<?php
include("header-profile.php");
if(isset($_COOKIE['site_url'])){
    $url= goodUrl($_COOKIE['site_url']);
    $DB = preg_replace("#[^0-9a-zA-Z_]#", "_", $url);
}else if(!isset($_GET['site-url'])){
   echo '<script>window.location="./"</script>'; 
}
?>
<style>
    .table-views {
        width:80%;
        margin:30px auto;
        box-shadow:0 0 4px;
        padding:20px;
        border-radius:5px;
    }
    .chartJS {
        margin:50px auto;
        width:80%;
        margin:30px auto;
        box-shadow:0 0 4px;
        padding:20px;
        border-radius:5px;
    }
    .footer-mapping {
        margin:50px auto;
        width:80%;
        margin:30px auto;
        padding:0px;
        border-radius:5px;
    }
    .footer-mapping #vmap {
        width: 100%; height: 400px;
		border-radius: 5px;
    }
    .data {
        margin-top:10px;
        font-weight:bold;
        text-align:center;
    }
    .footer-mapping span {
        font-size:11px;
        color:tomato;
    }
    @media(max-width: 768px){
        .table-views {
            width:100%;
            box-shadow:none;
            border:1px solid #ccc;
        }
        .chartJS {
            width:100%;
            box-shadow:none;
            border:1px solid #ccc;  
        }
        .footer-mapping {
            width:100%;
            box-shadow:none;
            border:1px solid #ccc;
        }
        .footer-mapping #vmap {
			width: 100%; 
			height: 350px;
		}
    }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="table-views">
            <?php
                
                $sql = mysqli_query($conn, "SELECT * FROM ".$DB." GROUP BY page_views ORDER BY activity_time ") or die(mysqli_error($conn));
                $siteName = preg_replace("#[^a-z0-9A-Z]#", ".", $DB);
                $output = "";
        		if (mysqli_num_rows($sql) > 0) {?>
        		    <div class="table table-responsive">
        		        <h4>Top Pages</h4><hr>
        		        <table class="table table-hover">
        		            <thead>
        		                <tr>
        		                    <th>Page</th>
        		                    <th>Visitor</th>
        		                    <!--<th>Load Speed</th>-->
        		                </tr>
        		            </thead>
        		<?php
        		    
            		foreach ($sql as $row) {
                        $page_link = $row['page_views'];
                        $page_load_speed = $row['pageLoadTime'];
                        $url_link = preg_replace("(^https?://)", "", $page_link );
                        
            			?>  
            			<tbody>
        			        <tr>
        			            <td><?php echo  $url_link;?></td>
        			            <td><?php echo countViewsPerPage($conn, $DB, $page_link)?></td>
        			            <!--<td><?php echo $page_load_speed;?></td>-->
        			        </tr>
        				</tbody>
            			<?php
            			    
            			}
            		?>
            		    </table>
            		    <h4>Total Views: <?php echo countTotalSiteView($conn, $DB)?></h4>
                    </div>
            	<?php
            	    $query = mysqli_query($conn, "SELECT COUNT(page_views) AS views , countryName, CAST(activity_time as Date) AS days_visited  FROM ".$DB." GROUP BY days_visited") or die(mysqli_error($conn));
            	    
            	    $data = array();
            	    foreach($query as $rowdata){
            	      $data[] = $rowdata;  
            	    }
            	    $chart_data = $activity_time = $countryName = "";
                	$new_data = json_encode($data);
                    $var=json_decode($new_data, true);
                    foreach ($var as $key=>$value) {
                        // $page .=  '\''.preg_replace("(^https?://)", "",$row['page_views']).'\', ';
                        $chart_data .= $value['views'].",";
                        $activity_time .= '\''.date("j-F:", strtotime($value["days_visited"])).'\', ';
                        $dates .= date("M-d", strtotime($value["days_visited"])).',';
                        if($value["countryName"] == ""){
                            $countryName = "";
                        }else{
                            $countryName .= '\''.$value["countryName"].'\', ';
                        }
                    }
                    $countryName = trim($countryName, ",");
                    $activity_time_trimed = trim($activity_time, ",");
                	$chart_data_trimmed = trim($chart_data, ",");
                	$dates = trim($dates, ",");
            	}
            ?>
            </div>
        </div>
        <div class="col-md-12">
            <div class="chartJS">
                <canvas id="myChart"></canvas>
            </div>
        </div>
        <div class="col-md-12">
            <div class="footer-mapping">
                <div class="col-md-10">
                   <div id="vmap" style=""></div><br>
                   <div><a href="" class="btn btn-default btn-sm country-details" id="<?php echo $DB?>"><i class="fa fa-globe" aria-hidden="true"></i> TRAFFIC SOURCE</a> </div>
                </div>
                <div class="col-md-2">
                    <div id="result"></div>
                </div>
            </div>
            <br><br><br>
        </div>
        <div class="modal" tabindex="-1" role="dialog" id="CountriesDialog">
        	<div class="modal-dialog modal-lg" role="document">
        		<div class="modal-content">
        	  		<div class="modal-header">
        	    		<h3 class="text-center"><?php echo $siteName;?></h3>
        	    		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        	      			<span aria-hidden="true">&times;</span>
        	    		</button>
        	  		</div>
        		  	<div class="modal-body">
        		    	<div id="modal-results"></div>
        		  	</div>
        		  	<div class="modal-footer">
        		    	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        		  	</div>
        		</div>
        	</div>
        </div>
    </div>
</div>
<link rel="stylesheet" href="maps/css/jqvmap.css" type="text/css"/>

<?php
include("footer-profile.php");
?>
<script type="text/javascript" src="maps/js/jquery.vmap.js"></script>
<script type="text/javascript" src="maps/js/jquery.vmap.world.js" charset="utf-8"></script>
<script type="text/javascript" src="maps/js/jquery.vmap.sampledata.js"></script>
<script>
    document.title = "<?php echo $DB?>";
    var ctx = document.getElementById("myChart").getContext('2d');
    var myChartTwo = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [<?php echo $activity_time_trimed;?>],
            datasets: [{
                label: 'Visitors', // Name the series
                data: [<?php echo $chart_data_trimmed;?>], // Specify the data values array
                fill: false,
                borderColor: '#6499cd', // Add custom color border (Line)
                backgroundColor: '#2196f3', // Add custom color background (Points and Fill)
                borderWidth: 1 // Specify bar border width
            }]},
        options: {
          responsive: true, // Instruct chart js to respond nicely.
          maintainAspectRatio: true, // Add to prevent default behaviour of full-width/height
          title: {
				display: true,
				text: 'Website View by Dates'
			},
        }
    });
</script>
<script>
  jQuery(document).ready(function () {
    var DB = '<?php echo $DB?>';
    jQuery('#vmap').vectorMap({
	    map: 'world_en',
	    backgroundColor: '#a5bfdd',
	    borderColor: '#818181',
	    borderOpacity: 0.25,
	    borderWidth: 1,
	    color: '#f4f3f0',
	    enableZoom: true,
	    hoverColor: '#c9dfaf',
	    hoverOpacity: null,
	    normalizeFunction: 'linear',
	    scaleColors: ['#b6d6ff', '#005ace'],
	    selectedColor: '#c9dfaf',
	    selectedRegions: null,
	    showTooltip: true,
	    onRegionOver: function(element, code, region){
	        var message = 'You clicked "'
	            + region
	            + '" which has the code: '
	            + code.toUpperCase();
	        jQuery.ajax({
	            
	        	url:"includes/maps",
	        	method:"post",
	        	data:{region:region, DB:DB},
	        	success:function(data){
	                $("#result").html(region +"<br><span> Visitors:</span> "+data).addClass("data");
	        	}
	        });
	    },
	    onRegionClick: function(event, code, region){
	       jQuery.ajax({
	        	url:"includes/maps",
	        	method:"post",
	        	data:{region:region, DB:DB},
	        	success:function(data){
        	       $("#result").html(region +"<br><span> Visitors<:/span> "+data ).addClass("data");
	        	}
	        }); 
	    }
        
	});
	$(document).on("click", ".country-details", function(event){
	    event.preventDefault();
	    var DBNAME = $(this).attr("id");
	    jQuery.ajax({
        	url:"includes/country-visitors",
        	method:"post",
        	data:{DBNAME:DBNAME},
        	success:function(data){
        	    $("#CountriesDialog").modal("show");
    	       $("#modal-results").html(data);
        	}
        });
	})
  });
</script>