<?php 
include 'header.php'; 

function extract_tags_from_url($url) {
  $tags = array();

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

  $contents = curl_exec($ch);
  curl_close($ch);

  if (empty($contents)) {
    return $tags;
  }
	
  if (preg_match_all('/<meta([^>]+)content="([^>]+)>/', $contents, $matches)) {
    $doc = new DOMDocument();
    $doc->loadHTML('<?xml encoding="utf-8" ?>' . implode($matches[0]));

    $nodes = $doc->getElementsByTagName('title');
	//get and display what you need:
	if ($nodes->length>0) { 			
		$title = $nodes->item(0)->nodeValue; 		
	}

    $tags = array();
    foreach($doc->getElementsByTagName('meta') as $metaTag) {
      if($metaTag->getAttribute('name') != "") {
        $tags[$metaTag->getAttribute('name')] = $metaTag->getAttribute('content');
      }
      elseif ($metaTag->getAttribute('property') != "") {
        $tags[$metaTag->getAttribute('property')] = $metaTag->getAttribute('content');
      }
    }
  }

  return $tags;
}
$web = (extract_tags_from_url("https://youtube.com"));

$url_web = json_encode($web);

$json = json_decode($url_web, true);
if(array_key_exists('title', $json)){
	$title = $json['title'];
}elseif(array_key_exists("og:title", $json)){
	$title = $json['og:title'];
}else{
	$title =  "Website has no Title Tag";
}

if(array_key_exists('description',$json)){
	$description = $json['description'];
}elseif(array_key_exists('og:description',$json)) {
	$description = $json['og:description'];
}else{
	$description = "Website has No Meta named description";
}

if(array_key_exists('keywords',$json) ){
	$keywords = $json['keywords'];
}elseif(array_key_exists('og:keywords',$json)) {
	$keywords = $json['og:keywords'];
}else{
	$keywords = "Website has No Meta named keywords";
}

if(array_key_exists('image',$json)){
	$image = '<img src="'.$json['image'].'" class="img-responsinve img-thumbnails image_preview">';
}elseif(array_key_exists('og:image',$json)) {
	$image = '<img src="'.$json['og:image'].'" class="img-responsinve img-thumbnails image_preview">';
}else{
	$image = "Website has No Meta named image";
}

echo $title."<br>";
echo $image."<br>";
echo nl2br($description)."<br>";


?>



