<?php
include 'header-profile.php';
?>
<style>
    .table-views {
        width:80%;
        margin:30px auto;
        box-shadow:0 0 4px;
        padding:20px;
        border-radius:5px;
    }
    .form-control {
        width:30%;
    }
    @media(max-width:768px){
        .table-views {
            width:100%;
            box-shadow:none;
            border:1px solid #ccc;
        }
        .form-control {
            width:100%;
        }
    }
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<?php
				$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ");
				$query->bind_param("s", $_SESSION['email']);
				$query->execute();
				$result = $query->get_result();
				
				$URI = basename($_SERVER["REQUEST_URI"]);
			    if($URI ==  "web-pages"){
			        
			    }else{
			        $page = $URI;
			    }
			?>
			    <select class="form-control" onchange="changeURL(this.value)" id="changeURL">
			        <option value="">My Websites</option>
			        
            <?php
				foreach ($result as $row) {
				$DB = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($row['website_link']));
				?>
					<option value="web-pages/<?php echo $DB?>"><?php echo strtoupper(goodUrl($row['website_link']))?></option>
				<?php
				}
			?>
			    </select>
		</div>
		<div class="col-md-12">
		    <div class="table-views">
		    <?php
		       $DBNAME = basename($_SERVER["REQUEST_URI"]);
		       $URL = preg_replace("#[^0-9a-zA-Z]#", ".", goodUrl($DBNAME));
		       if($DBNAME ==  "web-pages"){
		           
		       }else{?>
		           <h4><?php echo strtoupper($URL)?> <hr>Total Views: <?php echo countTotalSiteView($conn, $DBNAME)?></h4>
                <?php
                    
                    $sql = mysqli_query($conn, "SELECT * FROM ".$DBNAME." GROUP BY page_views ORDER BY id DESC ") or die(mysqli_error($conn));
                    $output = "";
            		if (mysqli_num_rows($sql) > 0) {?>
            		    <div class="table table-responsive">
            		        <table class="table table-hover">
            		            <thead>
            		                <tr>
            		                    <th>Page</th>
            		                    <th>Views</th>
            		                    <th>Load Speed</th>
            		                </tr>
            		            </thead>
            		<?php
                		foreach ($sql as $row) {
                            $page_link = $row['page_views'];
                            $page_load_speed = $row['pageLoadTime'];
                            $url_link = preg_replace("(^https?://)", "", $page_link );
                			?>  <tbody>
                			        <tr>
                			            <td><?php echo  $url_link;?></td>
                			            <td><?php echo countViewsPerPage($conn, $DBNAME, $page_link)?></td>
                			            <td><?php echo $page_load_speed;?></td>
                			        </tr>
                				</tbody>
                		<?php
                			    
            			}
            		?>
            		    </table>
            		</div>
            		<?php
            		}
		       }
		    ?>
		    </div>
			<div class="website-pages"><span class="loadingSpan" style="display: none;"> Loading... <i class="fa fa-spinner fa-spin fa-2x"></i></span></div>
		</div>
	</div>
</div>

<?php
include 'footer-profile.php';
?>
<script>
    function changeURL(url){
        if(url == ""){
            return false;
        }else{
            var changeURL = document.getElementById("changeURL").selected = url;
            window.location = url;
        }
    }
</script>