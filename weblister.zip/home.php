<?php include 'header.php'; 
?>
<style>
	.links {
		width: 70%;
		margin: auto;
	}
</style>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="well links">
					<h2 class="text-center">Find Useful Links</h2><hr>
					<select class="form-control" name="website_category" id="website_category" onchange="website_category(this.value)" >
						<option value="">Choose A Category</option>
						<option value="Blog">Blog</option>
						<option value="Education">Education</option>
						<option value="E-commerce">E-commerce</option>
						<option value="How To">How To</option>
						<option value="Life Style">Life Style</option>
						<option value="Medical">Medical</option>
						<option value="Music">Music</option>
						<option value="News">News</option>
						<option value="Personal">Personal</option>
						<option value="Technology">Technology</option>
						<option value="Other">Other</option>
					</select>
					<br><br>
				</div>
			</div>
			<div class="col-md-12">
				<div class="links">
					<h3 class="title text-center"></h3>
					<div class="display_sites"></div>
				</div>

			</div>
		</div>
	</div>
	<script type="text/javascript">
		function website_category(category) {
			if (category == "") {
				$(".title").html("");
				display_sites();
			}else if(category == "Blog"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				BlogSites();
			}else if(category == "Education"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				Education();
			}else if(category == "E-commerce"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				E_commerce();
			}else if(category == "How To"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				HowTo();
			}else if(category == "Life Style"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				LifeStyle();
			}else if(category == "Medical"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				Medical();
			}else if(category == "Music"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				Music();
			}else if(category == "News"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				News();
			}else if(category == "Personal"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				Personal();
			}
			else if(category == "Technology"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				Technology();
			}
			else if(category == "Other"){
				localStorage.setItem("title",category);
				$(".title").html(category+ "<hr>");
				Other();
			}

		}

		function BlogSites(){
			var BlogSites = "BlogSites";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{BlogSites:BlogSites},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}
		function Education(){
			var Education = "Education";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{Education:Education},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}
		function E_commerce(){
			var E_commerce = "E_commerce";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{E_commerce:E_commerce},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}
		function HowTo(){
			var HowTo = "HowTo";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{HowTo:HowTo},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}
		function LifeStyle(){
			var LifeStyle = "LifeStyle";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{LifeStyle:LifeStyle},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}

		function Medical(){
			var Medical = "Medical";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{Medical:Medical},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}

		function Music(){
			var Music = "Music";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{Music:Music},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}

		function News(){
			var News = "News";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{News:News},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}

		function Personal(){
			var Personal = "Personal";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{Personal:Personal},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}
		
		function Technology(){
			var Technology = "Technology";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{Technology:Technology},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}

		function Other(){
			var Other = "Other";
			$.ajax({
				url:"includes/web-fetch.php",
				method:"post",
				data:{Other:Other},
				success:function(data){
					$(".display_sites").html(data);
				}
			})
		}
	</script>
</body>
</html>
<?php ob_flush(); ?>
<!-- 
Will create an og meta generator to copy and paste the code.
 -->