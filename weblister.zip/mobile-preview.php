<?php
include("header-profile.php");
$url = basename($_SERVER["REQUEST_URI"]);
if($url == 'mobile-preview'){
    echo '
        <script>
            window.location = "web-profile";
        </script>
    ';
}else{
   $URL = base64_decode($url);
}
?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <h2><?php echo strtoupper(goodUrl($URL));?> Mobile Preview</h2><hr>
                <div id="preview"></div>
            </div>
            <div class='col-md-6'>
                <?php
                    echo MobiePreviewSite($conn, $_SESSION['email']);
                ?>
            </div>
        </div>
    </div>
<?php
include("footer-profile.php");
?>
<script>
    bioMp(document.getElementById('preview'), {
		url: '<?php echo $URL?>',
	    image: 'wmp/images/iphone6_front_black.png',
	    width: 330,
	});

</script>

