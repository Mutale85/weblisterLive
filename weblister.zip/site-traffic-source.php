<?php
include 'header-profile.php';
?>
<style>
    .table-views {
        width:80%;
        margin:30px auto;
        box-shadow:0 0 4px;
        padding:20px;
        border-radius:5px;
    }
    .form-control {
        width:40%;
    }
    @media(max-width:768px){
      .table-views {
          width:100%;
        }
      .form-control {
        width:100%;
     }
    }
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		    
			<?php
				$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ");
				$query->bind_param("s", $_SESSION['email']);
				$query->execute();
				$result = $query->get_result();
			?>
			<select class="form-control" onchange="changeURL(this.value)" id="changeURL">
			    <option value="">View Website</option>
            <?php    
				foreach ($result as $row) {
				$DB = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($row['website_link']));
				?>
				<option value="site-traffic-source/<?php echo $DB?>"><?php echo strtoupper(goodUrl($row['website_link']))?></option>
					<!--<div class="">-->
					<!--	<h4><?php echo strtoupper(goodUrl($row['website_link']))?></h4>-->
					<!--	<p><a href='site-traffic-source/<?php echo $DB?>' id="<?php echo $row['website_link']?>">Check Page Views</a></p>-->
					<!--</div>-->
				<?php
				}
			?>
			</select>
			
		</div>
		<div class="col-md-12">
		    <div class="table-views">
		    <?php
		       $DBNAME = basename($_SERVER["REQUEST_URI"]);
		       $URL = preg_replace("#[^0-9a-zA-Z]#", ".", goodUrl($DBNAME));
		       if($DBNAME ==  "site-traffic-source"){
		           
		       }else{?>
		           <!--<h4><?php echo strtoupper($URL)?> <hr>Total Views: <?php echo countTotalSiteView($conn, $DBNAME)?></h4>-->
                <?php
                    
                    $sql = mysqli_query($conn, "SELECT * FROM ".$DBNAME." GROUP BY countryName ") or die(mysqli_error($conn));
                    $output = "";
            		if (mysqli_num_rows($sql) > 0) {?>
            		    <h3><?php echo strtoupper(goodUrl($URL))?></h3><hr>
            		    <div class="table table-responsive">
            		        <table class="table table-hover">
            		            <thead>
            		                <tr>
            		                    <th>Country Name</th>
            		                    <th>Views</th>
            		                </tr>
            		            </thead>
            		<?php
                		foreach ($sql as $row) {
                            $countryName = $row['countryName'];
                			if($row['countryName'] == ""){
                		        
                		    }else{
                			?>  <tbody>
                			        <tr>
                			            <td><?php echo  $countryName;?></td>
                			            
                			            <td><?php echo viewerCountry($conn, $DBNAME, $countryName)?></td>
                			        </tr>
                				</tbody>
                		<?php
                		   }       
            			}
            		?>
            		    </table>
            		</div>
            		<?php
            		}
            		// Unique visitor
            		$query = mysqli_query($conn, "SELECT COUNT(user_ip) AS ip_add FROM ".$DBNAME." GROUP BY user_ip ");
            		$count_Ips = mysqli_num_rows($query);
            		echo "<h3>Total Unique Visitors: ". $count_Ips."</h3>";
		       }
		    ?>
		    </div>
			<div class="website-pages"><span class="loadingSpan" style="display: none;"> Loading... <i class="fa fa-spinner fa-spin fa-2x"></i></span></div>
		</div>
	</div>
</div>

<?php
include 'footer-profile.php';
?>
<script>
    function changeURL(url){
        if(url == ""){
            return false;
        }else{
            var changeURL = document.getElementById("changeURL").selected = url;
            window.location = url;
        }
    }
</script>

