<?php include "header-profile.php" ?>
<style>
	.Website-mobile-preview {
		margin:30px auto;
	}
	img {
		width: 200px;
		height: 200px;
	}
</style>
<div class="container-fluid">
	<div class="row">
		<div class="performance-div">
			<div class="col-md-12">
				<div id="performance"> Please Wait ... <i class="fa fa-spinner fa-spin fa-fw"></i></div>
			</div>
			<div class="col-md-12">
				<!-- Website Mobile Preview -->
				<div class="Website-mobile-preview">
					<div id="preview"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'footer-profile.php'; ?>
<script>
	performance();
</script>
