<?php
include("header.php");
?>
<style>
	.forgot-password {
		margin:60px auto;
		padding: 30px;
		width: 50%;
		box-shadow: 0 0 5px;
		border-radius: 7px;
		
	}
	#getpassword {
		width: 100%;
	}
	@media(max-width: 768px){
	  	.forgot-password {
	    	width: 100%;
	    	box-shadow: none;
	  	}
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="forgot-password">
				<h1 class="text-center">Recover Password</h1><hr>
				<form method="post" id="newPasswordForm">
					<div class="form-group">
						<div class="input-group">
							<input type="email" id="forgotpass_email" name="forgotpass_email" class="form-control" placeholder="Enter your email" onkeyup="restrict('forgotpass_email')" required="required">
							<div class="input-group-addon">
								<span class="input-group-text"><i class="fa fa-search" id="fafa" aria-hidden="true"></i></span>
							</div>
						</div>
					</div>
					<button type="submit" name="getpassword" id="getpassword" class="btn btn-info post-btn">Submit</button>
					<div id="results"></div>					
    			</form>
			</div>
		</div>
	</div>
</div>

<script>
	function restrict(elem){
		var tf = document.getElementById(elem);
		var rx = new RegExp;
		if (elem == "forgotpass_email") {
		    rx = /[' ";]/;
		}
		tf.value = tf.value.replace(rx, "");
	};
  
$(function(){
  $("#newPasswordForm").submit(function(event){
    	event.preventDefault();
    	var forgotpass_email = $("#forgotpass_email").val();
    $.ajax({
      // url:"actions.php",
		url:"includes/forgot-password.php",
		method:"post",
		data:{forgotpass_email:forgotpass_email},
		beforeSend:function(data){
      		$("#fafa").removeClass('fa fa-search');
      		$("#fafa").addClass('fa fa-spinner fa-spin');
      		$("#getpassword").attr("disabled", "disabled");
      		$("#getpassword").html("<i class='fa fa-spinner fa-spin'></i>");
     	 },
      	success:function(data){
        	$("#results").html(data);
        	$("#newPasswordForm")[0].reset();
        	$("#fafa").removeClass('fa fa-spinner fa-spin');
        	$("#fafa").addClass('fa fa-search');
        	$("#getpassword").removeAttr("disabled", "disabled");
      		$("#getpassword").html("Submit");
     	}
    })
  })
})
</script>