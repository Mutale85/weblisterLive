<?php
if (!isset($_GET['token']) && empty($_GET['email'])) {
	header("location:./");
}else{
	$token = $_GET['token'];
	$email = $_GET['email'];
}
include("header.php");
?>
<style>
	.resetpass-div {
		margin: 40px auto;
		width: 65%;
		box-shadow: 0 0 5px;
		border-radius: 7px;
		padding: 20px;
	}
	.input-group-addon {
		cursor: pointer;
	}
	/* The message box is shown when the user clicks on the password field */
	#message {
		text-align: center;
		font-size: 18px;
		margin: 10px;
	}
	.resetpass-div .short{
		color:#FF0000;
	}

	.resetpass-div .weak{
		color:#E66C2C;
	}

	.resetpass-div .good{
		color:#2D98F3;
	}

	.resetpass-div .strong{
		color:#006400;
	}
	@media(max-width: 768px){
		.resetpass-div {
			width: 100%;
			box-shadow: none;
		}
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="resetpass-div">
				<h1>Reset Password</h1><hr>
				<form method="post" id="resetPasswordForm">
					<div class="form-group">
						<label>New Password</label>
						<div class="input-group">
							<input type="password" name="new_password" id="new_password" class="form-control" required>
							<div class="input-group-addon" onclick="PasswordView()"><i class="fa fa-eye"></i></div>
						</div>
					</div>
					<input type="hidden" name="token" id="token" value="<?php echo $token?>">
					<input type="hidden" name="email" id="email" value="<?php echo $email?>">
					<div class="form-group">
						<label>Repeat Password</label>
						<input type="password" name="repeat_password" id="repeat_password" class="form-control" onkeyup="comparePass(this.value)" required>
					</div>
					<button class="btn btn-default" type="submit">Submit</button>
				</form>
				<div id="message">
				  <span id="result"></span>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	
function PasswordView(){
	var password = document.getElementById('new_password');
	var repeat_password = document.getElementById('repeat_password');
	if (password.type === "password" && repeat_password.type == "password") {
		password.type = "text";
		repeat_password.type = "";
		$(".fa-eye").addClass('fa-eye-slash');
	}else{
		password.type = "password";
		repeat_password.type = "password";
		$(".fa-eye").removeClass('fa-eye-slash');
	}
}

function comparePass(repeat_password){
	var new_password = document.getElementById('new_password').value;
	if (repeat_password != new_password) {
		$('#result').html("Passwords not matching").addClass("short");
	}else if(repeat_password == new_password){
		$('#result').html("");
	}
}

$(function(){	
	$('#new_password').keyup(function(){
		$('#result').html(checkStrength($('#new_password').val()))
	});
	function checkStrength(password){
        //initial strength
		var strength = 0
		
		//if the password length is less than 6, return message.
		if (password.length < 5) { 
			$('#result').removeClass()
			$('#result').addClass('short')
			return 'Too short' 
		}
		
		//length is ok, lets continue.
		
		//if length is 8 characters or more, increase strength value
		if (password.length > 5) strength += 1
		
		//if password contains both lower and uppercase characters, increase strength value
		if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))  strength += 1
		
		//if it has numbers and characters, increase strength value
		if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/))  strength += 1 
		
		//if it has one special character, increase strength value
		if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/))  strength += 1
		
		//if it has two special characters, increase strength value
		if (password.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
		
		//now we have calculated strength value, we can return messages
		
		//if value is less than 2
		if (strength < 2 )
		{
			$('#result').removeClass()
			$('#result').addClass('weak')
			return 'Weak'			
		}
		else if (strength == 2 )
		{
			$('#result').removeClass()
			$('#result').addClass('good')
			return 'Good'		
		}
		else
		{
			$('#result').removeClass()
			$('#result').addClass('strong')
			return 'Strong'
		}
	};

	// post new passwords
	$("#resetPasswordForm").submit(function(event){
		event.preventDefault();
		$.ajax({
			url:"includes/password-reset",
			method:"post",
			data:$(this).serialize(),
			success:function(data){
				if (data == "Done") {
					alert("Password Changed Successfully");
					window.location = "login";
				}else{
					alert("Password Changed Issues");
					window.location = "./";
				}
			}
		})
	})
})
</script>