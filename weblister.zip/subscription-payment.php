<?php
include 'header-profile.php';
	
?>
<style>
	.success-payment {
		margin:40px auto;
		box-shadow: 0 0 5px;
		padding: 20px;
		border-radius: 5px;
	}
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<?php
				if (isset($_GET['success']) && isset($_GET['user_email']) && isset($_GET['payment_plan']) && isset($_GET['currency']) && isset($_GET['amount_paid']) && isset($_GET['duration']) && isset($_GET['tx_ref'])) {
					$success 		= $_SESSION['email'];
					$user_email 	= $_GET['user_email'];
					$payment_plan 	= $_GET['payment_plan'];
					$currency 		= $_GET['currency'];
					$amount_paid 	= $_GET['amount_paid'];
					$duration 		= $_GET['duration'];
					$tx_ref 		= $_GET['tx_ref'];
					$end_date = "";
					$number_of_sites = "";

					if ($duration == "Monthly") {
						$end_date =  date('Y-m-d', strtotime("+30 days"));
					}elseif ($duration == "Yearly") {
						$end_date =  date('Y-m-d', strtotime("+1 year"));
					}

					if ($payment_plan == "Basic") {
						$number_of_sites = 1;
					}elseif ($payment_plan == "Middle") {
						$number_of_sites = 5;
					}elseif ($payment_plan == "Platinum") {
						$number_of_sites = 10;
					}

					// ---- confirm tx_ref --------
					$sql = $conn->prepare("SELECT tx_ref FROM web_directory WHERE user_email = ? ") or die(mysqli_error($conn));
					$sql->bind_param("s", $user_email);
					$sql->execute();
					$result= $sql->get_result();
					foreach ($result as $row) {
						if ($row['tx_ref'] == "") {
							echo '<script>
									window.location = "subscription";
								</script>';

						}if ($row['tx_ref'] == $tx_ref) {
							$new_tx_ref;
							
							$update = $conn->prepare("UPDATE web_directory SET plan = ?, price = ?, currency = ?, number_of_sites = ?, end_date = ?, tx_ref = ? WHERE user_email = ? ") or die(mysqli_error($conn));
							$update->bind_param("sssssss", $payment_plan, $amount_paid, $currency, $number_of_sites, $end_date, $new_tx_ref, $user_email );
							$update->execute();
							if ($update) {?>
								<div class="success-payment text-center">
									<h4>Thank you for subscribing to <b><?php echo $payment_plan;?></b></h4>
									<p>Give us feeback on any issues you have on + 260 976 330 092 or  <a href="mailto:info@weblister.co">EMAIL US HERE</a> </p>
								</div>
								
							<?php
							}
						}
					}

				}else{
					echo '<script>
							window.location = "subscription";
						</script>';
				}
			?>
		</div>
		
	</div>
</div>

<?php
include 'footer-profile.php';
?>
