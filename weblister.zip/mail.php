<!DOCTYPE html>
<html>
<head>
	<title>Mail</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
</head>
<style type="text/css">
	.mail-div {
		box-shadow: 0 0 5px;
		padding: 20px;
		width: 60%;
		margin:50px auto;
		border-radius: 5px;
	}
	h1 span {
		color: #6499cd;
	}
	.icon_image {
		width: 100px;
		height: 100px;
		float: right;
		-webkit-animation:spin 5s linear infinite;
	    -moz-animation:spin 5s linear infinite;
	    animation:spin 5s linear infinite;
	}
	@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
	@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
	@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }

	@media(max-width: 768px){
		.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
	}
</style>
<body>
	<div class="mail-div">
		<img src="images/icon_new.png" class="icon_image">
		<h1>Welcome: <span> George </span></h1>
		<a href="">Activate your account by clicking here</a>
		<p>You can also copy this link and paste it into your browser.</p>
		<h4>Welcome to weblister. Add your websites links and also check other sites that are similar to what yours is about.</h4>
	</div>
</body>
</html>