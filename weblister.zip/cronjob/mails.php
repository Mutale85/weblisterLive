<?php
include("../includes/db.php");
$con = "Testing";
echo $con;
?>