<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
date_default_timezone_set('Africa/Lusaka');

include("../includes/db.php");
include_once "../PHPMailer/PHPMailer.php";
include_once "../PHPMailer/Exception.php";
include_once "../PHPMailer/SMTP.php";
include_once "../PHPMailer/OAuth.php";


$query = $conn->prepare("SELECT * FROM web_directory");
$query->execute();
$result = $query->get_result();
$site_status = "";

foreach($result as $row){
    $url = strtoupper(goodUrl($row['website_link']));
    $user_email = $row['user_email'];
    
    if(AdminCheckWebsiteUptime($row['website_link'])){
        
        // $site_status = "<span class='text-success'>100 Uptime</span>";
        //Website Up
        $site_status = '
            <!DOCTYPE html>
                <html>
                <head>
                	<title>'.$url.'</title>
                	<meta name="viewport" content="width=device-width, initial-scale=1.0">
                	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
                	<style>
                		.mail-div {
                			border:1px solid #ccc;
                			padding: 20px;
                			width: 60%;
                			margin:50px auto;
                			border-radius: 5px;
                		}
                		h1 span {
                			color: #6499cd;
                		}
                		.icon_image {
                			width: 100px;
                			height: 100px;
                			float: right;
                			-webkit-animation:spin 5s linear infinite;
                		    -moz-animation:spin 5s linear infinite;
                		    animation:spin 5s linear infinite;
                		}
                		@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
                		@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
                		@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }
                
                		@media(max-width: 768px){
                			.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
                		}
                		.codeArea {
                			background: #6499cd;
                			color: #fff;
                			padding: 10px;
                			border-radius: 5px;
                			font-family: "Source Code Pro", monospace;
                		}
                		.codeArea textarea{
                			margin: 5px auto;
                			width: 98%;
                			height: 60px;
                			resize: none;
                			border: none;
                			padding: 10px;
                			color: #fff;
                		}
                		.monitor_image {
                			width: 50%;
                			height: 50%;
                			margin-left: auto;
                			margin-right: auto;
                		}
                		.link_btn button{
                			padding: 8px;
                			margin-top: 7px;
                			color: tomato;
                			font-family: "Source Code Pro", monospace;
                			font-weight: bold;
                		}
                		@media(max-width: 768px){
                			.mail-div {
                				width: 100%;
                			}
                			.codeArea textarea {
                				width: 95%;
                				border-radius: 5px;
                			}
                			.monitor_image {
                				width: 100%;
                				height: 100%;
                			}
                		}
                	</style>
                </head>
                <body>
                	
                	<div class="mail-div">
                		<img src="https://weblister.co/images/icon_new.png" class="icon_image" alt="Icon">
                		<h1>Your Website:  <span> '.strtoupper($url).' </span></h1>
                		<h2>Is very up un running Well. </h2>
                		<h3>Response Time: <span style="color:mediumseagreen">'.checkWebResponseTime($row['website_link']).'</span></h3>
                		<h4>Response Status:<span style="color:mediumseagreen"> 200</span></h4>
                		<img src="https://weblister.co/images/undraw_server_down.png" class="img-responsive monitor_image" >
                		<div class="codeArea">
                			<h4 align="center">For Detailed Analytics Add the code below if you haven\'t already added it to your HTML</h4><br>
                			<textarea readonly disabled="disabled" class="code-text"><script type="text/javascript" src="https://weblister.co/js/extension.js?url='.$row['website_link'].'"></script></textarea>
                			<br>
                		</div>
                		<a href="https://weblister.co/login" class="link_btn"><button>Access Info </button></a>
                		<p><em>Disclaimer: We are sending you this message because your website is listed with Weblister.co and we monitor your site uptime every 5 minutes.</em></p>
                		<p><a href="mailto:info@weblister.co">Send Us An Email</a> if you wish us to stop monitoring your site</p>
                	</div>
                	<script>
                		document.title = "'.$url.'";
                	</script>
                </body>
                </html>';
        
        
    }else{
        
        // $site_status = "<span class='text-danger'>Website Down</span>";
        //Website DOWN
        $site_status = '
            <!DOCTYPE html>
                <html>
                <head>
                	<title>'.$url.'</title>
                	<meta name="viewport" content="width=device-width, initial-scale=1.0">
                	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
                	<style>
                		.mail-div {
                			border:1px solid #ccc;
                			padding: 20px;
                			width: 60%;
                			margin:50px auto;
                			border-radius: 5px;
                		}
                		h1 span {
                			color: #6499cd;
                		}
                		.icon_image {
                			width: 100px;
                			height: 100px;
                			float: right;
                			-webkit-animation:spin 5s linear infinite;
                		    -moz-animation:spin 5s linear infinite;
                		    animation:spin 5s linear infinite;
                		}
                		@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
                		@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
                		@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }
                
                		@media(max-width: 768px){
                			.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
                		}
                		.codeArea {
                			background: #6499cd;
                			color: #fff;
                			padding: 10px;
                			border-radius: 5px;
                			font-family: "Source Code Pro", monospace;
                		}
                		.codeArea textarea{
                			margin: 5px auto;
                			width: 98%;
                			height: 60px;
                			resize: none;
                			border: none;
                			padding: 10px;
                			color: #fff;
                		}
                		.monitor_image {
                			width: 50%;
                			height: 50%;
                			margin-left: auto;
                			margin-right: auto;
                		}
                		.link_btn button{
                			padding: 8px;
                			margin-top: 7px;
                			color: tomato;
                			font-family: "Source Code Pro", monospace;
                			font-weight: bold;
                		}
                		@media(max-width: 768px){
                			.mail-div {
                				width: 100%;
                			}
                			.codeArea textarea {
                				width: 95%;
                				border-radius: 5px;
                			}
                			.monitor_image {
                				width: 100%;
                				height: 100%;
                			}
                		}
                	</style>
                </head>
                <body>
                	
                	<div class="mail-div">
                		<img src="https://weblister.co/images/icon_new.png" class="icon_image" alt="Icon">
                		<h1>Your Website:  <span> '.strtoupper($url).' </span></h1>
                		<h2 style="color:tomato;">Your Website is Down. </h2>
                		<h3>Response Time: <span style="color:mediumseagreen">'.checkWebResponseTime($row['website_link']).'</span></h3>
                		<h4>Response Status:<span style="color:tomato"> 400</span></h4>
                		<img src="https://weblister.co/images/undraw_server_down.png" class="img-responsive monitor_image" >
                		<div class="codeArea">
                			<p>Please Check with your hosting provider to see if there are any hiccups making your wesbite unreacheable.</p>
                		</div>
                		<a href="https://weblister.co/login" class="link_btn"><button>Access Info </button></a>
                		<p><em>Disclaimer: We are sending you this message because your website is listed with Weblister.co and we monitor your site uptime every 5 minutes.</em></p>
                		<p><a href="mailto:info@weblister.co">Send Us An Email</a> if you wish us to stop monitoring your site</p>
                	</div>
                	<script>
                		document.title = "'.$url.'";
                	</script>
                </body>
                </html>';
        
    }
    
    $sql = mysqli_query($conn, "SELECT  DATE_ADD(`date_sent`, INTERVAL 5 DAY ) AS due_date FROM `emails_records` ") or die(mysqli_error($conn)) ;
    
    $count_rows = mysqli_num_rows($sql);
    $rows = mysqli_fetch_assoc($sql);
    $due_date = $rows['due_date'];
    $mail = new PHPMailer();
    $mail->Host = "weblister.co";
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Username = "info@weblister.co";
    $mail->Password = "!vNQ6rQbQXMX";
    $mail->SMTPSecure = "ssl";//TLS
    $mail->Port = 465; //TLS port= 587
    $mail-> setFrom("info@weblister.co", "Website Monitoring");
    $mail->isHTML(TRUE);
    // $mail->SMTPDebug = 2;
    $mail-> Subject = $url." Uptime Status";
    
    $mail->Body = $site_status;
    try {
        $mail->addAddress($user_email, "Weblister");
    } catch (Exception $e) {
        echo 'Invalid address skipped: ' . htmlspecialchars($user_email) . '<br>';
        continue;
    }
    try {
        $mail->send();
        echo 'Message sent to :' . htmlspecialchars($user_email) . '<br>';
        $update = mysqli_query($conn, "INSERT INTO emails_records (user_email, next_date) VALUES('$user_email', '$due_date') ") or die(mysqli_error($conn));
    }catch (Exception $e) {
        echo 'Mailer Error (' . htmlspecialchars($user_email) . ') ' . $mail->ErrorInfo . '<br>';
        //Reset the connection to abort sending this message
        //The loop will continue trying to send to the rest of the list
        $mail->getSMTPInstance()->reset();
    }
    $mail->clearAddresses();
    
}
?>