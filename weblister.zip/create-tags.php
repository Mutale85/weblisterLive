<?php
include 'header.php';
?>
<style>
	.TagsDiv {
		margin:50px auto;
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="TagsDiv">
				<div class="metaTagsDiv">
					<form method="post" id="metaTagsForm">
						<div class="form-group">
							<label>Page Title</label>
							<input type="text" id="m_title" class="form-control">
						</div>
						<div class="form-group">
							<label>Page Description</label>
							<input type="text" id="m_description" class="form-control" placeholder="Page Description">
						</div>
						<div class="form-group">
							<label>Keywords</label>
							<input type="text" id="m_keywords" class="form-control" placeholder="Page keywords">
						</div>
						<div class="form-group">
							<label>Image Url</label>
							<input type="text" id="m_image" class="form-control" placeholder="http://www.example.com/image.jpg">
						</div>
					</form>
					<hr>
					<h2>Generated Meta Tags</h2>
					<div class="form-group">
						<textarea id="meta-tags" class="form-control" rows="8"></textarea>
					</div>
					<button type="button" class="btn btn-default copy_metas">Copy to Clipboard</button>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php");?>
<script>
	$(function(){
		// Tags creation --------
		$("#metaTagsForm input").on("input", function(){
			var m_title = jQuery("#m_title").val();
			var m_description = jQuery("#m_description").val();
			var m_image = jQuery("#m_image").val();
			var m_keywords = jQuery("#m_keywords").val();

			var tags = "";

			tags += '<title>'+m_title+'</title>\n';
			tags += '<meta name="description" content="'+m_description+'">\n';
			tags += '<meta property="og:title" content="'+m_title+'">\n';
			tags += '<meta property="og:description" content="'+m_description+'">\n';
			tags += '<meta property="og:keywords" content="'+m_keywords+'">\n';
			tags += '<meta property="og:image" content="'+m_image+'">\n';

			tags += '<meta name="description" content="'+m_description+'">\n';
			tags += '<meta property="twitter:title" content="'+m_title+'">\n';
			tags += '<meta property="twitter:description" content="'+m_description+'">\n';
			tags += '<meta property="twitter:keywords" content="'+m_keywords+'">\n';
			tags += '<meta property="twitter:image" content="'+m_image+'">\n';


			jQuery("textarea").html(tags);
		});

		jQuery('.copy_metas').on('click', function() {
		  document.querySelector("#meta-tags").select();
		  document.execCommand('copy');
		  alert("Copied");
		  $("#metaTagsForm")[0].reset();
			jQuery("textarea").html("");
		});
	})
</script>