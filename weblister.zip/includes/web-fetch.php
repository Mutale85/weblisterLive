<?php
include("db.php");

if (isset($_POST['display_sites'])) {
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory ORDER BY RAND() LIMIT 6") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<h3 class=''>Listed Websites</h3><br>";
		echo "<ol>";
		foreach ($QUERY as $row) { 
		?>
			<div class="col-md-6">
				<li> <a href="<?php echo $row['website_link']?>" target="_blank" class="check_user_ip" id="<?php echo $row['website_link']?>" onclick="manageClicks('<?php echo $row['website_link']?>')"><i class="fa fa-external-link" aria-hidden="true"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a>
				</li>
			</div>
		<?php
		}
		echo "</ol>";

		echo "<br><br><div class='directory_link'><a href='all-listed-sites' class=''><i class='fa fa-folder'></i> Open Directory</a></div><hr>";
	}else{
		
	}
}


if (isset($_POST['displayAllsites'])) {
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory ORDER BY RAND()") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<h3 class='allSitesTitle'>All Listed Websites</h3><br>";
		echo "<ol>";
		foreach ($QUERY as $row) { 
		?>
			<div class="col-md-6 allSites">
				<li> <a href="<?php echo $row['website_link']?>" target="_blank" class="check_user_ip" id="<?php echo $row['website_link']?>" onclick="manageClicks('<?php echo $row['website_link']?>')"><i class="fa fa-external-link" aria-hidden="true"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a>
				</li>
			</div>
		<?php
		}
		echo "</ol>";

	}else{

	}
}

if (isset($_POST['BlogSites'])) {
	$BlogSites = "Blog";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$BlogSites' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$BlogSites. "</span> Category</div>";
	}
}

if (isset($_POST['Education'])) {
	$Education = $_POST['Education'];
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$Education' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$Education. "</span> Category</div>";
	}
}

if (isset($_POST['E_commerce'])) {
	$E_commerce = "E-commerce";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$E_commerce' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$E_commerce. "</span> Category</div>";
	}
}

if (isset($_POST['HowTo'])) {
	$HowTo = "How To";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$HowTo' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$HowTo. "</span> Category</div>";
	}
}

if (isset($_POST['LifeStyle'])) {
	$LifeStyle = "Life Style";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$LifeStyle' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$LifeStyle. "</span> Category</div>";
	}
}

if (isset($_POST['Medical'])) {
	$Medical = "Medical";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$Medical' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$Medical. "</span> Category</div>";
	}
}

if (isset($_POST['Music'])) {
	$Music = "Music";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$Music' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$Music. "</span> Category</div>";
	}
}

if (isset($_POST['News'])) {
	$News = "News";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$News' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$News. "</span> Category</div>";
	}
}

if (isset($_POST['Personal'])) {
	$Personal = "Personal";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$Personal' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$Personal. "</span> Category</div>";
	}
}

if (isset($_POST['Technology'])) {
	$Technology = "Technology";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$Technology' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$Technology. "</span> Category</div>";
	}
}

if (isset($_POST['Other'])) {
	$Other = "Other";
	$QUERY = mysqli_query($conn, " SELECT * FROM web_directory WHERE website_category = '$Other' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($QUERY) > 0) {
		echo "<ol>";
		foreach ($QUERY as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<div class='alert alert-danger text-center'>No websites found in the <span style='color:#000;font-weight:bold;'>" .$Other. "</span> Category</div>";
	}
}











