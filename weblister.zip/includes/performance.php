<?php
include 'db.php';

if (isset($_POST['performance'])) {
	$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ");
	$query->bind_param("s", $_SESSION['email']);
	$query->execute();
	$result = $query->get_result();
	$URL = "";
	if ($result->num_rows > 0) {?>
		<div style="overflow-x:auto;">
	        <table id="pages">
				<thead>
					<tr>
						<th>URL</th>
						<th class="text-success">Uptime | %</th>
						<th class="text-danger">Downtime | %</th>
						<th class="text-success">Response | Seconds </th>
						<!--<th>Add Page </th>-->
					</tr>
				</thead>
	<?php
		foreach ($result as $row) {
			
			$URL .= $row['website_link'];

			if(websiteUptime($row['website_link'])){ ?>
				<tbody>
					<tr>
						<td><span><?php echo strtoupper(goodUrl($row['website_link']))?></span></td>
						<td><span class="text-success">100</span></td>
						<td><span class="text-danger">0</span></td>
						<td><span class="text-success"><?php echo checkWebResponseTime($row['website_link'])?></span></td>
						<!--<td>+</td>-->
					</tr>
				</tbody>    
		<?php
			}else{?>
				<tbody>
					<tr>
						<td><span><?php echo strtoupper(goodUrl($row['website_link']))?></span></td>
						<td><span>0%</span></td>
						<td><span class="text-danger">100%</span></td>
						<td><span class="text-success"><?php echo checkWebResponseTime($row['website_link'])?></span></td>
					</tr>
				</tbody>			   
		<?php
			}
		}
		?>
		</table>
	</div>
	<style>
        #pages {
          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        #pages td, #pages th {
          border: 1px solid #ddd;
          padding: 8px;
        }
        
        #pages tr:nth-child(even){background-color: #f2f2f2;}
        
        #pages tr:hover {background-color: #ddd;}
        
        #pages th {
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          /*background-color: #4CAF50;*/
          background-color:#6499cd;
          color: white;
        }
    </style>
	<?php
	}
}
?>