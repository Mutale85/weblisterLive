<?php
include 'db.php';

if (isset($_POST['website_link'])) {
	$website_link = $_POST['website_link'];
	$website_category = $_POST['website_category'];
	$query = $conn->prepare("SELECT * FROM web_directory WHERE website_category = ? AND website_link != ? ") or die(mysqli_error($conn));
	$query->bind_param("ss", $website_category, $website_link);
	$query->execute();
	$result = $query->get_result();
	if ($result->num_rows > 0) {
		
		foreach ($result as $row) { ?>
			<div class="similarSites well">
				<a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo goodUrl($row['website_link']); ?></a> 
			</div>
		<?php
		}
	}else{
		echo "<div class='text-danger'>No Similar Sites Found</div>";
	}
}
?>