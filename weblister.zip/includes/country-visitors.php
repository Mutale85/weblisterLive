<?php
include("db.php");

if(isset($_POST['DBNAME'])){
    $DBNAME = $_POST['DBNAME'];
    $sql = mysqli_query($conn, "SELECT * FROM ".$DBNAME." GROUP BY countryName ") or die(mysqli_error($conn));
	if (mysqli_num_rows($sql) > 0) {
	?>
	    <div style="overflow-x:auto;">
	        <h3><?php echo strtoupper(goodUrl($URL))?></h3>
	        <table class="country-users">
	            <thead>
	                <tr>
	                    <th>Country Name</th>
	                    <th>Views</th>
	                </tr>
	            </thead>
	<?php
		foreach ($sql as $row) {
            $countryName = $row['countryName'];
			if($row['countryName'] == ""){
		        
		    }else{
			?>  <tbody>
			        <tr>
			            <td><?php echo  $countryName;?></td>
			            
			            <td><?php echo viewerCountry($conn, $DBNAME, $countryName)?></td>
			        </tr>
				</tbody>
		<?php
		   }       
		}
		$query = mysqli_query($conn, "SELECT COUNT(user_ip) AS ip_add FROM ".$DBNAME." GROUP BY user_ip ") or die(mysqli_error($conn));;
    	$count_Ips = mysqli_num_rows($query);

	?>          <tfoot>
	                <tr>
	                    <th>Unique Visitors</th>
	                    <th><?php echo  $count_Ips; ?></th>
	                </tr>
	                <tr>
	                    <th>Total Visitors</th>
	                    <th><?php echo countTotalSiteView($conn, $DBNAME)?></th>
	                </tr>
	            </tfoot>
    	    </table>
    	</div>
    	<style>
            .country-users {
              font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
              border-collapse: collapse;
              width: 100%;
            }
            
            .country-users td, .country-users th {
              border: 1px solid #ddd;
              padding: 8px;
            }
            
            .country-users tr:nth-child(even){background-color: #6499cd;}
            
            .country-users tr:hover {background-color: #ddd;}
            
            .country-users th {
              padding-top: 12px;
              padding-bottom: 12px;
              text-align: left;
              background-color: #ccc;
              color: white;
            }
        </style>
	<?php
	}
}
?>