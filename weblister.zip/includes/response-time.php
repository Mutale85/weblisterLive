<?php
include("db.php");

if (isset($_POST['responseTime'])) {
	$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ");
	$query->bind_param("s", $_SESSION['email']);
	$query->execute();
	$result = $query->get_result();
	if ($result->num_rows > 0) {
			
		foreach ($result as $row) {
			$URL = $row['website_link'];
			?>
			<div class="well">
				<h5><?php echo checkWebsitePageResponseTime($URL)?></h5>
			</div>
		<?php
		}
	}
}

?>