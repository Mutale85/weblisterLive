<?php
include 'db.php';
if (isset($_GET['callback'])) {
	$getPageViews = $_GET['getPageViews'];
	$site_name = preg_replace("#[^0-9a-zA-Z_]#", "_" , goodUrl($_GET['site_name'])); 
	$operating_system = $_GET['operating_system'];
	$site_url = $_GET['site_url'];
	$_SESSION['page_views'];
	$countviews =  $_SESSION['page_views'] + 1;
	

	$pw = json_encode($getPageViews);

	$page_views = json_decode($pw, true);

	require_once '../mobile_detect/Mobile_Detect.php';
	$detect = new Mobile_Detect;
	$device_type = "";
	if( $detect->isMobile()){
		$device_type = "Mobile-Phone";
	}elseif ($detect->isTablet()) {
		$device_type = "Tablet";
	}else{
		$device_type = "Computer";
	}
	$ip_address = getUserIpAddr();
	

	// $sql = "CREATE TABLE IF NOT EXISTS weblifjy_web_listers.$site_name (
	// 	id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	// 	site_name VARCHAR(30) NOT NULL,
	// 	page_views TEXT NOT NULL,
	// 	device_type VARCHAR(100) NOT NULL,
	// 	user_ip VARCHAR(50) NOT NULL,
	// 	operating_system TEXT NOT NULL,
	// 	activity_time DATETIME NOT NULL
	// 	)
	// 	";

	// if ($conn->query($sql) === TRUE) {
	//    // echo "Table ".$site_name." created successfully<br>";
	// } else {
	//     echo "Error creating table: " . $conn->error;
	// }

	$activity_time =  date("Y:m:d h:i:s");
	$view = explode(",", $page_views);
	
	$insert = $conn->prepare("INSERT INTO $site_name (site_name, page_views,  device_type, user_ip, operating_system, activity_time) VALUES(?, ?, ?, ?, ?, ?)  ") or die(mysqli_error($conn));
	$insert->bind_param("ssssss", $site_name, $site_url, $device_type, $ip_address, $operating_system, $activity_time);
	if($insert->execute()){
		echo "Done";
	}else{
		echo "Error";
	}

// 	foreach ($view as $values) {
// 		preg_match("[a-zA-Z_//.:]", $values);
// 		$page_name = preg_replace("#[^a-zA-Z_//.:]#", "", $values);
// 		$numbers = preg_replace("#[^0-9]#", "", $values);
// 		echo $page_name." ".$numbers."<br>";
// 		// $update 
// 	}

}