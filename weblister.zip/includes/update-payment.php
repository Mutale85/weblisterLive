<?php
include 'db.php';
if (isset($_POST['tx_ref'])) {
	$tx_ref 		= $_POST['tx_ref'];
	$consumer_id 	= $_POST['consumer_id'];

	$update = $conn->prepare("UPDATE web_directory SET tx_ref = ?, user_id = ? WHERE user_email = ?  ") or die(mysqli_error($conn));

	$update->bind_param("sss", $tx_ref, $consumer_id, $_SESSION['email']);
	$update->execute();
}
?>