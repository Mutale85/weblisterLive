<?php
include("db.php");
if (isset($_POST['token']) AND isset($_POST['new_password'])) {
	$token = $conn->real_escape_string($_POST['token']);
	$new_password = $conn->real_escape_string($_POST['new_password']);
	$email = $conn->real_escape_string($_POST['email']);

	
    $check_db = $conn->prepare("SELECT * FROM members_list WHERE email = ? AND token = ? ") or die(mysqli_error($conn));
    $check_db->bind_param("ss", $email, $token);
    $check_db->execute();
    $result = $check_db->get_result();
    $count = $result->num_rows;
    if ($count > 0) {
    	$row = $result->fetch_assoc();
    	if ($row['token'] == "") {
    		header("location:./");
    	}elseif ($row['token'] != "") {
    		$tokenNow = "";
            $password = password_hash($new_password, PASSWORD_DEFAULT);
    		$update = $conn->prepare("UPDATE members_list SET password = ?, token = ? WHERE email = ? ") or die(mysqli_error());
    		$update->bind_param("sss", $password, $token, $email);
    		if($update->execute()){
                echo "Done";
                exit();
                // echo $conn->info;
            }else{
                echo $conn->info;
            }
    		$conn->close();
    	}
    }else{
    	header("location:./");
    }
}
?>