<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
include 'db.php';
if (isset($_POST['website_link'])) {

	$website_category 	= filter_var($_POST['website_category'], FILTER_SANITIZE_STRING);
	$website_link 		= filter_var($_POST['website_link'], FILTER_SANITIZE_URL);
	$ip_address 		= getUserIpAddr();
	$username 			= filter_var($_POST['username'], FILTER_SANITIZE_EMAIL);
	$email 				= filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
	$generatedPassword 	= passwordGenerate();
	$plan				= filter_var($_POST['plan'], FILTER_SANITIZE_STRING);
	$start_date			= filter_var($_POST['start_date'], FILTER_SANITIZE_STRING);	 
	$price				= filter_var($_POST['price'], FILTER_SANITIZE_STRING);
	$end_date			= filter_var($_POST['end_date'], FILTER_SANITIZE_STRING);

	if ($plan == "Trial") {
		$expiry_date 	= date('Y-m-d', strtotime("+ 2 weeks"));

	}

	if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9_+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website_link)) {
  		echo "Invalid URL";
  		exit();
  	}

  	$check_web = $conn->prepare("SELECT website_link FROM web_directory WHERE website_link = ? ") or die(mysqli_error($conn));
	$check_web->bind_param("s", $website_link);
	$check_web->execute();
	$result = $check_web->get_result();
	if ($result->num_rows > 0) {
		echo "Url: " .$website_link . " is already registered";
		exit();
	}

	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo "Invalid Email";
		exit();
	}

	$check_list = $conn->prepare("SELECT * FROM members_list WHERE email = ? ") or die(mysqli_error($conn));
	$check_list->bind_param("s", $email);
	$check_list->execute();
	$result = $check_list->get_result();
	if ($result->num_rows > 0) {
		echo $email . " Already Registered";
		exit();
	}

	$SQL = $conn->prepare("INSERT INTO web_directory (user_email, website_category, website_link, user_ip, plan, price, end_date) VALUES (?, ?, ?, ?, ?, ?, ?) ") or die(mysqli_error($conn));
	$SQL->bind_param("sssssss",$email, $website_category, $website_link, $ip_address, $plan, $price, $expiry_date);
	$SQL->execute();
	
	$password = password_hash($generatedPassword, PASSWORD_DEFAULT);

	$QUERY = $conn->prepare("INSERT INTO members_list (username, email, password) VALUES (?, ?, ?) ") or die(mysqli_error($conn));
	$QUERY->bind_param("sss", $username, $email, $password);

	$site_name = preg_replace("#[^0-9a-zA-Z_]#", "_" , goodUrl($website_link));

	$sql = "CREATE TABLE IF NOT EXISTS weblifjy_web_listers.$site_name (
          id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          site_name VARCHAR(30) NOT NULL,
          page_views TEXT NOT NULL,
          pageLoadTime VARCHAR(200) NOT NULL,
          device_type VARCHAR(100) NOT NULL,
          user_ip VARCHAR(50) NOT NULL,
          countryName VARCHAR(200) NOT NULL,
          operating_system TEXT NOT NULL,
          activity_time DATETIME NOT NULL
          )
          ";

    if ($conn->query($sql) === TRUE) {
       // echo "Table ".$site_name." created successfully<br>";
    } else {
        echo "Error creating table: " . $conn->error;
    }

	if($QUERY->execute()){
		$userlast_id = $QUERY->insert_id;
		// Send an Email
		include_once "../PHPMailer/PHPMailer.php";
		include_once "../PHPMailer/Exception.php";
		include_once "../PHPMailer/SMTP.php";
		include_once "../PHPMailer/OAuth.php";

		$message = '

          	<!DOCTYPE html>
			<html>
			<head>
				<title>'.$username.'</title>
				<meta name="viewport" content="width=device-width, initial-scale=1.0">
				<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
				<style>
					.mail-div {
						box-shadow: 0 0 5px;
						padding: 20px;
						width: 60%;
						margin:50px auto;
						border-radius: 5px;
					}
					h1 span {
						color: #6499cd;
					}
					.icon_image {
						width: 100px;
						height: 100px;
						float: right;
						-webkit-animation:spin 5s linear infinite;
					    -moz-animation:spin 5s linear infinite;
					    animation:spin 5s linear infinite;
					}
					@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
					@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
					@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }

					@media(max-width: 768px){
						.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
					}
					.codeArea {
            			background: #6499cd;
            			color: #fff;
            			padding: 10px;
            			border-radius: 5px;
            			font-family: "Source Code Pro", monospace;
            		}
            		.codeArea textarea{
            			margin: 5px auto;
            			width: 98%;
            			height: 60px;
            			resize: none;
            			border: none;
            			padding: 10px;
            			color: #fff;
            		}
				</style>
			</head>
			<body>
				
				<div class="mail-div">
					<img src="https://weblister.co/images/icon_new.png" class="icon_image" alt="Icon">
					<h1>Welcome: <span> '.$username.' </span></h1>
					<h4>Login Details</h4><hr>
					<h4>Email: '.$email.' and Your Password is: <b><i>'.$generatedPassword.'</b></i></h4>
					<h5> </h5>
					<a href="https://weblister.co/activation?userid='.$userlast_id.'&email='.$email.'&pass='.$password.'">Activate your account by clicking here</a>
					<p>You can also copy this :https://weblister.co/activation?userid='.$userlast_id.'&email='.$email.'&pass='.$password.' link and paste it into your browser.</p>
					<h4>Welcome to weblister. Add your websites links and also check other sites that are similar to what yours is about.</h4>

					<div class="codeArea">
						<h4 align="center">Please Add this Script in your HTML head Tags for our service to work on your sites</h4><br>
						<textarea readonly disabled="disabled" class="code-text"><script type="text/javascript" src="https://weblister.co/js/extension.js?url='.$website_link.'"></script></textarea>
						<br><br>
					</div>
				</div>
			</body>
			</html>
          ';
		$mail = new PHPMailer();
		$mail->Host = "weblister.co";
		$mail->isSMTP();
		$mail->SMTPAuth = true;
		$mail->Username = "info@weblister.co";
		$mail->Password = "!vNQ6rQbQXMX";
		$mail->SMTPSecure = "ssl";//TLS
		$mail->Port = 465; //TLS port= 587
		$mail->addAddress($email, $username); //$inst_admin_email;
		$mail-> setFrom("info@weblister.co", "Website Listing Success");
		$mail-> Subject = " Website Listing Success";
		$mail->isHTML(TRUE);
		// $mail->SMTPDebug = 2;
		$mail->Body = $message;
		if($mail->send()){
		echo "Website: ".goodUrl($website_link)." Listed, Check your <b>".$email."</b>  inbox / spam for an account verification link and login details\n
			
		";

		}else{

		} 
	}
}
?>