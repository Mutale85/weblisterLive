<?php 
include("db.php");

if(isset($_POST['DBNAME'])){
    $DB = $_POST['DBNAME'];
    $sql = mysqli_query($conn, "SELECT * FROM ".$DB." GROUP BY page_views ORDER BY activity_time ") or die(mysqli_error($conn));
    $siteName = preg_replace("#[^a-z0-9A-Z]#", ".", $DB);
    $output = "";
	if (mysqli_num_rows($sql) > 0) {?>
	   <div style="overflow-x:auto;">
	        <table id="pages">
                <tr>
                    <th>Page </th>
                    <th>Visitors</th>
                </tr>
	<?php
	    
		foreach ($sql as $row) {
            $page_link = $row['page_views'];
            $page_load_speed = $row['pageLoadTime'];
            $url_link = preg_replace("(^https?://)", "", $page_link );
            
		?>  
	        <tr>
	            <td><?php echo  $url_link;?></td>
	            <td><?php echo countViewsPerPage($conn, $DB, $page_link)?></td>
	        </tr>
		<?php
			    
		}
			// Unique visitor
    	$query = mysqli_query($conn, "SELECT COUNT(user_ip) AS ip_add FROM ".$DB." GROUP BY user_ip ") or die(mysqli_error($conn));;
    	$count_Ips = mysqli_num_rows($query);

	?>          <tfoot>
	                <tr>
	                    <th>Unique Visitors</th>
	                    <th><?php echo  $count_Ips; ?></th>
	                </tr>
	                <tr>
	                    <th>Total Visitors</th>
	                    <th><?php echo countTotalSiteView($conn, $DB)?></th>
	                </tr>
	            </tfoot>
		    </table>
        </div>
        <style>
            #pages {
              font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
              border-collapse: collapse;
              width: 100%;
            }
            
            #pages td, #pages th {
              border: 1px solid #ddd;
              padding: 8px;
            }
            
            #pages tr:nth-child(even){background-color: #f2f2f2;}
            
            #pages tr:hover {background-color: #ddd;}
            
            #pages th {
              padding-top: 12px;
              padding-bottom: 12px;
              text-align: left;
              /*background-color: #4CAF50;*/
              background-color:#6499cd;
              color: white;
            }
        </style>
    <?php
    }
}
?>