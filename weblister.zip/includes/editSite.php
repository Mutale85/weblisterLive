<?php
include 'db.php';
if (isset($_POST['site_id'])) {
	$site_id = $_POST['site_id'];
	$query = $conn->prepare("SELECT * FROM web_directory WHERE website_link = ? ") or die(mysqli_error($conn));
	$query->bind_param("s", $site_id);
	$query->execute();
	$res = $query->get_result();
	foreach ($res as $row) {
		echo json_encode($row);
	}
}
?>