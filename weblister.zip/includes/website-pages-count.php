<?php
include 'db.php';

if (isset($_POST['website_url'])) {
	$URL = $_POST['website_url'];
// 	echo getLinks($conn,$URL);
	echo pageLinks($conn,$URL);
}