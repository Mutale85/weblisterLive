<?php
include("db.php");
if(isset($_POST['website_link'])){
    $website_link = $_POST['website_link'];
    
?>
<div id="preview"></div>
<script>
    bioMp(document.getElementById('preview'), {
		url: '<?php echo $website_link?>',
	    image: 'wmp/images/iphone6_front_black.png',
	    width: 330,
	});

</script>
<?php

}
?>