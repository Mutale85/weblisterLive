<?php
include 'db.php';
if (isset($_POST['site_url'])) {
	$site_url = $_POST['site_url'];
	$clicks = $_POST['clicks'];
	$operating_system =  mysqli_real_escape_string($conn, filter_var($_POST['operating_system'], FILTER_SANITIZE_STRING));

	$update = $conn->prepare("UPDATE web_directory SET clicks = clicks + ? WHERE website_link = ? ") or die(mysqli_error($conn));
	$update->bind_param("ss", $clicks, $site_url);
	$update->execute();

	require_once '../mobile_detect/Mobile_Detect.php';
	$detect = new Mobile_Detect;
	$device = "";
	if( $detect->isMobile()){
		$device = "Mobile-Phone";
	}elseif ($detect->isTablet()) {
		$device = "Tablet";
	}else{
		$device = "Computer";
	}
	$ip_address = getUserIpAddr();
	
	$sql = $conn->prepare("INSERT INTO browserData (site_url, clicks, ip_address, operating_system, device_type) VALUES(?, ?, ?, ?, ?) ") or die(mysqli_error($conn));
	$sql->bind_param("sssss", $site_url, $clicks, $ip_address, $operating_system, $device);
	$sql->execute();
	// We can send a weekly email to user on how many clicks they get in a week.
}

?>