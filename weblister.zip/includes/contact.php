<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include_once "../PHPMailer/PHPMailer.php";
include_once "../PHPMailer/Exception.php";

// Load Composer's autoloader
include("../includes/db.php");

if (isset($_POST['name'])) {
    $name 		= filter_var($_POST['name'], FILTER_SANITIZE_STRING); 
	$email 		= filter_var($_POST['email'], FILTER_SANITIZE_STRING); 
	$subject 	= filter_var($_POST['subject'], FILTER_SANITIZE_STRING);	 
	$message 	= filter_var($_POST['message'], FILTER_SANITIZE_STRING);	 
	$attachment = $_FILES['attachment']['name'];
	$temp_name 	= $_FILES['attachment']['tmp_name'];
	$destination = "../mailedFiles/".basename($attachment);
	
	if(isset($_FILES['attachment']['name']) && $_FILES['attachment']['name'] != ""){
	   move_uploaded_file($temp_name, $destination); 
	}else{
	    $destination = "";
	}
	
	$send = "";

    // $to = "mutamuls@gmail.com";
    $to = 'info@weblister.co';
	$mail = new PHPMailer();
	$mail->addAddress($to);
	$mail->setFrom($email);
	$mail->Subject = $subject;
	$mail->Body = $message;
	$mail->isHTML(true);
	$mail->addAttachment($destination);
// 	$mail->SMTPDebug = 2;

    if($mail->send())
        $send = "Email sent ";
    else
       $send = $mail->ErrorInfo; 
	
	echo $send;	
}

?>