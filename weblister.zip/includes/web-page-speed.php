<?php
	if (isset($_GET['callback'])) {
		include 'db.php';
		require_once '../mobile_detect/Mobile_Detect.php';

		$pageLoadTime 		= preg_replace("#[^0-9.a-zA-Z ]#", "", $_GET['pageloadTime']);
		$pageUrl 			= filter_var($_GET['pageUrl'], FILTER_SANITIZE_URL);
		$site_name			= preg_replace("#[^0-9a-zA-Z_]#", "_" , goodUrl($_GET['URL']));
		$operating_system	= $_GET['operating_system'];
		$ip_address = getUserIpAddr();
		$geo = unserialize( file_get_contents('http://www.geoplugin.net/php.gp?ip=' . $ip_address) );
		$countryName = $geo["geoplugin_countryName"];
		
		$detect = new Mobile_Detect;
		$device_type = "";
		if( $detect->isMobile()){
			$device_type = "Mobile-Phone";
		}elseif ($detect->isTablet()) {
			$device_type = "Tablet";
		}else{
			$device_type = "Computer";
		}

		$activity_time =  date("Y:m:d h:i:s");
		
		$insert = $conn->prepare("INSERT INTO $site_name (site_name, page_views, pageLoadTime, device_type, user_ip, countryName, operating_system, activity_time) VALUES(?, ?, ?, ?, ?, ?, ?, ?)  ") or die(mysqli_error($conn));
		$insert->bind_param("ssssssss", $site_name, $pageUrl, $pageLoadTime, $device_type, $ip_address, $countryName, $operating_system, $activity_time);
		if($insert->execute()){
// 			echo "Done";
		}else{
			// echo "Error";
		}
	}
	
	/*
        geoplugin_request
        geoplugin_status
        geoplugin_credit
        geoplugin_city
        geoplugin_region
        geoplugin_areaCode
        geoplugin_dmaCode
        geoplugin_countryCode
        geoplugin_countryName
        geoplugin_continentCode
        geoplugin_latitude
        geoplugin_longitude
        geoplugin_regionCode
        geoplugin_regionName
        geoplugin_currencyCode
        geoplugin_currencySymbol
        geoplugin_currencySymbol_UTF8
        geoplugin_currencyConverter
    */
?>