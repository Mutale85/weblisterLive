<?php
include 'db.php';
if (isset($_POST['remove_url_link'])) {
	$remove_url_link = $_POST['remove_url_link'];
	$query = $conn->prepare("DELETE FROM web_directory WHERE website_link = ? ") or die(mysqli_error($conn));
	$query->bind_param("s", $remove_url_link);
	if($query->execute()){
		$site_name = preg_replace("#[^0-9a-zA-Z_]#", "_" , goodUrl($remove_url_link));
		$sql = mysqli_query($conn, "DROP TABLE $site_name");
		echo $remove_url_link . " Deleted";
		exit();
	}else{
		echo "Error";
	}
}

if(isset($_POST['site_owner_email'])){
    $site_owner_email = filter_var($_POST['site_owner_email'], FILTER_SANITIZE_EMAIL);
    $site_link = filter_var($_POST['site_link'], FILTER_SANITIZE_URL);
    $DB = preg_replace("#[^0-9a-zA-Z_]#", "_" , goodUrl($site_link));
    $query = $conn->prepare("DELETE FROM web_directory WHERE website_link = ? ") or die(mysqli_error($conn));
	$query->bind_param("s", $site_link);
	$query->execute();
	$sql = $conn->prepare("DELETE FROM members_list WHERE email = ? ") or die(mysqli_error($conn));
	$sql->bind_param("s", $site_owner_email);
	if($sql->execute()){
	   $sql = mysqli_query($conn, "DROP TABLE $DB");
	   echo $site_link . " Deleted";
	   exit(); 
	}
	
}
