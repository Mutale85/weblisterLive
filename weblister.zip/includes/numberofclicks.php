<?php
$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$start = $time;
include 'db.php';
$clicks = $site_name = $datenow = $number_of_clicks = "";
if (isset($_POST['numberofclicks'])) {
	$numberofclicks = $_POST['numberofclicks'];
	$query = $conn->prepare("SELECT * FROM browserData WHERE site_url = ? ") or die(mysqli_error($conn));
	$query->bind_param("s", $numberofclicks);
	$query->execute();
	$result = $query->get_result();
	$number_of_clicks = $result->num_rows;
	if ($result->num_rows > 0) {
		
		foreach ($result as $row) {
			$clicks .= $row['clicks'].",";
			$click_date = $row['click_date'];
			$date = date("D", strtotime($click_date));
			$datenow .=  '\''.$date.'\', ';
			
		}
		
	}else{
		$clicks = 0;
	}
	$clicks = trim($clicks, ',');
	$datenow = trim($datenow, ",");
	
	?>
	<div class="col-md-12">
		<h2 style="color: #fff;"><?php echo goodUrl($numberofclicks); ?></h2>
		<canvas id="myChart"></canvas>
	</div>
	<script type="text/javascript">

		window.chartColors = {
			red: 'rgb(255, 99, 132)',
			orange: 'rgb(255, 159, 64)',
			yellow: 'rgb(255, 205, 86)',
			green: 'rgb(75, 192, 192)',
			blue: 'rgb(54, 162, 235)',
			purple: 'rgb(153, 102, 255)',
			grey: 'rgb(231,233,237)'
		};
		var ctx = document.getElementById('myChart').getContext('2d');
		var myChart = new Chart(ctx, {
		  type: 'line',
		  data: {
		    labels: [
		    	<?php echo $datenow;?>
		    ],
		    datasets: [{
			      	label:  'Total Clicks: <?php echo $number_of_clicks;?>',
			      	backgroundColor: 'rgb(255, 99, 132)',
					borderColor: 'rgb(255, 79, 116)',
					borderWidth: 2,
					pointBorderColor: false,
					fill: false,
					lineTension: .4,
			      	data: [<?php echo $clicks; ?>],
			    } 
		    ]
		  }
		});	
	</script>
	<?php
	// piechart by device 
	
	$QUERY = $conn->prepare("SELECT * FROM browserData WHERE site_url = ? ") or die(mysqli_error($conn));

	$QUERY->bind_param("s", $numberofclicks);
	$QUERY->execute();

	$res = $QUERY->get_result();
	if ($res->num_rows > 0) {
		foreach ($res as $row) {
			$site_name .= '['.'\''.$row['device_type'].'\''.','. $row['clicks'].'],';
		}
		
	}else{
		$site_name = ['Devices', 0];
	}

	$computer = "Accessed from Computer";
	$sql = $conn->prepare("SELECT COUNT(device_type) AS computer_device FROM `browserData` WHERE device_type = ? AND site_url = ? ") or die(mysqli_error($conn));
	$sql->bind_param("ss", $computer, $numberofclicks);
	$sql->execute();
	$result = $sql->get_result();
	$row = $result->fetch_assoc();
	$count_computers = $row['computer_device'];

	// Count Clicks on Phone
	$phone_device = "Mobile Phone";
	$sql_mobile = $conn->prepare("SELECT COUNT(device_type) AS phone_device FROM `browserData` WHERE device_type = ? AND site_url = ? ") or die(mysqli_error($conn));
	$sql_mobile->bind_param("ss", $phone_device, $numberofclicks);
	$sql_mobile->execute();
	$result = $sql_mobile->get_result();
	$row = $result->fetch_assoc();
	$count_mobiles = $row['phone_device'];

	

	?>
	<!-- <?php echo $site_name;?> -->
	<div class="col-md-12">
		<div class="PieChartClass">
			
			<canvas id="piechart"></canvas>
		</div>
	</div>
	<script type="text/javascript">
		window.chartColors = {
			red: 'rgb(255, 99, 132)',
			orange: 'rgb(255, 159, 64)',
			yellow: 'rgb(255, 205, 86)',
			green: 'rgb(75, 192, 192)',
			blue: 'rgb(54, 162, 235)',
			purple: 'rgb(153, 102, 255)',
			grey: 'rgb(231,233,237)'
		};
		var ctx = document.getElementById('piechart').getContext('2d');
		var myDoughnutChart = new Chart(ctx, {
		    type: 'doughnut',
		    data: {
		    	datasets:[{
		    		data:[<?php echo $count_computers;?>, <?php echo $count_mobiles?>],
		    		// backgroundColor: "rgba(100, 153, 205, 1)",
		    		backgroundColor: [
		    			window.chartColors.red,
				        // window.chartColors.orange,
				        // window.chartColors.yellow,
				        window.chartColors.green,
				        // window.chartColors.blue,
		    		],
		    	}],

		    	labels:[
		    		'Computers: <?php echo $count_computers;?>',
		    		'Mobile: <?php echo $count_mobiles?>',
		    	]
		    },
		    options: {
		    	title: {
					display: true,
					text: '<?php echo goodUrl($numberofclicks); ?>'
				},
		    	responsive:true,
		    }

		});

		
	</script>
	<style>
		.PieChartClass {
			margin-top: 60px;
			margin-bottom: 60px;	
		}
	</style>
	<?php
	$conn->close();
}

$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 4);
// echo 'Generated in '.$total_time.' seconds.';
?>
