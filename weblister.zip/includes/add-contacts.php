<?php
include 'db.php';

if (isset($_POST['phonenumber'])) {
	$phonenumber = filter_var($_POST['phonenumber'], FILTER_SANITIZE_STRING);
	$user_email = filter_var($_POST['user_email'], FILTER_SANITIZE_STRING);

	$update = $conn->prepare("UPDATE members_list SET phonenumber = ? WHERE email = ?") or die(mysqli_error($conn));
	$update->bind_param("ss", $phonenumber, $user_email);
	$update->execute();
	if ($update) {
		echo getUserContacts($conn, $user_email);
	}	
}
if(isset($_POST['userEmail'])){
    echo getUserContacts($conn, $_SESSION['email']);
}
?>