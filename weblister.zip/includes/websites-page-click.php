<?php
	include("db.php");
	if (isset($_POST['numberofClicks'])) {

		echo getAllMembersWebsites($conn, $_SESSION['email']);
	}
?>