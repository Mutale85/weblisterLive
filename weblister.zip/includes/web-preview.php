<?php
include 'db.php';
if (isset($_POST['previewWebsite'])) {
	$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ");
	$query->bind_param("s", $_SESSION['email']);
	$query->execute();
	$result = $query->get_result();
	if ($result->num_rows > 0) {
			
		foreach ($result as $row) {
			$URL = $row['website_link'];
			?>
			<div class="well">
				<h4 class="text-center"><?php echo strtoupper(goodUrl($URL)); ?></h4><hr> 	
				<?php echo preview_site_in_php($URL)?>
			</div>
		<?php
		}
	}
}

if (isset($_POST['site_url'])) {
	$site_url = $_POST['site_url'];
	?>
	<div class="well">
		<h4 class="text-center"><?php echo strtoupper(goodUrl($site_url)); ?></h4><hr> 	
		<?php echo preview_site_in_php($site_url)?>
	</div>
	<?php
}

?>