<?php
function getUserIpAddr(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}


function UserName($conn, $user_id){
	$output = "";

	$query = $conn->prepare("SELECT * FROM members_list WHERE id = ? ") or die(mysqli_error($conn));
	$query->bind_param('i', $user_id);
	$query->execute();
	$result = $query->get_result();
	foreach ($result as $row) {
		$output = $row['username'];
	}

	return $output;
}

function MySites($conn, $user_email){
	$Query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ") or die(mysqli_error($conn));
	$Query->bind_param('s', $user_email);
	$Query->execute();
	$result = $Query->get_result();
	if ($result->num_rows > 0) {
		$rows = $result->fetch_assoc();
		echo "<div class='mywebsites'>";
		echo "<ol>";
		foreach ($result as $row) { ?>
			<div class="mysites-div">
				<h4 class="">Category: <?php echo $row['website_category']?></h4>
				<li>
					<a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a> |
					<button type="button" class="btn btn-default btn-sm edit_site" id="<?php echo $row['web_id']?>"><i class="fa fa-pencil-square-o"></i></button> | 
					<button type="button" class="btn btn-default btn-sm preview_site" id="<?php echo $row['website_link']?>">Preview</button>
					<button type="button" class="btn btn-default btn-sm numberofclicks" id="<?php echo $row['website_link']?>">Clicks</button>
				</li>

				<a href="" class="view_other_sites" id="<?php echo $row['website_category']?>" data-site="<?php echo $row['website_link']?>">View Similar Sites</a>
			</div>
			<hr>
		<?php
		}
		echo "</ol>";
		echo "</div>";

	}else{
		echo "<div class='well'>
				<h4 class='text-center'>Add your website link and start viewing other websites which are similar to yours</h4>
			</div>";
	}
}


function MyListedSites($conn, $user_email){
	$Query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ") or die(mysqli_error($conn));
	$Query->bind_param('s', $user_email);
	$Query->execute();
	$result = $Query->get_result();
	if ($result->num_rows > 0) {
		$rows = $result->fetch_assoc();
		foreach ($result as $row) { 
		$url = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($row['website_link']));
		?>
        <style>
        .dropbtn {
            background-color: #6499cd;
            color: white;
            padding: 8px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            width:100%;
            border-radius:5px;
        }
        
        .dropdown-div {
            position: relative;
            display: inline-block;
            width:100%;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            width:100%;
        }
        
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        
        .dropdown-content a:hover {background-color: #f1f1f1}
        
        /*.dropdown:hover .dropdown-content {*/
        /*    display: block;*/
        /*}*/
        
        .dropdown-div:hover .dropbtn {
            background-color: #1a3864;
        }
        </style>
		<div class="col-md-6">
			<div class="dropdown-div">
			    <button onclick="myFunction('<?php echo $row['web_id']?>')" class="dropbtn" id="btn_<?php echo $row['web_id']?>"><?php echo strtoupper( goodUrl($row['website_link']))?> <span class="caret"></span></button>
				<div class="dropdown">
                    <div class="dropdown-content" id="myDropdown_<?php echo $row['web_id']?>">
                		<a href="" class="devices_used" id="<?php echo $row['website_link']?>" ><i class="fa fa-circle-o fa-fw"></i> DEVICES USED</a>
                		<a href="" class="preview_site" id="<?php echo $row['website_link']?>"><i class="fa fa-square-o fa-fw"></i>META TAGS PREVIEW</a>
                		<a href="" class="country_details" id="<?php echo $url?>"><i class="fa fa-globe fa-fw"></i> COUNTRIES </a>
                		<a href="" class="page_details" id="<?php echo $url?>"><i class="fa fa-bar-chart fa-fw"></i> PAGE DETAILS</a>
                		<a href="" class="compare_sites" id="<?php echo $row['website_link']?>" data-category="<?php echo $row['website_category']?>"><i class="fa fa-globe fa-fw"></i> SIMILAR WEBSITES</a>
                		<a href="" class="mobile_preview" id="<?php echo $row['website_link']?>"><i class="fa fa-mobile-phone fa-fw"></i> MOBILE PREVIEW</a>
                		<a href="" class="edit_site" id="<?php echo $row['website_link']?>"><i class="fa fa-pencil-square-o fa-fw"></i> EDIT WEBSITE</a>
                		<a href="" class="remove_url" id="<?php echo $row['website_link']?>"><i class="fa fa-trash fa-fw"></i> DELETE WEBSITE </a>
                		<a href="">TOTAL VIEWS: <?php echo countDeviceUsesAsMobilePhone($conn, $url) + countDeviceUsesAsTablet($conn, $url) + countDeviceUsesAsComputer($conn, $url) ?> </a>
                    </div>
                </div>
			</div>
			<br><br><br>
		</div>
		<script>
            /* When the user clicks on the button, 
            toggle between hiding and showing the dropdown content */
            function myFunction(id) {
                document.getElementById("myDropdown_"+id).classList.toggle("show");
            }
            
            // Close the dropdown if the user clicks outside of it
            window.onclick = function(event) {
              if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                  var openDropdown = dropdowns[i];
                  if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                  }
                }
              }
            }
        </script>
		<?php
		}

	}else{
		
	}
}
function MobiePreviewSite($conn, $user_email){
	$Query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ") or die(mysqli_error($conn));
	$Query->bind_param('s', $user_email);
	$Query->execute();
	$result = $Query->get_result();
	if ($result->num_rows > 0) {
		$rows = $result->fetch_assoc();
		foreach ($result as $row) { 
		$URL = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($row['website_link']));
		?>
		    <div class="pagelinkDiv">
		        <h4><?php echo strtoupper(goodUrl($row['website_link']))?></h4>
				<a href="mobile-preview/<?php echo base64_encode($row['website_link']); ?>" class="btn btn-success btn-sm"> Preview Site</a>
			</div>
		<?php
		}

	}else{
		
	}
}

//  PREVIEW WEBSITE WITH META TAGS
function extract_tags_from_url($url) {
	$tags = array();

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

	$contents = curl_exec($ch);
	curl_close($ch);

	if (empty($contents)) {
		return $tags;
	}

	if (preg_match_all('/<meta([^>]+)content="([^>]+)>/', $contents, $matches)) {
		$doc = new DOMDocument();
		$doc->loadHTML('<?xml encoding="utf-8" ?>' . implode($matches[0]));

		$nodes = $doc->getElementsByTagName('title');
	//get and display what you need:
		if ($nodes->length>0) { 			
			$title = $nodes->item(0)->nodeValue; 		
		}

		$tags = array();
		foreach($doc->getElementsByTagName('meta') as $metaTag) {
  			if($metaTag->getAttribute('name') != "") {
    			$tags[$metaTag->getAttribute('name')] = $metaTag->getAttribute('content');
  			}
  			elseif ($metaTag->getAttribute('property') != "") {
    			$tags[$metaTag->getAttribute('property')] = $metaTag->getAttribute('content');
  			}
		}
		}

		return $tags;
}

function preview_site_in_php($_url){
	$web = (extract_tags_from_url($_url));

	$url_web = json_encode($web);

	$json = json_decode($url_web, true);
	if(array_key_exists('title', $json)){
		$title = $json['title'];
	}elseif(array_key_exists("og:title", $json)){
		$title = $json['og:title'];
	}else{
		$title =  "Website has no meta property og:title";
	}
 
	if(array_key_exists('description',$json)){
		$description = $json['description'];
	}elseif(array_key_exists('og:description',$json)) {
		$description = $json['og:description'];
	}else{
		$description = "Website has no meta property og:description<br>
		";
	}

	if(array_key_exists('keywords',$json) ){
		$keywords = $json['keywords'];
	}elseif(array_key_exists('og:keywords',$json)) {
		$keywords = $json['og:keywords'];
	}else{
		$keywords = "Website has no meta property og:keywords";
	}

	if(array_key_exists('image',$json)){
		$image = '<img src="'.$json['image'].'" class="img-responsinve img-thumbnails previewImage">';
	}elseif(array_key_exists('og:image',$json)) {
		$image = '<img src="'.$json['og:image'].'" class="img-responsinve img-thumbnails PreviewImage">';
	}else{
		$image = "Website has no meta og:image image";
	}
	echo "<div class='webPreview'>";
	echo "<h3>".$title."</h3><br>";
	echo $image."<br>";
	echo "<p>".nl2br($description)."</p>";
	echo "</div>";
}

// making the domain name look good.

function goodUrl($url_nice){
	$input = $url_nice;

// in case scheme relative URI is passed, e.g., //www.google.com/
	$input = trim($input, '/');

	// If scheme not included, prepend it
	if (!preg_match('#^http(s)?://#', $input)) {
	    $input = 'http://' . $input;
	}

	$urlParts = parse_url($input);

	// remove www
	$domain = preg_replace('/^www\./', '', $urlParts['host']);
	return $domain;
}


function websiteUptime($url){
    // Check, if a valid url is provided
    if(!filter_var($url, FILTER_VALIDATE_URL)){
        return false;
    }

    // Initialize cURL
    $curlInit = curl_init($url);
    
    // Set options
    curl_setopt($curlInit,CURLOPT_CONNECTTIMEOUT,10);
    curl_setopt($curlInit,CURLOPT_HEADER,true);
    curl_setopt($curlInit,CURLOPT_NOBODY,true);
    curl_setopt($curlInit,CURLOPT_RETURNTRANSFER,true);

    // Get response
    $response = curl_exec($curlInit);
    
    // Close a cURL session
    curl_close($curlInit);

    return $response?true:false;
}

function passwordGenerate() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $password = array(); 
    $alphabet_Length = strlen($alphabet) - 1;
    for ($i = 0; $i < 9; $i++) {
        $new = rand(0, $alphabet_Length);
        $password[] = $alphabet[$new];
    }
    return implode($password); //turn the array into a string
}

function getAllMembersWebsites($conn, $user_email){
	$output = "";
	$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ") or die(mysqli_error($conn));
	$query->bind_param("s", $user_email);
	$query->execute();
	$result = $query->get_result();
	foreach ($result as $row) {
		$url = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($row['website_link']));
		?>

		<!--<a href="views/<?php echo $url?>" id="<?php echo $row['website_link']?>">-->
		<!--	<?php echo strtoupper( goodUrl($row['website_link']))?>	-->
		<!--</a>-->
		<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo strtoupper( goodUrl($row['website_link']))?> <span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><i class="fa fa-laptop fa-fw"></i> Computer Views: <?php echo countDeviceUsesAsComputer($conn, $url); ?></li>
        		<li><i class="fa fa-tablet fa-fw"></i> Tablet Views: <?php echo countDeviceUsesAsTablet($conn, $url); ?></li>
        		<li><i class="fa fa-mobile-phone fa-fw"></i> Mobile-Phone Views: <?php echo countDeviceUsesAsMobilePhone($conn, $url); ?></li>
        		<li><i class="fa fa-globe fa-fw"></i><a href="site-traffic-source/<?php echo $url?>">Trafic Source</a></li>
        		<li><i class="fa fa-bar-chart fa-fw"></i><a href="views/<?php echo $url?>"  id="<?php echo $row['website_link']?>">Analyze Page Details</a></li>
            </ul>
        </li>
		<!--<p><i class="fa fa-laptop fa-fw"></i> Computer Views: <?php echo countDeviceUsesAsComputer($conn, $url); ?></p>-->
		<!--<p><i class="fa fa-tablet fa-fw"></i> Tablet Views: <?php echo countDeviceUsesAsTablet($conn, $url); ?></p>-->
		<!--<p><i class="fa fa-mobile-phone fa-fw"></i> Mobile-Phone Views: <?php echo countDeviceUsesAsMobilePhone($conn, $url); ?></p>-->
		<!--<p><i class="fa fa-globe fa-fw"></i><a href="site-traffic-source/<?php echo $url?>">Trafic Source</a></p>-->
		<!--<p><i class="fa fa-bar-chart fa-fw"></i><a href="views/<?php echo $url?>"  id="<?php echo $row['website_link']?>">Analyze Page Details</a></p>-->
		<!--<b><i class="fa fa-check-square-o fa-fw"></i> Total Views: <?php echo countURLClicks($conn, $url)?></b>-->
		<hr>
	<?php
	}
}

// count number of clicks per website and devices used to access the website

function countURLClicks($conn, $Url) {
	$output = "";
	$query = mysqli_query($conn, "SELECT COUNT(page_views) AS total_views FROM $Url ") or die(mysqli_error($conn));

	foreach ($query as $row) {
		$output .= $row['total_views'];
	}
	return $output;
}


function countDeviceUsesAsComputer($conn, $URL){
	$output = "";
	$sql = mysqli_query($conn, " SELECT COUNT(device_type) AS device FROM $URL WHERE device_type = 'Computer' ") or die(mysqli_error($conn)) ;
	foreach ($sql as $row) {
		$output .= $row['device'];
	}
	return $output;
}

function countDeviceUsesAsTablet($conn, $URL){
	$output = "";
	$sql = mysqli_query($conn, " SELECT COUNT(device_type) AS device FROM $URL WHERE device_type = 'Tablet' ") or die(mysqli_error($conn)) ;
	foreach ($sql as $row) {
		$output .= $row['device'];
	}
	return $output;
}

function countDeviceUsesAsMobilePhone($conn, $URL){
	$output = "";
	$sql = mysqli_query($conn, " SELECT COUNT(device_type) AS device FROM $URL WHERE device_type = 'Mobile-Phone' ") or die(mysqli_error($conn)) ;
	foreach ($sql as $row) {
		$output .= $row['device'];
	}
	return $output;
}


// check website response time -------

function checkWebsitePageResponseTime($url){
	$output = "";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	if(curl_exec($ch)) {
		$info = curl_getinfo($ch);
		$output .= strtoupper(goodUrl($info['url'])).': <span class="text-success">' . $info['total_time'] . ' seconds</span> ';
	}else{
		$output.= strtoupper(goodUrl($url)). ': No Response Time Gotten';
	}
	curl_close($ch);
	return $output;
}

function checkWebResponseTime($url){
	$output = "";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	if(curl_exec($ch)) {
		$info = curl_getinfo($ch);
		$output .= '<span class="text-success">' . $info['total_time'] . ' S</span> ';
	}
	curl_close($ch);
	return $output;
}

// test url existence -----
function urlExistence($url){
	$output = "";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, true);
	curl_setopt($ch, CURLOPT_NOBODY, true);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$data = curl_exec($ch);
	curl_close($ch);
	$output = $data;

	return $output;
}

/// get website links -----

function getLinks($conn, $URL) {
	$output = "";
	$html = file_get_contents($URL);
	//Create a new DOM document
	$dom = new DOMDocument;

	//Parse the HTML. The @ is used to suppress any parsing errors
	//that will be thrown if the $html string isn't valid XHTML.
	@$dom->loadHTML($html);

	//Get all links. You could also use any other tag name here,
	//like 'img' or 'table', to extract other tags.
	$links = $dom->getElementsByTagName('a');
	$N_URL = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($URL));
	//Iterate over the extracted links and display their URLs
	foreach ($links as $link){
		$output .= "<div class='well'>"; 
	    $output .= '<p>'.$link->getAttribute('href'). '</p>';

	    $page_link =  $link->getAttribute('href'); 
	    //Count Number of clicks each Page Has
	    $sql = mysqli_query($conn, "SELECT COUNT(page_views) AS page_link_count, pageLoadTime, id FROM ".$N_URL." WHERE page_views = '$page_link' ") or die(mysqli_error($conn));
		if (mysqli_num_rows($sql) > 0) {
			foreach ($sql as $row) {
				$output .= "Views: ".$row['page_link_count']."<br>";
				$output .= "Load Speed: <em>". $row['pageLoadTime']."</em>";
			}
		}
			// $output.="<button class='btn btn-danger btn-xs pull-right delete_page_view' id='".$row['id']."'> <i class='fa fa-trash'></i></button>";
		$output .="</div>";
	}
	$sql_query = mysqli_query($conn, "SELECT COUNT(page_views) AS total_clicks FROM ".$N_URL." ") or die(mysqli_error($conn));
	// $output .= "Response Time : ".checkWebResponseTime($page_link);
	$row = mysqli_fetch_assoc($sql_query);
	
		echo   "<h4>".strtoupper(goodUrl($URL)). "<b> - Total Views: " .$row['total_clicks']."</h4><br><br>";
	return $output;
}

function getUserContacts($conn, $user_email){
	$output = "";
	$sql = $conn->prepare("SELECT * FROM  members_list WHERE email = ? ") or die(mysqli_error($conn));
	$sql->bind_param("s", $user_email);
	$sql->execute();
	$result = $sql->get_result();
	foreach ($result as $row) {
		if ($row['phonenumber'] == "") {
			$output .= $row['email'];
		}else{
			$output .= "<h4>Email: ". $row['email']."</h4>";
			$output .= "<h4>Phone: ". $row['phonenumber']."</h4>";	
		}
	}
	return $output;
}

//pagelinks

function pageLinks($conn, $URL){

	$html = file_get_contents($URL);

	$doc = new DOMDocument();
	@$doc->loadHTML($html); //helps if html is well formed and has proper use of html entities!

	$xpath = new DOMXpath($doc);

	$nodes = $xpath->evaluate('/html/body//a');
	$N_URL = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($URL));
	foreach($nodes as $node) {
	    $page_url = $node->getAttribute('href');

	    $output .= "<div class='well'>"; 
	    $output .= '<p>'.$node->getAttribute('href'). '</p>';

	    $sql = mysqli_query($conn, "SELECT COUNT(page_views) AS page_link_count, pageLoadTime, id FROM ".$N_URL." WHERE page_views = '$page_url' ") or die(mysqli_error($conn));
		if (mysqli_num_rows($sql) > 0) {
			foreach ($sql as $row) {
				$output .= "Views: ".$row['page_link_count']."<br>";
				$output .= "Load Speed: <em>". $row['pageLoadTime']."</em>";
			}
		}
		$output .="</div>";
	}
	$sql_query = mysqli_query($conn, "SELECT COUNT(page_views) AS total_clicks FROM ".$N_URL." ") or die(mysqli_error($conn));
	$row = mysqli_fetch_assoc($sql_query);
	
		echo   "<h4>".strtoupper(goodUrl($URL)). "<b> - Total Views: " .$row['total_clicks']."</h4><br><br>";
	return $output;
}


// count times each link has been viewd 

function countViewsPerPage($conn, $DB, $page_link){
    $output = "";
    $sql = mysqli_query($conn, "SELECT COUNT(page_views) AS page_link_count FROM ".$DB." WHERE page_views = '$page_link' ") or die(mysqli_error($conn));
	if (mysqli_num_rows($sql) > 0) {
		foreach ($sql as $row) {
			$output .= $row['page_link_count'];
		}
	}
	
	return $output;
}


function countTotalSiteView($conn, $DB){
    $output = "";
    $sql = mysqli_query($conn, "SELECT COUNT(page_views) AS total_site_views FROM ".$DB."") or die(mysqli_error($conn));
	if (mysqli_num_rows($sql) > 0) {
		foreach ($sql as $row) {
			$output .= $row['total_site_views'];
		}
	}
	
	return $output;
}

// see where visitors are coming from

// function CountVisitsByCountry($conn, $DB,  $ip_address) {
//     $output = "";
//     $sql = mysqli_query($conn, "SELECT * FROM ".$DB." GROUP BY user_ip ") or die(mysqli_error($conn));
// 	if (mysqli_num_rows($sql) > 0) {
// 		foreach ($sql as $row) {
// 			$output .= $row['total_site_views'];
// 		}
// 	}
// 	$geoPlugin_array = unserialize( file_get_contents('http://www.geoplugin.net/php.gp?ip=' . $ip_address) );
// 	return $output;
    
// }


function AdmincheckWebsitePageResponseTime($url){
	$output = "";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	if(curl_exec($ch)) {
		$info = curl_getinfo($ch);
		$output .= "<span class='text-success'>".$info['total_time'] . ' seconds</span> ';
	}else{
		$output.= '<span class="text-danger"> 0 Time</span>';
	}
	curl_close($ch);
	return $output;
}

function AdminCheckWebsiteUptime($url){
    $timeout = 20;
    if(!filter_var($url, FILTER_VALIDATE_URL)){
        return false;
    }

    $curlInit = curl_init($url);
    
    curl_setopt($curlInit,CURLOPT_CONNECTTIMEOUT,10);
    curl_setopt($curlInit,CURLOPT_HEADER,true);
    curl_setopt($curlInit,CURLOPT_NOBODY,true);
    curl_setopt($curlInit,CURLOPT_RETURNTRANSFER,true);
    curl_setopt ($curlInit, CURLOPT_TIMEOUT, $timeout ); 
    $response = curl_exec($curlInit);
    $httpStatus = curl_getinfo( $curlInit, CURLINFO_HTTP_CODE );
    if($httpStatus == '200'){
        return true;
    }else{
        
    }
    curl_close($curlInit);

    return $response;
}

function viewerCountry($conn, $DB, $countryName){
    $output = "";
    $sql = mysqli_query($conn, "SELECT COUNT(countryName) AS view_by_country FROM ".$DB." WHERE countryName = '".addslashes($countryName)."'  GROUP BY countryName ") or die(mysqli_error($conn));
	if (mysqli_num_rows($sql) > 0) {
		foreach ($sql as $row) {
			$output .= $row['view_by_country']."<br>";
		}
	}
	return $output;
}

?>
