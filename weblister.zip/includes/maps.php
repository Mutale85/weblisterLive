<?php
include("db.php");

if(isset($_POST['region'])){
    $countryName = $_POST['region'];
    if($countryName == "Russian Federation"){
       $countryName = "Russia"; 
    }
    if($countryName == "United States of America"){
       $countryName =  'United States';
    }
    $DB = $_POST['DB'];

    if(viewerCountry($conn, $DB, $countryName) == 0 ){
        echo 0;
    }else{
       echo viewerCountry($conn, $DB, $countryName); 
    }
}
?>