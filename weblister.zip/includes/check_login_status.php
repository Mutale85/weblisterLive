<?php
require_once("db.php");
if (!isset($_SESSION['username'])) {
	header('location:logout.php');
}
$user_ok = false;
$log_id = "";
$log_username = "";
$log_password = "";

 function checkUser($conn, $id, $em, $p){
// $conn is the db connection, $id is the user id, $em is the user- username & $p is the user password
 	$query = mysqli_query($conn, "SELECT user_ip FROM members_list WHERE id = '$id'AND email = '$em' AND password = '$p' LIMIT 1 " ) or die(mysqli_error($conn));
 	$numrows = mysqli_num_rows($query);
 	if ($numrows > 0) {
 		return true;
 	}
 }
if (isset($_SESSION['user_id']) && isset($_SESSION['username']) && isset($_SESSION['password'])) {
	$log_id = preg_replace('#[^0-9]#', "", $_SESSION['user_id']);
	$log_username = preg_replace('#[^a-zA_Z0-9]#i', "", $_SESSION['username']);
	$log_password = preg_replace('#[^a-zA_Z0-9$._/\*]#i', "", $_SESSION['password']); 
 	$user_ok =  checkUser($conn, $log_id, $log_username, $log_password);
$message = "";
	if ($user_ok == true) {
		$query = mysqli_query($conn, "UPDATE members_list SET lastlogin = now() WHERE inst_id = '$log_id' LIMIT 1 ");
		$message = $_SESSION['username'];
	}
	// echo $message;
}
?>
<?php
if( isset( $_SESSION['counter'] ) )
{
$_SESSION['counter'] += 1;
}
else
{
$_SESSION['counter'] = 1;
}
$msg = "You have visited this page ". $_SESSION['counter']. " times ";
$msg .= " In this session.";
?>