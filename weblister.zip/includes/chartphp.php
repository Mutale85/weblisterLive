<?php
include('db.php');
if(isset($_POST['DBNAME'])){
    $DB = $_POST['DBNAME'];
    // graph performance
    $query = mysqli_query($conn, "SELECT COUNT(page_views) AS views , countryName, CAST(activity_time as Date) AS days_visited  FROM ".$DB." GROUP BY days_visited") or die(mysqli_error($conn));
    	    
    $data = array();
    foreach($query as $rowdata){
      $data[] = $rowdata;  
    }
    $chart_data = $activity_time = $countryName = "";
	$new_data = json_encode($data);
    $var=json_decode($new_data, true);
    foreach ($var as $key=>$value) {
        // $page .=  '\''.preg_replace("(^https?://)", "",$row['page_views']).'\', ';
        $chart_data .= $value['views'].",";
        $activity_time .= '\''.date("M-d", strtotime($value["days_visited"])).'\', ';
        $dates .= date("M-d", strtotime($value["days_visited"])).',';
        if($value["countryName"] == ""){
            $countryName = "";
        }else{
            $countryName .= '\''.$value["countryName"].'\', ';
        }
    }
    $countryName = trim($countryName, ",");
    $activity_time_trimed = trim($activity_time, ",");
	$chart_data_trimmed = trim($chart_data, ",");
	$dates = trim($dates, ",");
    ?>
    <!--Chart starts-->
    <div class="chartJS">
        <canvas id="myChart"></canvas>
    </div>
    <script>
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChartTwo = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [<?php echo $activity_time_trimed;?>],
                datasets: [{
                    label: 'Visitors', // Name the series
                    data: [<?php echo $chart_data_trimmed;?>], // Specify the data values array
                    fill: false,
                    borderColor: '#6499cd', // Add custom color border (Line)
                    backgroundColor: '#2196f3', // Add custom color background (Points and Fill)
                    borderWidth: 1 // Specify bar border width
                }]},
            options: {
              responsive: true, // Instruct chart js to respond nicely.
              maintainAspectRatio: true, // Add to prevent default behaviour of full-width/height
              title: {
    				display: true,
    				text: '<?php echo $site_name;?>'
    			},
    			scales: {
                    yAxes: [{
                        stacked: true
                    }]
                },
                
            }
        });
    </script>
    <?php
}
?>