<?php
include("db.php");

if (isset($_POST['websiteUptime'])) {
	$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ");
	$query->bind_param("s", $_SESSION['email']);
	$query->execute();
	$result = $query->get_result();
	if ($result->num_rows > 0) {
			
		foreach ($result as $row) {
			
			$URL = $row['website_link'];

			if(websiteUptime($URL)){ ?>
				<div class="well">
					<h4><?php echo strtoupper(goodUrl($URL))?>: <span class="text-success">100 <span style="color: #000; font-size: 13px;">%</span> Uptime</span> </h4>
			   </div>      
		<?php
			}else{
			   echo '<h4>Woops, '.strtoupper(goodUrl($URL)).'<span class="text-danger"> is down.</span></h4>'; 
			   // Here we can send email notifcation to the owner and also
			}
		}
	}
}

?>