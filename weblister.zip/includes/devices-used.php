<?php 
include("db.php");

if(isset($_POST['DBNAME'])){
$site_name = $_POST['DBNAME'];
$url = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($site_name));

$total = 100;
$math = countDeviceUsesAsComputer($conn, $url) + countDeviceUsesAsTablet($conn, $url) + countDeviceUsesAsMobilePhone($conn, $url);

$computer = countDeviceUsesAsComputer($conn, $url) / $math * $total; 
$table = countDeviceUsesAsTablet($conn, $url) / $math * $total;
$mobile = countDeviceUsesAsMobilePhone($conn, $url) / $math * $total;
?>
    <div class="table table-responsive">
        <table class="table table-hover">
                <tr>
                    <th><i class="fa fa-laptop" aria-hidden="true"></i> Computers</th>
                    <td> <?php echo countDeviceUsesAsComputer($conn, $url)?></td>
                </tr>
                <tr>
                   <th><i class="fa fa-tablet" aria-hidden="true"></i> Tablets</th>
                   <td> <?php echo countDeviceUsesAsTablet($conn, $url)?></td> 
                </tr>
                    <tr>
                    <th><i class="fa fa-mobile-phone" aria-hidden="true"></i> Mobile</th>
                    <td> <?php echo countDeviceUsesAsMobilePhone($conn, $url)?></td>
                </tr>
                <tfoot>
                    <tr>
                        <th>Total Views</th>
                        <th><?php echo countURLClicks($conn, $url)?></th>
                    </tr>
                </tfoot>
        </table>
    </div>
    
    <div class="percentage">
        <div class="devices-div">
          <div class="divices">
            <div class="device-name"><i class="fa fa-laptop" aria-hidden="true"></i> Computers | <?php echo countDeviceUsesAsComputer($conn, $url)?> | Visits</div>
            <div class="device-bar">
              <div class="device-per" per="<?php echo $computer?>"></div>
            </div>
            <div class="divices">
              <div class="device-name"><i class="fa fa-tablet" aria-hidden="true"></i> Tablets | <?php echo countDeviceUsesAsTablet($conn, $url)?> | Visits</div>
              <div class="device-bar">
                <div class="device-per" per="<?php echo $table;?>"></div>
              </div>
            </div>
            <div class="divices">
              <div class="device-name"><i class="fa fa-mobile-phone" aria-hidden="true"></i> Mobile | <?php echo countDeviceUsesAsMobilePhone($conn, $url)?> | Visits</div>
              <div class="device-bar">
                <div class="device-per" per="<?php echo $mobile?>"></div> 
              </div>
            </div>
          </div>
        </div>
    </div>
    <style>
    .percentage{
        font-family: "Open Sans", sans-serif;
        display: flex;
    }
    .devices-div {
        width: 100%;
        max-width: 600px;
        padding: 0 20px;
    }
    .device-name {
        font-size: 18px;
        font-weight: 500;
        text-transform: uppercase;
        margin: 20px 0;
    }
    .device-bar {
        height: 20px;
        background: #cacaca;
        border-radius: 8px;
    }
    .device-per {
        height: 20px;
        background-color: #f05a48;
        border-radius: 8px;
        width: 0;
        position: relative;
        transition: 1s linear;
    }
    .device-per::before {
        content: attr(per);
        position: absolute;
        padding: 4px 6px;
        background-color: #000;
        color: #fff;
        font-size: 12px;
        border-radius: 4px;
        top: -35px;
        right: 0;
        transform: translateX(50%);
    }
    .device-per::after {
        content: "";
        position: absolute;
        width: 10px;
        height: 10px;
        background-color: #000;
        top: -16px;
        right: 0;
        transform: translateX(50%) rotate(45deg);
        border-radius: 2px;
    }
    </style>
    <script>
        $(".device-per").each(function() {
          var $this = $(this);
          var per = $this.attr("per");
          $this.css("width", per + "%");
          $({ animatedValue: 0 }).animate(
            { animatedValue: per },
            {
              duration: 1000,
              step: function() {
                $this.attr("per", Math.floor(this.animatedValue) + "%");
              },
              complete: function() {
                $this.attr("per", Math.floor(this.animatedValue) + "%");
              }
            }
          );
        });
    </script>
<?php
    
}