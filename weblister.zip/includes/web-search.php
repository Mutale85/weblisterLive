<?php
include 'db.php';
if (isset($_POST['search'])) {
	$search = filter_var($_POST['search'], FILTER_SANITIZE_URL);
	$QUERY = $conn->prepare(" SELECT * FROM web_directory WHERE website_link LIKE CONCAT ('%', ?, '%') or website_category LIKE CONCAT ('%', ?, '%') ") or die(mysqli_error($conn));
	$QUERY->bind_param("ss", $search, $search);
	$QUERY->execute();
	$result = $QUERY->get_result();

	if ($result->num_rows > 0) {
		echo "<h4> Search Result</h4><br>";
		echo "<ol>";
		foreach ($result as $row) { ?>
			<div class="col-md-6 div_websites">
				<li><a href="<?php echo $row['website_link']?>" target="_blank"><i class="fa fa-external-link"></i> <?php echo ucfirst(goodUrl($row['website_link']));?></a></li>
			</div>
		<?php
		}
		echo "</ol>";
	}else{
		echo "<h3 class='alert alert-danger text-center'>Search returned no positive result</h3>";
	}
}
?>