<?php
include 'db.php';

if (isset($_POST['website_category'])) {
	$website_category = filter_var($_POST['website_category'], FILTER_SANITIZE_STRING);
	$website_link = filter_var($_POST['website_link'], FILTER_SANITIZE_URL);
	$site_id = preg_replace("#[^0-9]#", "", $_POST['site_id']);
	$ip_address = getUserIpAddr();

	if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9_+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website_link)) {
  		echo "Invalid URL";
  		exit();
  	}

  	// UPDATE SITE

  	$update = $conn->prepare("UPDATE web_directory SET website_category = ?, website_link = ?, user_ip = ? WHERE web_id = ? ") or die(mysqli_error($conn));
  	$update->bind_param("sssi", $website_category, $website_link, $ip_address, $site_id );
  	if( $update->execute()){
  		echo goodUrl($website_link)." Updated";
  	}


}
?>