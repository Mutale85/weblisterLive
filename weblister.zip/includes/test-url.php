<?php
include("db.php");

if(isset($_POST['website_link'])){
    $website_link = $_POST['website_link'];
    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9_+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website_link)) {
  		echo "Invalid URL";
  		exit();
  	}
  	// check if url exists 
  	if(urlExistence($website_link)){
      	if(websiteUptime($website_link)){
      	    // we test for headers
      	    // we test for speed
      	       echo $website_link." <h4 class='text-success'> Load Time: ". checkWebResponseTime($website_link)."</h4>";
      	       echo $website_link. "<h4 class='text-success'>Uptime : 100%</h4>";
      	}else{
      	    echo $website_link."<h4 class='text-danger'> is Down </h4>";
      	}
  	}else{
  	    echo $website_link . "<h4 class='text-danger'> Does not exist </h4>";
  	}
}
?>