<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
include 'db.php';
if (isset($_POST['username_check'])) {
	$username_check = filter_var(mysqli_real_escape_string($conn, $_POST['username_check']), FILTER_SANITIZE_EMAIL);
	$check = $conn->prepare("SELECT * FROM members_list WHERE username = ? ") or die(mysqli_error($conn));
	$check->bind_param("s", $username_check);
	$check->execute();
	$result = $check->get_result();
	if ($result->num_rows == 1) {
		echo "User with username: " .$username_check . " is already registered";
		exit();
	}else{
		echo "";
	}
}

if(isset($_POST['email'])) {
	$username = filter_var(mysqli_real_escape_string($conn, $_POST['username']), FILTER_SANITIZE_EMAIL);
	$email = filter_var(mysqli_real_escape_string($conn, $_POST['email']), FILTER_SANITIZE_EMAIL);
	$password = filter_var(mysqli_real_escape_string($conn, $_POST['password']), FILTER_SANITIZE_EMAIL);

	if ($email == "") {
		echo "Email field cannot be empty";
		exit();
	}
	if ($password == "") {
		echo "Password field cannot be empty";
		exit();
	}
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo "Invalid Email";
		exit();
	}
	$check = $conn->prepare("SELECT * FROM members_list WHERE email = ? ") or die(mysqli_error($conn));
	$check->bind_param("s", $email);
	$check->execute();
	$result = $check->get_result();
	if ($result->num_rows > 0) {
		echo "User with Email: " .$email . " is already registered";
		exit();
	}

	$password = password_hash($password, PASSWORD_DEFAULT);
	$SQL = $conn->prepare("INSERT INTO members_list (username, email, password) VALUES (?, ?, ?) ") or die(mysqli_error($conn));
	$SQL->bind_param("sss", $username, $email, $password);
	if($SQL->execute()){
		$userlast_id = $SQL->insert_id;
		// Send an Email
		include_once "../PHPMailer/PHPMailer.php";
		include_once "../PHPMailer/Exception.php";
		include_once "../PHPMailer/SMTP.php";
		include_once "../PHPMailer/OAuth.php";

		$message = '

                  	<!DOCTYPE html>
					<html>
					<head>
						<title>'.$username.'</title>
						<meta name="viewport" content="width=device-width, initial-scale=1.0">
						<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
						<style>
							.mail-div {
								box-shadow: 0 0 5px;
								padding: 20px;
								width: 60%;
								margin:50px auto;
								border-radius: 5px;
							}
							h1 span {
								color: #6499cd;
							}
							.icon_image {
								width: 100px;
								height: 100px;
								float: right;
								-webkit-animation:spin 5s linear infinite;
							    -moz-animation:spin 5s linear infinite;
							    animation:spin 5s linear infinite;
							}
							@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
							@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
							@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }

							@media(max-width: 768px){
								.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
							}
						</style>
					</head>
					<body>
						
						<div class="mail-div">
							<img src="https://weblister.co/images/icon_new.png" class="icon_image" alt="Icon">
							<h1>Welcome: <span> '.$username.' </span></h1>
							<a href="http://localhost/directory/activation?userid='.$userlast_id.'&email='.$email.'&pass='.$password.'">Activate your account by clicking here</a>
							<p>You can also copy this :http://localhost/directory/activation?userid='.$userlast_id.'&email='.$email.'&pass='.$password.' link and paste it into your browser.</p>
							<h4>Welcome to weblister. Add your websites links and also check other sites that are similar to what yours is about.</h4>
						</div>
					</body>
					</html>
                  ';
                  $mail = new PHPMailer();
                  $mail->Host = "weblister.co";
                  $mail->isSMTP();
                  $mail->SMTPAuth = true;
                  $mail->Username = "info@weblister.co";
                  $mail->Password = "!vNQ6rQbQXMX";
                  $mail->SMTPSecure = "ssl";//TLS
                  $mail->Port = 465; //TLS port= 587
                  $mail->addAddress($email, $username); //$inst_admin_email;
                  $mail-> setFrom("info@weblister.co", "Activation Link");
                  $mail-> Subject = " Activation Link";
                  $mail->isHTML(TRUE);
                  // $mail->SMTPDebug = 2;
                  $mail->Body = $message;
                  if($mail->send()){
                    echo "Registration Successful. Check Your Email <b>".$email."</b> for an account verification link";
                  }else{
                    
                  } 
	}

	$SQL->close();
	$conn->close();

}
?>