<?php
include 'db.php';
if (isset($_POST['email'])) {

	$query = $conn->prepare("SELECT * FROM members_list WHERE email = ? ") or die(mysqli_error($conn));
	$email  = mysqli_real_escape_string($conn, filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
	$password  = mysqli_real_escape_string($conn, $_POST['password']);
	// $password = preg_replace('#[^a-zA_Z0-9$._/\*]#i@*%', "", $_POST['password']);
	$user_ip = getUserIpAddr();

	$query->bind_param("s", $email);

	$query->execute();
	$result = $query->get_result();
	$count = $result->num_rows;
	if ($count > 0){
		foreach ($result as $row) {
			$active = $row['activate'];
			if ($active == '1') {
				if (password_verify($password, $row['password'])) {
					$_SESSION['email'] = $row['email'];
					$_SESSION['user_id'] = $row['id'];
					setcookie("RTS5435Xsdfstayn", $row['id']);
					$_SESSION['username'] = $row['username'];
					$_SESSION['password'] = $row['password'];
					setcookie("username", $row['username']);
					$login = date("d-m-y h:m:s");
					
					$sql = $conn->prepare("UPDATE members_list SET last_login = ?, user_ip = ? WHERE email = ? ") or die(mysqli_error($conn));
					$sql->bind_param("sss", $login, $user_ip, $email);
					$sql->execute();
					if ($sql) {
				// 		echo "login";
						if(!empty($_POST['remember_me'])){
							setcookie("user_login", $_POST['email'], time()+ (10 * 365 * 24 * 60 * 60));
							setcookie("user_login_pass", $_POST['password'], time()+ (10 * 365 * 24 * 60 * 60));
						}else{
							if (isset($_COOKIE['user_login'])) {
								setcookie("user_login","");
							}
							if (isset($_COOKIE['user_login_pass'])) {
								setcookie("user_login_pass","");
							}
						}
					}
				}else{
					echo "Incorrect Login Details";
					exit();
				}
			}else{
				echo "Your Account is not activated";
				//send an email with activation link
			}			
		}
	}else{
		echo "User Not Found";
	}
}
$conn->close();
?>