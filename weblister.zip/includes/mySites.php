<?php
include 'db.php';

if (isset($_POST['mySites'])) {
	echo MySites($conn, $_SESSION['email']);
}
?>