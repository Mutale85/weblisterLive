<?php
// -------------------------------------------------------
include ("db.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include_once "../PHPMailer/PHPMailer.php";
include_once "../PHPMailer/Exception.php";
include_once "../PHPMailer/SMTP.php";
include_once "../PHPMailer/OAuth.php";

if (isset($_POST['forgotpass_email'])) {
	$email = mysqli_real_escape_string($conn, filter_var($_POST['forgotpass_email'], FILTER_SANITIZE_STRING));
	$sql = $conn->prepare("SELECT * FROM members_list WHERE email = ? ") or die(mysqli_error($conn));
	$sql->bind_param("s", $email);
	$sql->execute();
	$result = $sql->get_result();

	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		$email = $row['email'];
		$username = $row['username'];
		$userForgotten = $row['password'];
		$string = "1234567890qwertyuiopasdfghjklzxcvbnm";
		$shuffle = str_shuffle($string);
		$token = substr($shuffle, 0, 10);
		$update = $conn->prepare("UPDATE members_list SET token = ? WHERE email = ? ") or die("There Was a Problem with Your Password Reset");
		$update->bind_param("ss", $token, $email);
		$update->execute();
		// We send email to user
		$message = '	<!DOCTYPE html>
						<html>
						<head>
							<title>'.$email.'</title>
							<meta name="viewport" content="width=device-width, initial-scale=1.0">
							<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
							<style>
								.mail-div {
									box-shadow: 0 0 5px;
									padding: 20px;
									width: 60%;
									margin:50px auto;
									border-radius: 5px;
								}
								h1 span {
									color: #6499cd;
								}
								.icon_image {
									width: 100px;
									height: 100px;
									float: right;
									-webkit-animation:spin 5s linear infinite;
								    -moz-animation:spin 5s linear infinite;
								    animation:spin 5s linear infinite;
								}
								@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
								@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
								@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }

								@media(max-width: 768px){
									.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
								}
							</style>
						</head>
						<body>
							
							<div class="mail-div">
								<img src="https://weblister.co/images/icon_new.png" class="icon_image" alt="Icon">
								<h1>Welcome: <span> '.$username.' </span></h1>
								<a title="actions_link" href="https://weblister.co/resetpassword?token='.$token.'&email='.$email.'">Click Here To Reset Password</a>
								<p>You can also copy this :https://weblister.co/resetpassword?token='.$token.'&email='.$email.' link and paste it into your browser.</p>
								<h4>Ignore this message if you did not request a password reset!</h4>
							</div>
						</body>
						</html>
						';
				           
                    	$mail = new PHPMailer();
						$mail->Host = "weblister.co";
						$mail->isSMTP();
						$mail->SMTPAuth = true;
						$mail->Username = "info@weblister.co";
						$mail->Password = "!vNQ6rQbQXMX";
						$mail->SMTPSecure = "ssl";//TLS
						$mail->Port = 465; //TLS port= 587
						$mail->addAddress($email, $username); //$inst_admin_email;
						$mail-> setFrom("info@weblister.co", "Password Reset");
						$mail-> Subject = " Reset Password";
						$mail->isHTML(TRUE);
                    // 	$mail->SMTPDebug = 2;
                    	$mail->Body = $message;
                    	if($mail->send()){
                    		echo "An email with a password reset has been sent to <b>".$email."</b> check your email inbox / spam mails";
                    	}else{
                    		echo $mail->ErrorInfo;
                    	}
                        	
	}else{
		echo "<span style='color:red;'>Email Not Found In Our Server</span>";
	}
}
?>