<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include 'db.php';

if (isset($_POST['website_category'])) {
  	$website_category = filter_var($_POST['website_category'], FILTER_SANITIZE_STRING);
  	$website_link = filter_var($_POST['website_link'], FILTER_SANITIZE_URL);
  	$site_id = preg_replace("#[^0-9]#", "", $_POST['site_id']);
  	$ip_address = getUserIpAddr();

	if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9_+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website_link)) {
  		echo "Invalid URL";
  		exit();
  	}
    

  	$check_web = $conn->prepare("SELECT website_link FROM web_directory WHERE website_link = ? ") or die(mysqli_error($conn));
    $check_web->bind_param("s", $website_link);
    $check_web->execute();
    $result = $check_web->get_result();
    if ($result->num_rows > 0) {
      echo "Url: " .$website_link . " is already registered";
      exit();
    }
    $Trial    = "Trial";
    $Basic    = "Basic";
    $Medium   = "Medium";
    $Platinum = "Platinum";
    $number_of_sites = "";
    $sql = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ? ") or die(mysqli_error($conn));
    $sql->bind_param("s", $_SESSION['email']);
    $sql->execute();
    $count_sites = $sql->num_rows;
    $check = $sql->get_result();
    $plan = $price = $start_date = $end_date = $currency = "";
    foreach ($check as $rows) {
      $plan = $rows['plan'];
      $start_date = $rows['start_date'];
      $end_date = $rows['end_date'];
      $currency = $rows['currency'];
      $price = $rows['price'];
      if ($rows['plan'] == "Trial" && $count_sites == 1) {
        echo "You Subscription only allows a Single Website";
        exit();
      }elseif ($rows['plan'] == "Basic" && $count_sites >= 3) {
        echo "You Subscription only allows a 10 Website";
        exit();
      }elseif ($rows['plan'] == "Medium" && $count_sites >= 20) {
        echo "You can only add a maximum of 20 Websites";
        exit();
      }elseif($rows['plan'] == "Platinum" && $count_sites >= 30){
        echo "You can only add a maximum of 30 Websites";
        exit();
      }
    }

  	$sql_add = $conn->prepare("INSERT INTO web_directory (user_email, website_category, website_link, user_ip, plan, price, currency, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ") or die(mysqli_error($conn));
  	$sql_add->bind_param("ssssssss", $_SESSION['email'], $website_category, $website_link, $ip_address, $plan, $price, $currency, $end_date );
  	if( $sql_add->execute()){
  		// echo goodUrl($website_link)." Added";
      $site_name = preg_replace("#[^0-9a-zA-Z_]#", "_" , goodUrl($website_link));
      $sql = "CREATE TABLE IF NOT EXISTS weblifjy_web_listers.$site_name (
          id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          site_name VARCHAR(30) NOT NULL,
          page_views TEXT NOT NULL,
          pageLoadTime VARCHAR(200) NOT NULL,
          device_type VARCHAR(100) NOT NULL,
          user_ip VARCHAR(50) NOT NULL,
          countryName VARCHAR(200) NOT NULL,
          operating_system TEXT NOT NULL,
          activity_time DATETIME NOT NULL
          )
          ";

        if ($conn->query($sql) === TRUE) {
           // echo "Table ".$site_name." created successfully<br>";
        } else {
            echo "Error creating table: " . $conn->error;
        }
        // Email User the New Link to add to the site -----
        include_once "../PHPMailer/PHPMailer.php";
		include_once "../PHPMailer/Exception.php";
		include_once "../PHPMailer/SMTP.php";
		include_once "../PHPMailer/OAuth.php";
		$username = goodUrl($website_link);
		$message = '
		    <!DOCTYPE html>
            <html>
            <head>
            	<title>'.$username.'</title>
            	<meta name="viewport" content="width=device-width, initial-scale=1.0">
            	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            	<style>
            		.mail-div {
            			box-shadow: 0 0 5px;
            			padding: 20px;
            			width: 60%;
            			margin:50px auto;
            			border-radius: 5px;
            		}
            		h1 span {
            			color: #6499cd;
            		}
            		.icon_image {
            			width: 100px;
            			height: 100px;
            			float: right;
            			-webkit-animation:spin 5s linear infinite;
            		    -moz-animation:spin 5s linear infinite;
            		    animation:spin 5s linear infinite;
            		}
            		@-moz-keyframes spin { 100% { -moz-transform: rotate(360deg); } }
            		@-webkit-keyframes spin { 100% { -webkit-transform: rotate(360deg); } }
            		@keyframes spin { 100% { -webkit-transform: rotate(360deg); transform:rotate(360deg); } }
            
            		@media(max-width: 768px){
            			.mail-div {width: 95%; box-shadow: none;border: 1px solid #ccc;}
            		}
            		.codeArea {
            			background: #6499cd;
            			color: #fff;
            			padding: 10px;
            			border-radius: 5px;
            			font-family: "Source Code Pro", monospace;
            		}
            		.codeArea textarea{
            			margin: 5px auto;
            			width: 98%;
            			height: 60px;
            			resize: none;
            			border: none;
            			padding: 10px;
            			color: #fff;
            		}
            		.monitor_image {
            			width: 400px;
            			height: 400px;
            			margin-left: auto;
            			margin-right: auto;
            		}
            	</style>
            </head>
            <body>
            	
            	<div class="mail-div">
            		<img src="https://weblister.co/images/icon_new.png" class="icon_image" alt="Icon">
            		<h1>You have add a New website <span> '.$username.' </span></h1>
            		<img src="https://weblister.co/images/anotherSite.png" class="img-responsive monitor_image" alt="siteImage">
            		<div class="codeArea">
            			<h4 align="center">Please Add this code in your HTML for our service to work on your sites</h4><br>
            			<textarea readonly disabled="disabled" class="code-text"><script type="text/javascript" src="https://weblister.co/js/extension.js?url='.$website_link.'"></script></textarea>
            			<br><br>
            		</div>
            	</div>
            </body>
            </html>
		';
		
		$mail = new PHPMailer();
		$mail->Host = "weblister.co";
		$mail->isSMTP();
		$mail->SMTPAuth = true;
		$mail->Username = "info@weblister.co";
		$mail->Password = "!vNQ6rQbQXMX";
		$mail->SMTPSecure = "ssl";//TLS
		$mail->Port = 465; //TLS port= 587
		$mail->addAddress($_SESSION['email'], $username);
		$mail-> setFrom("info@weblister.co", "New Site Added");
		$mail-> Subject = $username;
		$mail->isHTML(TRUE);
		// $mail->SMTPDebug = 2;
		$mail->Body = $message;
		if($mail->send()){
		    echo strtoupper(goodUrl($website_link))." Added";

		}else{

		} 
        
      exit();
  	}

}
?>