<?php
include("db.php");

if (isset($_POST['website_category'])) {
	$website_category = filter_var($_POST['website_category'], FILTER_SANITIZE_STRING);
	$website_link = filter_var($_POST['website_link'], FILTER_SANITIZE_URL);
	$user_id = preg_replace("#[^0-9]#", "", $_POST['user_id']);
	$ip_address = getUserIpAddr();

	if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9_+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website_link)) {
  		echo "Invalid URL";
  		exit();
  	}

	// we process the data and send to DB.
	$check = $conn->prepare("SELECT website_link FROM web_directory WHERE website_link = ? ") or die(mysqli_error($conn));
	$check->bind_param("s", $website_link);
	$check->execute();
	$result = $check->get_result();
	if ($result->num_rows > 0) {
		echo "Url: " .$website_link . " is already registered";
		exit();
	}

	$SQL = $conn->prepare("INSERT INTO web_directory (user_id, website_category, website_link, user_ip) VALUES (?, ?, ?, ?) ") or die(mysqli_error($conn));
	$SQL->bind_param("isss",$user_id, $website_category, $website_link, $ip_address);
	
	if($SQL->execute()){
		echo "Url: " .$website_link . " successfully registered";
		exit();
	}

	$SQL->close();
	$conn->close();
}
?>