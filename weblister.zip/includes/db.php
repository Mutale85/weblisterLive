<?php
session_start();
session_name();
define("HOST", "");
define("USER", "weblifjy_web_lister_muls");
define("PASS", "qW9XVgq^^#L@");
define("DBNAME", "weblifjy_web_listers");

$conn = new mysqli(HOST, USER, PASS, DBNAME);

// $conn = new mysqli("localhost", "root", "", "web_directory");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

include("functions.php");
?>