<?php
include 'db.php';

if (isset($_POST['mySites'])) {
	echo MyListedSites($conn, $_SESSION['email']);
}
?>