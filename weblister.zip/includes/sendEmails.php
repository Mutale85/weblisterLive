<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include("db.php");
include_once "../PHPMailer/PHPMailer.php";
include_once "../PHPMailer/Exception.php";
include_once "../PHPMailer/SMTP.php";
include_once "../PHPMailer/OAuth.php";


$query = $conn->prepare("SELECT * FROM web_directory");
$query->execute();
$result = $query->get_result();
$site_status = "";

foreach($result as $row){
    $url = strtoupper(goodUrl($row['website_link']));
    $user_email = $row['user_email'];
    
    if(AdminCheckWebsiteUptime($row['website_link'])){
        $site_status = "<span class='text-success'>100 Uptime</span>";
    }else{
        $site_status = "<span class='text-danger'>Website Down</span>";
    }

    
    $mail = new PHPMailer();
    $mail->Host = "weblister.co";
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Username = "info@weblister.co";
    $mail->Password = "!vNQ6rQbQXMX";
    $mail->SMTPSecure = "ssl";//TLS
    $mail->Port = 465; //TLS port= 587
    $mail-> setFrom("info@weblister.co", "Website Monitoring");
    $mail->isHTML(TRUE);
    $mail->SMTPDebug = 2;
    $mail-> Subject = $url." Uptime Status";
    $mail->addAddress($user_email, "Weblister");
    $mail->Body = $site_status;
    
    if($mail->send()){
        echo 'Message sent to :' . htmlspecialchars($user_email) . '<br>';
        $update = $conn->prepare("INSERT INTO emails_records (user_email) VALUES(?) ") or die(mysqli_error($conn));
        $update->bind_param("s", $user_email);
        $update->execute();
    }else{
        $mail->ErrorInfo;
    }
}

?>