<?php
include("header.php");
?>
<style>
	.form-div {
		width:65%; border: solid 1px #333333;margin: 50px auto;
		background: #fff;
	}
	
	.error-msg_s {
		color:#cc0000; margin-top:10px;text-align: center;
		background: rgba(0,0,0,0.8); padding: 7px;
	}
	
	.login_eye_con:hover {
		cursor: pointer;
	}
	.eyeColor {
		color: mediumseagreen;
	}
	.input-group-addon {
		background: #fff;
	}
	@media(max-width: 767px){
		.form-div {
			width:100%;
			border: none;
			box-shadow: 0 0 3px;
		}
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="form-div">
            	<h1 class="text-center">Login</h1><br>
               	<form method="post" id="LoginForm">
               		<div class="form-group">
               			<div class="input-group">
               				<div class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
               				<input type="email" name="email" id="email" class="form-control" required="required" placeholder="Email">
               			</div>
               		</div>
               		<div class="form-group">
               			<div class="input-group">
               				<div class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></div>
               				<input type="password" name="password" id="password" class="form-control" required="required" placeholder="Your Password">
               				<div class="input-group-addon login_eye_con"><i class="fa fa-eye"></i></div>
               			</div>
               		</div>
               		<div class="checbox">
               		    <?php
    						if (empty($_COOKIE["user_login"])) {
    							echo '<label><input type="checkbox" name="remember_me"> Remember Me</label>';
    						}else{	
    							echo '<label><input type="checkbox" name="remember_me" checked> Remember Me</label>';
    						}
    					?>
               		</div>
                  	<button type="submit" name="submit" class="btn btn-primary pull-right">Login</button>
               	</form>
               	<div class="">
               		<br><br><hr>
	               	<p>Not yet a Member?<a href="./" class="text-danger"> Add your Site</a></p>
	               	<p><a href="forgotpassword">Forgot Password?</a></p>
	               </div>
           		<div class="login-error-msg"></div>		
         	</div>
		</div>
	</div>
</div>
<?php include("footer.php");?>
<script type="text/javascript">
	$(function(){
		$("#LoginForm").submit(function(e){
			e.preventDefault();
			$.ajax({
				url:"includes/login",
				method:"post",
				data:$(this).serialize(),
				beforeSend:function(){
					$("button").attr("disabled", "disabled");
					$("button").html("<i class='fa fa-spinner fa-spin'></i>");
				},
				success:function(data){
					if (data=="login") {
						window.location = "login";
					}else{
				// 		alert(data);
						window.location = "login";
						$("button").html("Submit");
						$("button").removeAttr("disabled");
						$(".login-error-msg").html(data).addClass("error-msg_s");
					}
					
					
				}
			})
		});

		$(".login_eye_con").click(function(){
			var password = document.getElementById('password');
			if (password.type === 'password') {
				password.type = 'text';
				$(".fa-eye").addClass('fa-eye-slash').addClass("eyeColor");
			}else{
				password.type = 'password';
				$(".fa-eye").removeClass('fa-eye-slash').removeClass("eyeColor");
			}
		})
	})
</script>