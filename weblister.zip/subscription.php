<?php
include 'header-profile.php';
?>
<style>
    .price-grid ul li {
        font-family: 'Source Code Pro', monospace;
    }
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="subscription">
				<h4 class="text-center"><i class="fa fa-credit-card fa-fw" aria-hidden="true"></i> <?php echo $message?></h4>

				<p class="text-center"><a href="" class="btn btn-default monthly">Monthly</a> | <a href="" class="btn btn-primary yearly">Yearly</a></p>
			</div>
		</div>
		<br><br><br>
		<div class="price-grid col-md-4">
			<div class="price-block agile">
				<div class="price-gd-top pric-clr1">
					<h4>Basic</h4>
					<h3 id="amount">$5.99</h3>
					<h5 id="period">Monthly</h5>
				</div>
				<div class="price-gd-bottom">
					<div class="price-list">
						<ul>
							<li>Up to 10K visitors</li>
							<li>Unlimted Websites</li>
							<li>Website Monitoring Every 5 Minutes</li>
							<li>Check Top Performing Pages</li>
							<li>Update Website Visits</li>
							<li>Receive Email Alerts on Downtime</li>
							<li>Check Mobile Responsiveness</li>
						</ul>
					</div>
				</div>
				
				<form method="post" id="">
					<input type="hidden" name="subscription_plan_one" id="subscription_plan_one" class="form-control" value="Basic">
					<input type="hidden" name="subscription_price_one" id="subscription_price_one" class="form-control" value="5.99">
					<input type="hidden" name="allowed_sites_one" id="allowed_sites_one" class="form-control" value="100">
					<input type="hidden" name="duration_one" id="duration_one" class="form-control" value="Monthly">
					<input type="hidden" name="currency" id="currency" value="USD">
					<input type="hidden" name="user_email" id="user_email" value="<?php echo $_SESSION['email']?>">
					<div class="price-select text-center pric-sclr1">
						<button class="btn btn-default popup-with-zoom-anim one" onclick="BasicPayment(event)" data-user_email="<?php echo $_SESSION['email']?>"> PAY Now</button><br><br>
					</div>
				</form>
				<script src="https://checkout.flutterwave.com/v3.js"></script>
			</div>
		</div>

		<div class="price-grid col-md-4">
			<div class="price-block agile">
				<div class="price-gd-top pric-clr2">
					<h4>Middle</h4>
					<h3 id="amount_two">$9.99</h3>
					<h5 id="period_two">Monthly</h5>
				</div>
				<div class="price-gd-bottom">
					<div class="price-list">
						<ul>
							<li>Up to 100K visitors</li>
							<li>Unlimted Websites</li>
							<li>Check Top Performing Pages</li>
							<li>Website Monitoring Every 5 Minutes</li>
							<li>Update Website Visits</li>
							<li>Receive Email Alerts on Downtime</li>
							<li>Check Mobile Responsiveness</li>
						</ul>
					</div>
				</div>
				
				<form method="post" id="">
					<input type="hidden" name="subscription_plan_two" id="subscription_plan_two" class="form-control" value="Middle">
					<input type="hidden" name="subscription_price_two" id="subscription_price_two" class="form-control" value="9.99">
					<input type="hidden" name="allowed_sites_two" id="allowed_sites_two" class="form-control" value="200">
					<input type="hidden" name="duration_two" id="duration_two" class="form-control" value="Monthly">
					<input type="hidden" name="currency" id="currency" value="USD">
					<input type="hidden" name="user_email" id="user_email" value="<?php echo $_SESSION['email']?>">
					<div class="price-select text-center pric-sclr2">
						<button class="btn btn-default popup-with-zoom-anim two" onclick="MediumPay(event)">PAY Now</button><br><br>
					</div>
				</form>
			</div>
		</div>

		<div class="price-grid col-md-3">
			<div class="price-block agile">
				<div class="price-gd-top pric-clr3">
					<h4>Platinum</h4>
					<h3 id="amount_three">$19.99</h3>
					<h5 id="period_three">Monthly</h5>
				</div>
				<div class="price-gd-bottom">
					<div class="price-list">
						<ul>
							<li>unlimited visitors</li>
							<li>Unlimted Websites</li>
							<li>Website Monitoring Every 5 Minutes</li>
							<li>Check Top Performing Pages</li>
							<li>Update Website Visits</li>
							<li>Receive Email Alerts on Downtime</li>
							<li>Check Mobile Responsiveness</li>
						</ul>
					</div>
				</div>
				
				<form method="post" id="">
					<input type="hidden" name="subscription_plan_three" id="subscription_plan_three" class="form-control" value="Platinum">
					<input type="hidden" name="subscription_price_three" id="subscription_price_three" class="form-control" value="19.99">
					<input type="hidden" name="allowed_sites_three" id="allowed_sites_three" class="form-control" value="30">
					<input type="hidden" name="duration_three" id="duration_three" class="form-control" value="Monthly">
					<input type="hidden" name="currency" id="currency" value="USD">
					<input type="hidden" name="user_email" id="user_email" value="<?php echo $_SESSION['email']?>">
					<div class="price-select text-center pric-sclr3">
						<button class="btn btn-default popup-with-zoom-anim three" onclick="PlatinumPay(event)">PAY Now</button><br><br>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php
include 'footer-profile.php';
?>
<script>
	$(document).ready(function(){
		
		var amount 						= document.getElementById('amount');
		var amount_two 					= document.getElementById('amount_two');
		var amount_three 				= document.getElementById('amount_three');


		var period 						= document.getElementById('period');
		var period_two 					= document.getElementById('period_two');
		var period_three 				= document.getElementById('period_three');

		//------------ Hidden Forms ----------

		var subscription_plan_one 		= document.getElementById("subscription_plan_one");
		var subscription_price_one 		= document.getElementById("subscription_price_one");
		var allowed_sites_one 			= document.getElementById("allowed_sites_one");
		var duration_one 				= document.getElementById("duration_one");

		var subscription_plan_two 		= document.getElementById("subscription_plan_two");
		var subscription_price_two 		= document.getElementById("subscription_price_two");
		var allowed_sites_two 			= document.getElementById("allowed_sites_two");
		var duration_two 				= document.getElementById("duration_two");

		var subscription_plan_three 	= document.getElementById("subscription_plan_three");
		var subscription_price_three 	= document.getElementById("subscription_price_three");
		var allowed_sites_three 		= document.getElementById("allowed_sites_three");
		var duration_three 				= document.getElementById("duration_three");

		$(document).on("click", ".yearly", function(e){
			e.preventDefault();

			$(amount).html("$"+5.99*11);
			$(amount_two).html("$"+9.99*11);
			$(amount_three).html("$"+19.99*11);

			//------- period -----
			period.innerHTML 		= "Yearly";
			period_two.innerHTML 	= "Yearly";
			period_three.innerHTML 	= "Yearly";

			subscription_price_one.value 	= 5.99*11;
			subscription_price_two.value 	= 9.99*11;
			subscription_price_three.value 	= 19.99*11;

			duration_one.value = "Yearly";
			duration_two.value = "Yearly";
			duration_three.value = "Yearly";
		});

		$(document).on("click", ".monthly", function(e){
			e.preventDefault();

			//------- period -----
			period.innerHTML 		= "Monthly";
			period_two.innerHTML 	= "Monthly";
			period_three.innerHTML 	= "Monthly";

			$(amount).html("$"+5.99);
			$(amount_two).html("$"+9.99);
			$(amount_three).html("$"+19.99);

			subscription_price_one.value 	= 5.99;
			subscription_price_two.value 	= 9.99;
			subscription_price_three.value 	= 19.99;

			duration_one.value = "Monthly";
			duration_two.value = "Monthly";
			duration_three.value = "Monthly";
		});
	})
</script>
<!-- First Payment Button -->
<script>
  	function BasicPayment(event) {
  		event.preventDefault();
  		var subscription_plan_one 		= document.getElementById("subscription_plan_one").value;
		var amount_to_pay 				= document.getElementById("subscription_price_one").value;
		var allowed_sites_one 			= document.getElementById("allowed_sites_one").value;
		var duration_one 				= document.getElementById("duration_one").value;
		var user_email 					= document.getElementById("user_email").value;
		var currency 					= document.getElementById("currency").value;
		var tx_ref 						= allowed_sites_one+"_"+user_email;
		var username 					= "<?php echo $_SESSION['username']?>";
		var consumer_id 				= "<?php echo $_SESSION['user_id']?>";
		var consumer_mac				= "<?php echo getUserIpAddr()?>";
		var redirect_url 				= "subscription-payment?success=success&user_email="+user_email+"&payment_plan="+subscription_plan_one+"&currency="+currency+" &amount_paid="+amount_to_pay+"&duration="+duration_one;
// 		var public_key = "FLWPUBK_TEST-e5fa271a124685e29bf24120770dcdbc-X";
        var public_key = "FLWPUBK-2cc15d3e7d92a0ce012bdabbf548afd5-X";
		var description = "Payment for Weblister subscription amounting to: "+currency+amount_to_pay;
		// alert(redirect_url);
		var logo = "https://weblister.co/images/icon_new.png";										

    	FlutterwaveCheckout({
			public_key: public_key,
			tx_ref: tx_ref,
			amount: amount_to_pay,
			currency: currency,
			payment_options: "card",
			redirect_url:redirect_url,
	      	meta: {
	        	consumer_id: consumer_id,
	        	consumer_mac: consumer_mac,
	      	},
	      	customer: {
	        	email: user_email,
	        	// phone_number: "08102909304",
	        	name: username,
	      	},
	      	callback: function (data) {
	        	console.log(data);
	      	},
	      	onclose: function() {
	        	// close modal
	      	},
	      	customizations: {
	        	title: "Weblister",
	        	description: description,
	        	logo: logo,
	      	},
	    });

	    $.ajax({
	    	url:"includes/update-payment",
	    	method:"post",
	    	data:{
	    		consumer_id:consumer_id,
	    		tx_ref:tx_ref
	    	},
	    	success:function(data){

	    	}
	    })
  	}
</script>
<script>
  	function MediumPay(event) {
  		event.preventDefault();
  		var subscription_plan_two 		= document.getElementById("subscription_plan_two").value;
		var amount_to_pay 				= document.getElementById("subscription_price_two").value;
		var allowed_sites_two 			= document.getElementById("allowed_sites_two").value;
		var duration_two 				= document.getElementById("duration_two").value;
		var user_email 					= document.getElementById("user_email").value;
		var currency 					= document.getElementById("currency").value;
		var tx_ref 						= allowed_sites_two+user_email;
		var username 					= "<?php echo $_SESSION['username']?>";
		var consumer_id 				= "<?php echo $_SESSION['user_id']?>";
		var consumer_mac				= "<?php echo getUserIpAddr()?>";
		var redirect_url 				= "subscription-payment?success=success&user_email="+user_email+"&payment_plan="+subscription_plan_two+"&currency="+currency+"&amount_paid="+amount_to_pay+"&duration="+duration_two+"&tx_ref="+tx_ref;
// 		var public_key = "FLWPUBK_TEST-e5fa271a124685e29bf24120770dcdbc-X";
        var public_key = "FLWPUBK-2cc15d3e7d92a0ce012bdabbf548afd5-X";
		var description = "Payment for Weblister subscription amounting to: "+currency+amount_to_pay;
		// alert(redirect_url);
		var logo = "https://weblister.co/images/icon_new.png";										

    	FlutterwaveCheckout({
			public_key: public_key,
			tx_ref: tx_ref,
			amount: amount_to_pay,
			currency: currency,
			payment_options: "card",
			redirect_url:redirect_url,
	      	meta: {
	        	consumer_id: consumer_id,
	        	consumer_mac: consumer_mac,
	      	},
	      	customer: {
	        	email: user_email,
	        	// phone_number: "08102909304",
	        	name: username,
	      	},
	      	callback: function (data) {
	        	console.log(data);
	      	},
	      	onclose: function() {
	        	// close modal
	      	},
	      	customizations: {
	        	title: "Weblister",
	        	description: description,
	        	logo: logo,
	      	},
	    });
	    $.ajax({
	    	url:"includes/update-payment",
	    	method:"post",
	    	data:{
	    		consumer_id:consumer_id,
	    		tx_ref:tx_ref
	    	},
	    	success:function(data){

	    	}
	    })
  	}
</script>
<script>
  	function PlatinumPay(event) {
  		event.preventDefault();
  		var subscription_plan_three 		= document.getElementById("subscription_plan_three").value;
		var amount_to_pay 				= document.getElementById("subscription_price_three").value;
		var allowed_sites_three 			= document.getElementById("allowed_sites_three").value;
		var duration_three 				= document.getElementById("duration_three").value;
		var user_email 					= document.getElementById("user_email").value;
		var currency 					= document.getElementById("currency").value;
		var tx_ref 						= allowed_sites_three+"_"+user_email;
		var username 					= "<?php echo $_SESSION['username']?>";
		var consumer_id 				= "<?php echo $_SESSION['user_id']?>";
		var consumer_mac				= "<?php echo getUserIpAddr()?>";
		var redirect_url 				= "subscription-payment?success=success&user_email="+user_email+"&payment_plan="+subscription_plan_three+"&currency="+currency+" &amount_paid="+amount_to_pay+"&duration="+duration_three;
// 		var public_key = "FLWPUBK_TEST-e5fa271a124685e29bf24120770dcdbc-X";
        var public_key = "FLWPUBK-2cc15d3e7d92a0ce012bdabbf548afd5-X";
		var description = "Payment for Weblister subscription amounting to: "+currency+amount_to_pay;
		// alert(redirect_url);
		var logo = "https://weblister.co/images/icon_new.png";										

    	FlutterwaveCheckout({
			public_key: public_key,
			tx_ref: tx_ref,
			amount: amount_to_pay,
			currency: currency,
			payment_options: "card",
			redirect_url:redirect_url,
	      	meta: {
	        	consumer_id: consumer_id,
	        	consumer_mac: consumer_mac,
	      	},
	      	customer: {
	        	email: user_email,
	        	// phone_number: "08102909304",
	        	name: username,
	      	},
	      	callback: function (data) {
	        	console.log(data);
	      	},
	      	onclose: function() {
	        	// close modal
	      	},
	      	customizations: {
	        	title: "Weblister",
	        	description: description,
	        	logo: logo,
	      	},
	    });
	    $.ajax({
	    	url:"includes/update-payment",
	    	method:"post",
	    	data:{
	    		consumer_id:consumer_id,
	    		tx_ref:tx_ref
	    	},
	    	success:function(data){

	    	}
	    })
  	}
</script>