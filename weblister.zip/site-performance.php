<?php
include("header-profile.php");
if(isset($_COOKIE['site_url'])){
    $url= goodUrl($_COOKIE['site_url']);
    $site_name = $_COOKIE['site_url'];
    $DB = preg_replace("#[^0-9a-zA-Z_]#", "_", $url);
}else if(!isset($_GET['site-url'])){
   echo '<script>window.location="./"</script>'; 
}else{
    $url= goodUrl($_GET['site-url']);
    $site_name = $_GET['site-url'];
    $DB = preg_replace("#[^0-9a-zA-Z_]#", "_", $url);
}
?>
<style>
    .mapping {
        margin:50px auto;
        width:80%;
        margin:30px auto;
        padding:0px;
        border-radius:5px;
    }
    .mapping #vmap {
        width: 100%; height: 400px;
		border-radius: 5px;
    }
    .data {
        font-style:italic;
    }
    .mapping span {
        font-size:11px;
        color:tomato;
    }
    .detailsDiv {
        width:80%;
        margin:60px auto;
        border:1px solid #ccc;
        padding:20px;
        font-family: 'Source Code Pro', monospace;
    }
    .tableDiv {
        border-radius:3px;
        border:1px solid #ddd;
        padding:10px;
    }
    #demo-table {
      font-family: 'Source Code Pro', monospace;
      border-collapse: collapse;
      width: 80%;
      margin:30px auto;
    }
    
    #demo-table td, #demo-table th {
      border: 1px solid #ddd;
      padding: 8px;
    }
    
    #demo-table tr:nth-child(even){background-color: #f2f2f2;}
    
    #demo-table tr:hover {background-color: #ddd;}
    
    #demo-table th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: left;
      /*background-color: #4CAF50;*/
      background-color:#6499cd;
      color: white;
    }
    @media(max-width: 767px){
        .detailsDiv {
            width:100%;
            border:none;
            padding:0;
        }
        .table-views {
            width:100%;
            box-shadow:none;
            border:1px solid #ccc;
        }
        .chartJS {
            width:100%;
            box-shadow:none;
            border:1px solid #ccc;  
        }
        .mapping {
            width:100%;
            box-shadow:none;
            border:none;
            padding:5px;
            
        }
        .mapping #vmap {
			width: 100%; 
			height: 350px;
		}
		#demo-table th {
		    font-size:14px;
		}
		
    }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
			<!--<div class="mylistedSites"></div>-->
			<h3><?php echo $site_name?>'s Performance</h3><hr>
		</div>
        <div class="col-md-12">
            <?php
                $sql = mysqli_query($conn, "SELECT * FROM web_directory WHERE website_link = '$site_name' ") or die(mysqli_error($conn));
                $row = mysqli_fetch_assoc($sql);
                $website_category = $row['website_category'];
            ?>
            <div class="buttonLinks text-center">
                <a href="site-performance?site-url=<?php echo $site_name?>" class="btn btn-default btn-sm" id="<?php echo $DB?>"><i class="fa fa-globe" aria-hidden="true"></i> RESET</a>
                <a href="" class="btn btn-default btn-sm country-details" id="<?php echo $DB?>"><i class="fa fa-globe" aria-hidden="true"></i> COUNTRIES</a>
                <a href="" class="btn btn-default btn-sm page-details" id="<?php echo $DB?>"><i class="fa fa-globe" aria-hidden="true"></i> TOP PAGES</a>
                <a href="" class="btn btn-default btn-sm devices-details" id="<?php echo $site_name?>"><i class="fa fa-globe" aria-hidden="true"></i> DEVICES USED</a>
                <a href="" class="btn btn-default btn-sm similar-sites" id="<?php echo $website_category?>" data-cat="<?php echo $site_name?>"><i class="fa fa-globe" aria-hidden="true"></i> SIMILAR SITES</a>
                <a href="" class="btn btn-default btn-sm mobile-preview" id="<?php echo $DB?>"><i class="fa fa-globe" aria-hidden="true"></i> MOBILE PREVIEW</a>
                <a href="" class="btn btn-default btn-sm header-preview" id="<?php echo $site_name?>"><i class="fa fa-globe" aria-hidden="true"></i> HEADER PREVIEW</a>
                <br><br><br>
            </div>
            <div style="overflow-x:auto;">
                <table id="demo-table">
    				<thead>
    					<tr>
    						<th>URL</th>
    						<th class="text-success">Uptime</th>
    						<th class="text-danger">Downtime</th>
    						<th class="text-success">Load | Seconds </th>
    						<!--<th>Add Page </th>-->
    					</tr>
    				</thead>
        		<?php	
    				if(websiteUptime($site_name)){ ?>
        				<tbody>
        					<tr>
        						<td><span><?php echo strtoupper(goodUrl($site_name))?></span></td>
        						<td><span class="text-success">100 %</span></td>
        						<td><span class="text-danger">0 %</span></td>
        						<td><span class="text-success"><?php echo checkWebResponseTime($site_name)?></span></td>
        						<!--<td>+</td>-->
        					</tr>
        				</tbody>    
        		<?php
        			}else{?>
        				<tbody>
        					<tr>
        						<td><span><?php echo strtoupper(goodUrl($site_name))?></span></td>
        						<td><span>0%</span></td>
        						<td><span class="text-danger">100%</span></td>
        						<td><span class="text-success"><?php echo checkWebResponseTime($site_name)?></span></td>
        					</tr>
        				</tbody>			   
        		<?php
        			}
        			$query = mysqli_query($conn, "SELECT COUNT(user_ip) AS ip_add FROM ".$DB." GROUP BY user_ip ") or die(mysqli_error($conn));;
    	            $count_Ips = mysqli_num_rows($query);
        		?>
    		    </table>
    		</div>
            <div class="detailsDiv">
                <div class="col-md-6">
                    <div class="alert alert-success">
                        Total Visitors: <?php echo countTotalSiteView($conn, $DB)?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-info">
                        Unique Visitors: <?php echo $count_Ips; ?>
                    </div>
                </div>
                <h3 class="detailsHeader">Site Performance</h3>
                <div class="performance-result"></div>
                <div id="preview"></div>
            </div>
            
            <!--Chart End-->
            <!--Map Starts Here-->
                <div class="mapping">
                    <h3>Visits by Country</h3><hr>
                    <div id="vmap" style=""></div>
                    <div id="result">Hover or Click on Country</div>
                    <br><br>
                </div>
            <!--Map Ends Here-->
            <!--Modal To Show Countrie User Starts Here-->
            <div class="modal" tabindex="-1" role="dialog" id="CountriesDialog">
            	<div class="modal-dialog modal-lg" role="document">
            		<div class="modal-content">
            	  		<div class="modal-header">
            	    		<h3 class="text-center"><?php echo $site_name;?></h3>
            	    		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
            	      			<span aria-hidden="true">&times;</span>
            	    		</button>
            	  		</div>
            		  	<div class="modal-body">
            		    	<div id="modal-results"></div>
            		  	</div>
            		  	<div class="modal-footer">
            		    	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            		  	</div>
            		</div>
            	</div>
            </div>
            <!--Modal Ends Here-->
        </div>
    </div>
</div>
<?php
include("footer-profile.php");
?>
<link rel="stylesheet" href="maps/css/jqvmap.css" type="text/css"/>
<script type="text/javascript" src="maps/js/jquery.vmap.js"></script>
<script type="text/javascript" src="maps/js/jquery.vmap.world.js" charset="utf-8"></script>
<script type="text/javascript" src="maps/js/jquery.vmap.sampledata.js"></script>
<script>
    document.title = "<?php echo $url?>";

    jQuery(document).ready(function () {
    var DB = '<?php echo $DB?>';
    jQuery('#vmap').vectorMap({
	    map: 'world_en',
	    backgroundColor: '#a5bfdd',
	    borderColor: '#818181',
	    borderOpacity: 0.25,
	    borderWidth: 1,
	    color: '#f4f3f0',
	    enableZoom: true,
	    hoverColor: '#c9dfaf',
	    hoverOpacity: null,
	    normalizeFunction: 'linear',
	    scaleColors: ['#b6d6ff', '#005ace'],
	    selectedColor: '#c9dfaf',
	    selectedRegions: null,
	    showTooltip: true,
	    onRegionOver: function(element, code, region){
	        var message = 'You clicked "'
	            + region
	            + '" which has the code: '
	            + code.toUpperCase();
	        jQuery.ajax({
	            
	        	url:"includes/maps",
	        	method:"post",
	        	data:{region:region, DB:DB},
	        	success:function(data){
	                $("#result").html(region +"<br><span> Visitors:</span> "+data).addClass("data");
	        	}
	        });
	    },
	    onRegionClick: function(event, code, region){
	       jQuery.ajax({
	        	url:"includes/maps",
	        	method:"post",
	        	data:{region:region, DB:DB},
	        	success:function(data){
        	       $("#result").html(region +"<br><span> Visitors:</span> "+data ).addClass("data");
	        	}
	        }); 
	    }
        
	});
	$(document).on("click", ".country-details", function(event){
	    event.preventDefault();
	    var DBNAME = $(this).attr("id");
	    jQuery.ajax({
        	url:"includes/country-visitors",
        	method:"post",
        	data:{DBNAME:DBNAME},
        	beforeSend:function(){
				$("#loader").css("display", "block");
			},
        	success:function(data){
        	    $("#CountriesDialog").modal("show");
    	       $("#modal-results").html(data);
    	       $("#preview").hide();
    	       $("#loader").css("display", "none");
        	}
        });
	})
	
	//-------- top pages ---------
	
	$(document).on("click", ".page-details", function(event){
	    event.preventDefault();
	    var DBNAME = $(this).attr("id");
	    jQuery.ajax({
        	url:"includes/top-pages",
        	method:"post",
        	data:{DBNAME:DBNAME},
        	beforeSend:function(){
				$("#loader").css("display", "block");
			},
        	success:function(data){
        	    $(".performance-result").show().html(data);
        	    $("#preview").hide();
        	    $(".detailsHeader").html("TOP PAGES");
        	    $("#loader").css("display", "none");
        	}
        });
	})
	$(document).on("click", ".devices-details", function(event){
	    event.preventDefault();
	    var DBNAME = $(this).attr("id");
	    jQuery.ajax({
        	url:"includes/devices-used",
        	method:"post",
        	data:{DBNAME:DBNAME},
        	beforeSend:function(){
				$("#loader").css("display", "block");
			},
        	success:function(data){
        	    $(".performance-result").show().html(data);
        	    $("#preview").hide();
        	    $(".detailsHeader").html("DEVICES USED");
        	    $("#loader").css("display", "none");
        	}
        });
	});
	
	// check similar sites -----
	$(document).on("click", ".similar-sites", function(event){
	    event.preventDefault();
	    var website_link = '<?php echo $site_name?>';
        var website_category = $(this).attr("id");
	    jQuery.ajax({
        	url:"includes/web-other-sites",
        	method:"post",
        	data:{website_link:website_link, website_category:website_category},
        	beforeSend:function(){
				$("#loader").css("display", "block");
			},
        	success:function(data){
        	    $(".performance-result").show().html(data);
        	    $("#preview").hide();
        	    $(".detailsHeader").html("SIMILAR WEBSITES");
        	    $("#loader").css("display", "none");
        	}
        });
	});
    // Mobile view-------- 	
	$(document).on("click", ".mobile-preview", function(event){
	    event.preventDefault();
	    $("#preview").show();
	    var website_link = '<?php echo $site_name?>';
        bioMp(document.getElementById('preview'), {
    		url: website_link,
    	    image: 'wmp/images/iphone6_front_black.png',
    	    width: 330,
    	});
    	$(".performance-result").hide();
    	$(".detailsHeader").html("MOBILE PREVIEW");
    	$("#loader").css("display", "none");
	});
	
	// Preview header ------
	$(document).on("click", ".header-preview", function(event){
	    event.preventDefault();
	    var site_url = $(this).attr("id");
	    jQuery.ajax({
        	url:"includes/web-preview",
        	method:"post",
        	data:{site_url:site_url},
        	beforeSend:function(){
				$("#loader").css("display", "block");
			},
        	success:function(data){
        	    $(".performance-result").show().html(data);
        	    $("#preview").hide();
        	    $(".detailsHeader").html("WEBSITE META TAGS");
        	    $("#loader").css("display", "none");
        	}
        });
	});
	
  });
  
  
  function chatData(){
      var DBNAME = "<?php echo $DB?>";
      jQuery.ajax({
        	url:"includes/chartphp",
        	method:"post",
        	data:{DBNAME:DBNAME},
        	beforeSend:function(){
				$("#loader").css("display", "block");
			},
        	success:function(data){
    	       $(".performance-result").show().html(data);
    	       $("#preview").hide();
    	       $("#loader").css("display", "none");
        	}
        });
  }
  chatData();
</script>

