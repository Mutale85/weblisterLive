<?php
include 'header.php';
?>
<style>
	.all-listed-sites {
		margin:60px auto;
		/*border:1px solid #fff;*/
		/*background: #fff;*/
		padding: 40px;
		padding-bottom: 40px;
		border-radius: 5px;
		font-family: 'Source Code Pro', monospace;
	}
	.typewriter {
		font-size:50px;
		font-family: roboto;
		color: #1a3864;
		text-shadow: 2px 2px 2px #fff;
	}
	.all-listed-sites p i {
		color: #ccc;
	}
	.allSites a {
		font-size: 18px;
	}
	@media(max-width: 768px){
		.all-listed-sites {
			margin:60px auto;
			border:1px solid #fff;
			background: #fff;
			padding: 40px;
			padding-bottom: 40px;
			border-radius: 5px;
			font-family: 'Source Code Pro', monospace;
		}
		.typewriter {
			font-size:30px;
			font-family: roboto;
			color: #1a3864;
			text-shadow: 2px 2px 2px #fff;
		}
		.allSitesTitle {
			color: red;
			text-align: center;
		}
		.all-listed-sites ol li{
			margin-left: -30px;
		}
		.allSites a {
			color: red;
			font-size: 16px;
		}
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="all-listed-sites">
				<h1 class="text-center typewriter"> <span>Your best websites</span> directory</h1><br><br>
				<div class="form-group">
					<div class="input-group">
						<input type="search" name="find_site" id="find_site" class="form-control" placeholder="Enter website URL or name">
						<div class="input-group-addon search"><i class="fa fa-search" aria-hidden="true"></i></div>
					</div>
					<p><i>Enter URL or website name or search by category e.g, technology, education, music.</i></p>
				</div>
				<div class="displayAllsites"></div>
			</div>
		</div>
	</div>
</div>
<script>
	
</script>