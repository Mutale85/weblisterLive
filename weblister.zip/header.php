<?php
ob_start();
include 'includes/db.php';
if (isset($_SESSION['username'])) {
	header("location:web-profile/".$_SESSION['username']);
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Monitoring Website Uptime and Count Website Visitors</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Primary Meta Tags -->

    <meta name="title" content="weblister.co - Monitoring Website Uptime and Count Website Visitors">
    <meta name="description" content="Webliters, Monitor website uptime and count website visitors. Check which devices are used to access your site.">
    <meta property="og:title" content="Weblister - Monitor website Uptime and Count Visitors">
    <meta property="og:description" content="Webliters, Monitor website uptime and count website visitors. Check which devices are used to access your site.">
    <meta property="og:keywords" content="computer device, mobile-phone device, tablet devices,">
    <meta property="og:image" content="https://www.weblister.co/images/icon_new.png">
    <meta name="description" content="Webliters, Monitor website uptime and count website visitors. Check which devices are used to access your site.">
    <meta property="twitter:title" content="Weblister - Monitor website Uptime and Count Visitors">
    <meta property="twitter:description" content="Webliters, Monitor website uptime and count website visitors. Check which devices are used to access your site.">
    <meta property="twitter:keywords" content="computer device, mobile-phone device, tablet devices,">
    <meta property="twitter:image" content="https://www.weblister.co/images/icon_new.png">
	<!--Google Index Verification-->
	<meta name="google-site-verification" content="4jbOUVKGHZ1jTvzMM-7zkqw_C3kEaEUeIRG93hKwxAI" />
	
	
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-3.3.7.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome.css">
	<link rel="icon" type="icon" href="images/icon_new.png">
	<link href='https://fonts.googleapis.com/css?family=Sofia' rel='stylesheet'>
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-3.3.7.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript" src="js/extension.js?url=https://weblister.co"></script>
</head>
<body class="main">
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<a href="https://weblister.co/" class="navbar-brand" title="weblister"><img src="images/icon_new.png" class="logo-img"> <span>Weblister√</span></a>
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="mainNavBar">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="https://weblister.co/#pricing" title="pricing"><i class="fa fa-credit-card fa-fw" aria-hidden="true"></i> Princing </a></li>
					<li><a href="demo" title="demo"><i class="fa fa-globe fa-fw" aria-hidden="true"></i> Demo </a></li>
					<li><a href="https://weblister.co/login" title="login"><i class="fa fa-sign-in fa-fw" aria-hidden="true"></i> Login </a></li>
					<li><a href="https://weblister.co/contact" title="contact"><i class="fa fa-envelope-o" aria-hidden="true"></i> Contact Us</a></li>
					<li><a href="https://weblister.co/create-tags" title="create-tags"><i class="fa fa-code fa-fw"></i> Create Tags</a></li>
					<li><a href=""></a></li>
				</ul>
			</div>
		</div>
	</nav><br><br>
	<style type="text/css">
		.main {
			background: #fff;
			/*background-image: url("images/floral-1814372_1280.jpg");*/
		}
		.navbar-fixed-top .navbar-header a.navbar-brand { font-size: 20px;}
		.navbar-fixed-top .navbar-nav li a { font-size: 18px; font-family: roboto;}
		.navbar-fixed-top {
			border: none;
			background: #fff;
			/*height: 75px;*/
		}
		.dark_mode {
			background: #23272A;
			color: #fff;
		}
		.url_class {
			color: #fff;
		}
		.logo-img {
			height: 110px;
			width: 110px;
			position: absolute;
			top: 0px;
			left: 15px;
		}
		.navbar-brand span {
			display: none;
		}
		.navbar-brand {
			font-family: oxygen;
		}

		@media(max-width: 768px){
			.navbar-fixed-top {
				background-color: #f8f8f8;
  				border-color: #e7e7e7; 
  				height: auto;
			}
			.navbar-brand img {
				width: 70px;
				height: 70px;
				margin-top: -15px;
			}
			.navbar-brand span {display: none;}
			.form-inline {
				margin-top: 15px;
				width: auto;
			}
			li a.home {display: none;}
		}
		/*from Index.php*/
		html {
		scroll-behavior: smooth;
    	}
    	.container {
    		background: #fff;
    	}
    
    	.main-container, .main-container-two {
    		margin: 60px auto;
    	}
    	.main-container-two img {
    		width: 100%;
    		height: 100%;
    	}
    	.main-container .h1 {
    		font-size:50px;
    		font-family: roboto;
    		color: #1a3864;
    		text-shadow: 2px 2px 2px #fff;
    	}
    
    	.webFormDiv {
    		margin-top: 50px;
    		border: 1px solid #ccc;
    		padding: 20px;
    		font-family: 'Source Code Pro', monospace;
    		color: #1a3864;
    		/*box-shadow: 0 0 5px;*/
    		margin-bottom: 60px;
    		border-radius: 5px;
    	}
    	
    	ul {
    		list-style: none;
    		font-size: 17px;
    		margin-left: -25px;
    		font-family: 'Source Code Pro', monospace;
    		color: #1a3864;
    	}
    	.login-btn {
    		margin: 20px auto;
    		width: 50%;
    		border: 2px solid #ccc;
    		background: #ccc;
    		padding: 7px;
    		border-radius: 4px;
    		font-size: 18px;
    		font-weight: bold;
    		font-family: 'Source Code Pro', monospace; 
    	}
    	.login_link:hover {text-decoration: none;}
    	.login-btn:hover {
    		background: transparent;
    	}
    	.url-error {
    		color: red;
    	}
    	.directory_link a {
    		font-size: 18px;
    		font-weight: bold;
    		font-family: 'Source Code Pro', monospace;
    	}
    	.directory_link a:hover {
    		text-decoration: none;
    	}
    	img.mobile-preview {
    		margin-left: auto;
    		margin-right: auto;
    		height: 450px;
    	}
    	img.image-demo {
    		width: 100%;
    		height: 100%;
    	}
    
    	/*--prices start here--*/
    	.price-grid {
    	    /*float: left;
    	    width: 31%;
    	    margin: 0% 2% 0% 0%;*/
    	    width: 33%;
    	    margin: 20px auto;
    	}
    	.priceing-table h1 {
    	    font-size: 3em;
    	    color: #fff;
    	    text-align: center;
    	    margin:1em 0em;
    	}
    	.priceing-table h3 {
    		color: #fff;
    	}
    	.priceing-table .paypal-form {
    		text-align: center;
    	}
    	.wthree {
    	    margin: 0% 0% 0% 0%;
    	}
    	.priceing-table-main {
    	    width:50%;
    	    margin: 0 auto;
    	}
    	.prices-head h2 {
    	    font-size: 2em;
    	    color: #68AE00;
    	    margin:0em 0em 1em 0.4em;
    	    font-family: 'Carrois Gothic', sans-serif;
    	}
    	.price-list ul {
    	    padding: 0px;
    	    list-style: none;
    	}
    	.price-gd-top .price-trial {
    		background: #6499cd;
    	}
    	.price-gd-top {
    	    /*background:#ecb412;*/
    	    background: #6499cd;
    	    text-align: center;
    	    border-radius: 5px 5px 0px 0px;
    	}
    	.price-gd-top h4 {
    	    font-size: 1.8em;
    	    color: #fff;
    	    padding: 0.4em 1em;
    	    /*background:#d29d05;*/
    	    background: #1a3864;
    	    border-radius: 5px 5px 0px 0px;
    	}
    	/*-- w3layouts --*/
    	.price-gd-top h3 {
    	    padding:0.2em 0em 0.1em 0em;
    	    font-size:2.5em;
    	    color: #fff;
    	}
    	.price-gd-top h5 {
    	    font-size: 1em;
    	    color: #fff;
    	    padding: 0.2em 0em 0.8em 0em;
    	}
    	.price-gd-bottom {
    	    background: #fff;
    	    text-align: center;
    	    padding: 1em 0em;
    	}
    	.price-gd-top.pric-clr2 h4 {
    	    background: #7d1e4a;
    	}
    	.price-gd-top.pric-clr2 {
    	    background:#96285b;
    	}
    	.price-selet.pric-sclr2 a {
    	    background: #7d1e4a;
    	}
    	.price-gd-top.pric-clr3 {
    	    background: #2d818a;
    	}
    	.price-gd-top.pric-clr3 h4 {
    	    background: #14646d;
    	}
    	.price-selet.pric-sclr3 a {
    	    background: #14646d;
    	}
    	.price-list ul li {
    	    padding: 0.5em 0em;
    	    font-size:0.9em;
    	    color: #545454;
    	}
    	.price-selet {
    	    padding: 1em 0em;
    	    text-align: center;
    	    background: #fff;
    	    border-radius: 0px 0px 5px 5px;
    	}
    	/*-- agileits --*/
    	.price-selet a {
    	    font-size: 1.1em;
    	    color: #fff;
    	    display: block;
    	}
    	.price-selet a {
    	    font-size: 0.9em;
    	    color: #ffffff;
    	    display: inline-block;
    	    padding: 0.5em 1.5em;
    	    background:#d29d05;
    	    border-radius: 3px;
    	}
    	.price-grid {
    	    margin-bottom: 3em;
    	}
    	.price-block {
    	    box-shadow: 0px 0px 2px 1px rgba(0,0,0,0.15);
    	    transition: 0.5s all;
    	    -webkit-transition: 0.5s all;
    	    -moz-transition: 0.5s all;
    	    -o-transition: 0.5s all;
    	}
    	.price-block:hover {
    	    transform: scale(1.1);
    	    -webkit-transform: scale(1.1);
    	    -moz-transform: scale(1.1);
    	    -o-transform: scale(1.1);
    	    -ms-transform: scale(1.1);
    	    z-index: 1;
    	}
    	.sample-code {
    		border-radius: 5px;
    	}
    	.codeArea {
    		/*background: #ccc;*/
    		/*color: #fff;*/
    		border-radius: 4px;
    		font-family: 'Source Code Pro', monospace;
    	}
    	.codeArea textarea{
    		width: 100%;
    		height: 60px;
    		resize: none;
    		border: none;
    		padding: 10px;
    	}
    	.footer {
    	    margin:30px auto;
    	}
    	/*Main Footer*/
    	.footer-container {
    	    /*background:#1a3864;*/
    	    background:#6499cd;
    	    font-family: 'Source Code Pro', monospace;
    	    color:#fff;
    	}
    	.main-footer {
    	    width:70%;
    	    margin:60px auto;
    	    padding-bottom:30px;
    	}
    	.main-footer ul {
    	    list-style:none;
    	}
    	.main-footer ul li a {
    	    color:#1a3864;
    	}
    	.main-footer ul li a:hover {
    	    text-decoration:none;
    	}
    	/*End of footer*/
    	@media(max-width: 767px){
    		.price-grid {
    			width: 100%;
    		}
    		.main-footer {
    		    width:100%;
    		}
    	}
	</style>

	<script>
		var pagename = window.location.hostname;
		var title = document.title;
		title = pagename;
		$('a[href*="#"]')
  // Remove links that don't actually link to anything
          .not('[href="#"]')
          .not('[href="#0"]')
          .click(function(event) {
            // On-page links
            if (
              location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
              && 
              location.hostname == this.hostname
            ) {
              // Figure out element to scroll to
              var target = $(this.hash);
              target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
              // Does a scroll target exist?
              if (target.length) {
                // Only prevent default if animation is actually gonna happen
                event.preventDefault();
                $('html, body').animate({
                  scrollTop: target.offset().top
                }, 1000, function() {
                  // Callback after animation
                  // Must change focus!
                  var $target = $(target);
                  $target.focus();
                  if ($target.is(":focus")) { // Checking if the target was focused
                    return false;
                  } else {
                    $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
                    $target.focus(); // Set focus again
                  };
                });
              }
            }
          });
	</script>