<!-- Add and Edit Site Modal -->
<div class="modal fade" id="sitesModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title text-center" id="siteModalLabel">Add New Website</h4>
			</div>
			<div class="modal-body">
				<form method="POST" id="MainForm">
					<div id="preview_data" class="text-center"></div>
					<div class="form-group">
						<label>CATEGORY</label>
						<select class="form-control" name="website_category" id="website_category" required="required">
							<option value="">Choose A Category</option>
							<option value="Blog">Blog</option>
							<option value="Education">Education</option>
							<option value="E-commerce">E-commerce</option>
							<option value="How To">How To</option>
							<option value="Life Style">Life Style</option>
							<option value="Medical">Medical</option>
							<option value="Music">Music</option>
							<option value="News">News</option>
							<option value="Personal">Personal</option>
							<option value="Technology">Technology</option>
							<option value="Other">Other</option>
						</select>
						<input type="hidden" name="site_id" id="site_id">
						<em id="cat_error"></em>
					</div>
					<div class="form-group addnew" style="display: none;">
						<label><i class="fa fa-external-link" aria-hidden="true"></i> LINK</label>
						<input type="text" name="website_link" onblur="is_valid_url(this.value)" id="website_link" class="form-control" placeholder="https://" required="required">
						<em>Add an active link</em> <em id="url-error"></em>
						<input type="hidden" name="user_id" id="user_id" value="<?php echo $_SESSION['user_id']?>">
					</div>
					<button class="btn btn-primary" type="button" id="submitBtn">SUBMIT SITE</button>
					<button class="btn btn-warning preview" type="button"><i class="fa fa-eye eye"></i> Preview</button>
					<button class="btn btn-success pull-right editBtn" type="button" style="display: none;"><i class="fa fa-pencil-square-o"> Edit</i></button>
					<button class="btn btn-primary update_site" type="button" style="display: none;">UPDATE SITE</i></button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!-- End Site Modal -->
<!-- start of metatags modal -->
<div class="modal fade" id="tagsModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Meta Tags</h4>
			</div>
			<div class="modal-body">
				<div class="metaTagsDiv">
					<form method="post" id="metaTagsForm">
						<div class="form-group">
							<label>Page Title</label>
							<input type="text" id="m_title" class="form-control">
						</div>
						<div class="form-group">
							<label>Page Description</label>
							<input type="text" id="m_description" class="form-control" placeholder="Page Description">
						</div>
						<div class="form-group">
							<label>Keywords</label>
							<input type="text" id="m_keywords" class="form-control" placeholder="Page keywords">
						</div>
						<div class="form-group">
							<label>Image Url</label>
							<input type="text" id="m_image" class="form-control" placeholder="http://www.example.com/image.jpg">
						</div>
					</form>
					<hr>
					<h2>Generated Meta Tags</h2>
					<div class="form-group">
						<textarea id="meta-tags" class="form-control" rows="8"></textarea>
					</div>
					<button type="button" class="btn btn-default copy_metas">Copy to Clipboard</button>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!-- end of metatags modal -->

<script type="text/javascript" src="wmp/biomp.js"></script>
<script>
		$(function () {

			$("button.navbar-toggle.collapsed").click(function(){
				$('.side-nav').toggle().addClass("aside-bg");
				
			});

			var aside = $('.side-nav');
			var	showAsideBtn = $('.show-side-btn-link');
			var	contents = $('#contents');
			var	_window = $(window);

			showAsideBtn.on("click", function (e) {
				e.preventDefault();
				$("#" + $(this).data('show')).toggleClass('hide_showAside');
				contents.toggleClass('marginDIV');
				aside.toggleClass("hide_showAside");
			});

			_window.on('resize', function () {
				if ($(window).width() > 768) {
					aside.css('display', 'block');
				}
			});

			// slide-bar
			var slideNavDropdown = $('.side-nav-dropdown');

		  	$('.side-nav .categories li').on('click', function () {

				var $this = $(this)

				$this.toggleClass('opend').siblings().removeClass('opend');

				if ($this.hasClass('opend')) {
				  	$this.find('.side-nav-dropdown').slideToggle('fast');
				  	$this.siblings().find('.side-nav-dropdown').slideUp('fast');
				} else {
				  	$this.find('.side-nav-dropdown').slideUp('fast');
				}
		  	}); 
		});

// Add New Site Modal -------------
		$(function(){
			$(".showSiteModal").click(function(e){
				e.preventDefault();
				$("#sitesModal").modal("show");
				$("#MainForm")[0].reset();
				$("#siteModalLabel").html("Add New Website");
				$(".addnew").css("display", "block");
			});

			//Add New Site 

			$(document).on("click", "#submitBtn", function(e){
				e.preventDefault();
				validate();
				$.ajax({
					url:"includes/add-new-site",
					method:"post",
					data:$("#MainForm").serialize(),
					beforeSend:function(){
				      	$("#loader").css("display", "block");
				    },
					success:function(data){
						$("#sitesModal").modal("hide");
						alert(data);
						mySites();
						$("#submitBtn").show();
						$(".preview").show();
						$(".update_site").hide();
						$("#MainForm")[0].reset();
						$("#loader").css("display", "block");
						$(".addnew").css("display", "none");
						websiteUptime();
						checkWebsiteResponseTime();
						performance();
					}
				})

			})
			// Editing ALready Existing Site
			$(document).on ("click", ".edit_site", function(e){
				e.preventDefault();
				var site_id = $(this).attr("id");
				$("#sitesModal").modal("show");
				$("#siteModalLabel").html("Edit "+site_id);
				$.ajax({
					url:"includes/editSite",
					method:"post",
					data:{site_id:site_id},
					dataType:"json",
					success:function(data){
						$("#site_id").val(data.web_id);
						$("#website_category").val(data.website_category);
						$("#website_link").val(data.website_link);
						$("#submitBtn").hide();
						$("#preview").hide();
						$(".update_site").show();
					}
				}) 
			})

			// Update the Site
			$(".update_site").click(function(){
				validate();
				$.ajax({
					url:"includes/web-edited",
					method:"post",
					data:$("#MainForm").serialize(),
					beforeSend:function(){
				      	// $("#loader").css("display", "block");
				    },
					success:function(data){
						alert(data);
						mySites();
						$("#sitesModal").modal("hide");
						$("#submitBtn").show();
						$(".preview").show();
						$(".update_site").hide();
						$("#MainForm")[0].reset();
						$("#loader").css("display", "none");
						checkWebsiteResponseTime();
						previewWebsite();
					}
				})
			})

			$(document).on("click", ".remove_url", function(){
				var remove_url_link = $(this).attr("id");
				if (confirm("You cannot reverse this decision")) {
					$.ajax({
						url:"includes/remove-url",
						method:"post",
						data:{remove_url_link:remove_url_link},
						success:function(data){
							alert(data);
							mySites();
							checkWebsiteResponseTime();
							previewWebsite();
							websiteUptime();
							performance();
						}
					})
				}else{
					return false;
				}
			})

			// preview site ------

			$(document).on("click", ".preview_site", function(e){
				e.preventDefault();
				
				var site_url = $(this).attr("id");
				$.ajax({
					url:"includes/web-preview",
					method:"post",
					data:{site_url:site_url},
					beforeSend:function(){
						$("#loader").css("display", "block");
					},
					success:function(data){
				        $(".site_header").css("display", "block").html("Website Headers Preview");
						$("#loader").css("display", "none");
						$("#performance").show().html(data);
				// 		$("#preview").hide();
						
					}
				})
			});
		})
		
        $(function(){
			$(document).on("click", ".compare_sites", function(e){
			    e.preventDefault();
				var website_link = $(this).attr("id");
				var website_category  = $(this).data("category")
				$.ajax({
					url:"includes/web-other-sites",
					method:"post",
					data:{website_link:website_link, website_category:website_category},
					beforeSend:function(){
				      	$("#loader").css("display", "block");
				    },
					success:function(data){
						$("#loader").css("display", "none");
						$(".site_header").html('<i class="fa fa-search-plus" aria-hidden="true"></i> Similar Site By Category');
						$("#performance").show().html(data);
				// 		$("#preview").hide();
					}
				})
			})
		})

		//Start of TagsModal
		$(function(){
			$(".showTagsModal").click(function(e){
				e.preventDefault();
				$("#tagsModal").modal("show");
				$("#metaTagsForm")[0].reset();
				jQuery("textarea").html("");
			});

			// Tags creation --------
			$("#metaTagsForm input").on("input", function(){
				var m_title = jQuery("#m_title").val();
				var m_description = jQuery("#m_description").val();
				var m_image = jQuery("#m_image").val();
				var m_keywords = jQuery("#m_keywords").val();

				var tags = "";

				tags += '<title>'+m_title+'</title>\n';
				tags += '<meta name="description" content="'+m_description+'">\n';
				tags += '<meta property="og:title" content="'+m_title+'">\n';
				tags += '<meta property="og:description" content="'+m_description+'">\n';
				tags += '<meta property="og:keywords" content="'+m_keywords+'">\n';
				tags += '<meta property="og:image" content="'+m_image+'">\n';

				tags += '<meta name="description" content="'+m_description+'">\n';
				tags += '<meta property="twitter:title" content="'+m_title+'">\n';
				tags += '<meta property="twitter:description" content="'+m_description+'">\n';
				tags += '<meta property="twitter:keywords" content="'+m_keywords+'">\n';
				tags += '<meta property="twitter:image" content="'+m_image+'">\n';


				jQuery("textarea").html(tags);
			});

			jQuery('.copy_metas').on('click', function() {
			  document.querySelector("#meta-tags").select();
			  document.execCommand('copy');
			  alert("Copied");
			});
		})
		//end of Tags Modal

		//Check all Listed Sites ----
		function mySites() {
			var mySites = "mySites";
			$.ajax({
				url:"includes/mylistedSites",
				method:"post",
				data:{mySites:mySites},
				success:function(data){
					$(".mylistedSites").html(data);
				}
			})
		}
		document.title = "<?php echo UserName($conn, $_SESSION['user_id']); ?>";
		mySites()

		// check number of clicks -----
		function numberofClick(){
			var numberofClicks = "numberofClicks";
			$.ajax({
				url:"includes/websites-page-click",
				method:"post",
				data:{numberofClicks:numberofClicks},
				success:function(data){
					$("#numberofClicks").html(data);
				}
			})
		}
		numberofClick();

		// check website runtime ----
		function websiteUptime(){
			var websiteUptime = "websiteUptime";
			$.ajax({
				url:"includes/web-availability-check",
				method:"post",
				data:{websiteUptime:websiteUptime},
			    beforeSend:function(){
			      // $("#loader").css("display", "block");
			    },
				success:function(response){
					$("#websiteUptime").html(response);
		      		$("#loader").css("display", "none");
				}
			})
		}
		websiteUptime();
		// setInterval(function(){
		// 	websiteUptime();
		// }, 100000);

		

		function checkWebsiteResponseTime(){
			var responseTime = "responseTime";
			$.ajax({
				url:"includes/response-time",
				method:"post",
				data:{responseTime:responseTime},
				beforeSend:function(){
					// $("#loader").css("display", "block");
				},
				success:function(data){
					// $("#loader").css("display", "none");
					$(".responseTime").html(data);
				}
			})
		}
		// checkWebsiteResponseTime();
		// setInterval(function(){
		// 	checkWebsiteResponseTime();
		// }, 100000);



    //---------------- MAIN FUNCTION SHOWING WEBSITE PERFORMANCE ----------
		function performance(){
			var performance = "performance";
			$.ajax({
				url:"includes/performance",
				method:"post",
				data:{performance:performance},
				beforeSend:function(){
					// $("#loader").css("display", "block");
				},
				success:function(data){
					$("#performance").html(data);
					$("#loader").css("display", "none");
					$(".site_header").html('<i class="fa fa-signal" aria-hidden="true"></i> Website Uptime Monitoring');
				}
			})
		}
// 		setInterval(function(){
// 		  performance();  
// 		}, 100000);
		performance();

		$(function(){
			$(document).on("click", ".check_pages", function(e){
				e.preventDefault();
				var website_url  = $(this).attr("id");
				$(".loadingSpan").css("display","block");
				$.ajax({
					url:"includes/website-pages-count",
					method:"post",
					data:{website_url:website_url},
					beforeSend:function(){
						// $("#loader").css("display", "block");
					},
					success:function(data){
						$(".website-pages").html(data).addClass("website-pages-div");
						$("#loader").css("display", "none");
					}
				})
			});

			//delete page-view
			$(document).on("click", ".delete_page_view", function(){
				var delete_page_view_id = $(this).attr("id");
				alert(delete_page_view_id);
			});
			
			// Devices Used ---------
			$(document).on("click", ".devices_used", function(event){
        	    event.preventDefault();
        	    var DBNAME = $(this).attr("id");
        	    jQuery.ajax({
                	url:"includes/devices-used",
                	method:"post",
                	data:{DBNAME:DBNAME},
                	beforeSend:function(){
    					$("#loader").css("display", "block");
    				},
                	success:function(data){
                	    $("#performance").show().html(data);
                	   // $("#preview").hide();
                	    $("#loader").css("display", "none");
                	    $(".site_header").html(' Devices Used');
                	}
                });
        	});
        	
        	// ------- Mobile View---------
        	// Mobile view-------- 	
        	$(document).on("click", ".mobile_preview", function(event){
        	    event.preventDefault();
        	    $("#preview").show();
        	    var website_link = $(this).attr("id");
        	    jQuery.ajax({
                	url:"includes/mobile-preview",
                	method:"post",
                	data:{website_link:website_link},
                	beforeSend:function(){
    					$("#loader").css("display", "block");
    				},
                	success:function(data){
                	    $("#performance").show().html(data);
                	   // $("#preview").hide();
                	    $("#loader").css("display", "none");
                	    $(".site_header").html(website_link+ ' Mobile View');
                	}
                });
        	});
        	
        	// countries - views
        	$(document).on("click", ".country_details", function(event){
        	    event.preventDefault();
        	    var DBNAME = $(this).attr("id");
        	    jQuery.ajax({
                	url:"includes/country-visitors",
                	method:"post",
                	data:{DBNAME:DBNAME},
                	
                	success:function(data){
                	    $("#CountriesDialog").modal("show");
            	       $("#modal-results").html(data);
            	       $("#site_name").html("Countries")
                	}
                });
        	})
        	// page-details
        	$(document).on("click", ".page_details", function(event){
        	    event.preventDefault();
        	    var DBNAME = $(this).attr("id");
        	    jQuery.ajax({
                	url:"includes/top-pages",
                	method:"post",
                	data:{DBNAME:DBNAME},
                	beforeSend:function(){
    					$("#loader").css("display", "block");
    				},
                	success:function(data){
                	    $("#performance").show().html(data);
                	    $("#loader").css("display", "none");
                	    $(".site_header").html(' Top Pages');
                	}
                });
        	})
			
		})
	</script>
</body>
</html>