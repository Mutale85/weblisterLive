<?php include 'header.php'; ?>
<style type="text/css">
	textarea {resize: none;}
</style>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="form-div">
					<h2 class="text-center">Add Your Website Link</h2><hr>
					<form method="POST" id="MainForm">
						<div id="preview_data" class="text-center"></div>
						<div class="form-group">
							<label>CATEGORY</label>
							<select class="form-control" name="website_category" id="website_category" required="required">
								<option value="">Choose A Category</option>
								<option value="Blog">Blog</option>
								<option value="Education">Education</option>
								<option value="E-commerce">E-commerce</option>
								<option value="How To">How To</option>
								<option value="Life Style">Life Style</option>
								<option value="Medical">Medical</option>
								<option value="Music">Music</option>
								<option value="News">News</option>
								<option value="Personal">Personal</option>
								<option value="Technology">Technology</option>
								<option value="Other">Other</option>
							</select>
							<em id="cat_error"></em>
						</div>
						<div class="form-group">
							<label><i class="fa fa-external-link" aria-hidden="true"></i> LINK</label>
							<input type="text" name="website_link" onblur="is_valid_url(this.value)" id="website_link" class="form-control" placeholder="https://" required="required">
							<em>Add an active link</em> <em id="url-error"></em>
						</div>
						<div class="form-group">
							<label>ABOUT THE SITE</label>
							<textarea class="form-control" rows="4" name="description" id="description" required="required" placeholder="Write a brief description abou the website"></textarea>
							<em>Not More than 100 words.</em>
						</div>
						<div class="form-group captcha">
							<label>Prove You Are Human</label>
                      		<div class="input-group">
                      			<span class="input-group-addon" style="padding:0; margin: 0;">
			          				<img src="captcha.php" id="captcha_image" />
			         			</span>
                       			<input type="text" name="captcha_code" id="captcha_code" class="form-control" placeholder="Enter code" required="required">
                   				<span class="input-group-addon" style="padding:5">
			          				<a href="#" class="reload-captcha pull-right" onclick="captcha_image();return false "><i class="fa fa-refresh"></i></a>
			         			</span>
				            </div>
				        </div>
						<button class="btn btn-primary" type="submitBtn" id="submitBtn">SUBMIT SITE</button>
						<button class="btn btn-warning preview" type="button"><i class="fa fa-eye eye"></i> Preview</button>
						<button class="btn btn-success pull-right editBtn" type="button" style="display: none;"><i class="fa fa-pencil-square-o"> Edit</i></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>