$(document).ready(function(){
	$("#submitBtn").attr("disabled", "disabled");
	$("#website_category").change(function() {
		if ($(this).val() != "") {
			$("#submitBtn").removeAttr("disabled");
		}else{
			$("#submitBtn").attr("disabled", "disabled");
		}
	})

	$("#MainForm").on("submit", function(event){
		event.preventDefault();
		var website_category = $('#website_category').val();
		var url = $('#website_link').val();
		var pattern = /^((http|https|ftp):\/\/)/;

		if (website_category == "") {
			$("#cat_error").html("Select your category").addClass("danger_url");
			return false;
		}

		if (url == "") {
			$("#url-error").html("Enter Your Url").addClass("danger_url");
			return false;
		}
		
		if(!pattern.test(url)) {
		    $("#url-error").html("Url must start with http:// or https://").addClass("danger_url");
			return false;
		}

		if(url.match(/^(ht|f)tps?:\/\/[a-z0-9-_\.]+\.[a-z]{2,4}\/?([^\s<>\#%"\,\{\}\\|\\\^\[\]`]+)?$/)){
 			$("#url-error").html("");
 		}else{
 			$("#url-error").html("Invalid Url").addClass("danger_url");
 			return false;
 		}

		$.ajax({
			url:"includes/web-process",
			method:"post",
			data:$(this).serialize(),
			beforeSend:function(){
				$("#submitBtn").html("<i class='fa fa-spinner fa-spin' aria-hidden='true'></i>");
			},
			success:function(data){
				alert(data);
				mySites();
				$("#submitBtn").html('SUBMIT SITE');
				$("#MainForm")[0].reset();
				display_sites();
			}
		})
	})

	$(".preview").click(function(){
		var website_category = $('#website_category').val();
		var url = $('#website_link').val();
		// var description = $('#description').val();
		var captcha_code = $("#captcha_code").val();
		if (website_category == "" || url == "" || captcha_code == "") {
			alert("All fields are required");
			return false;
		}else{
			$(".form-group").hide();
			$("#preview_data").html("<h4>Category: "+ website_category + " | Url: <a href="+url+" target='_blank'>"+url+"</a>").addClass("preview_class");
			$(".preview").hide();
			$(".editBtn").css("display","block");
		}
	})
	$(".editBtn").click(function(){
		$(this).hide();
		$(".form-group").show();
		$(".preview").show();
		$("#preview_data").html("").removeClass("preview_class");
	})
})

function is_valid_url(url){

		if(url.match(/^(ht|f)tps?:\/\/[a-z0-9-_\.]+\.[a-z]{2,4}\/?([^\s<>\#%"\,\{\}\\|\\\^\[\]`]+)?$/)){
			$("#url-error").html("");
		}else{
			$("#url-error").html("Url must start with http:// or https:// and should be in lowercase.").addClass("url-error");
			return false;
		}
}

function captcha_image(){
	document.getElementById('captcha_image').src='captcha?'+Math.random();
	$(".fa-refresh").toggleClass("fa-spin");
}

function validate() {
	var website_category = $('#website_category').val();
	var url = $('#website_link').val();
	var pattern = /^((http|https|ftp):\/\/)/;
	var description = $("#description").val();

	if (website_category == "") {
		$("#cat_error").html("Select your category").addClass("danger_url");
		return false;
	}

	if (url == "") {
		$("#url-error").html("Enter Your Url").addClass("danger_url");
		return false;
	}
	if (description == "") {
		$("#description-error").html("Write a short description of your site").addClass("danger_url");
		return false;
	}
	
	if(!pattern.test(url)) {
	    $("#url-error").html("Url must start with http:// or https://").addClass("danger_url");
		return false;
	}

	if(url.match(/^(ht|f)tps?:\/\/[a-z0-9-_\.]+\.[a-z]{2,4}\/?([^\s<>\#%"\,\{\}\\|\\\^\[\]`]+)?$/)){
		$("#url-error").html("");
	}else{
		$("#url-error").html("Invalid Url").addClass("danger_url");
		return false;
	}
}


// display websites

function display_sites(){
	var display_sites = "display_sites";
	$.ajax({
		url:"includes/web-fetch",
		method:"post",
		data:{display_sites:display_sites},
		success:function(data){
			$(".display_sites").html(data);
		}
	})
}
display_sites();

function displayAllsites(){
	var displayAllsites = "displayAllsites";
	$.ajax({
		url:"includes/web-fetch",
		method:"post",
		data:{displayAllsites:displayAllsites},
		success:function(data){
			$(".displayAllsites").html(data);
		}
	})
}
displayAllsites();

// ------- INDEX SEARCH FORM AND CLICKS VIEW REPORT --------------

$(function(){
	$(".search").click(function(){
		var search = $("#find_site").val();
		if (search == "") {
			alert("Enter url or website name");
			return false;
		}
		if (search.length < 3) {
			alert("url or website name should be more than 3 characters");
			return false;
		}

		$.ajax({
			url:"includes/web-search",
			method:"post",
			data:{search:search},
			beforeSend:function(){
				$(".fa-search").addClass("fa-spinner fa-spin");
			},
			success:function(data){
				$('.displayAllsites').html(data);
				$(".fa-search").removeClass("fa-spinner fa-spin");
			}
		})
	});

	if ($("#search").val() == "") {
		displayAllsites();
	}

});



var counter = {};

function manageClicks(url) {
	if (! counter[url]) counter[url] = 0;
	counter[url] ++;
	var site_url = url;
	var clicks = counter[url];
	var operating_system = opSystem();
	$.ajax({
		url:"includes/web-clicks",
		method:"post",
		data:{site_url:site_url, clicks:clicks, operating_system:operating_system},
		success:function(data){
			window.open(url);
		}
	})
}

function opSystem() {
	var operating_system = navigator.userAgent;
	var element = document.getElementById("check_deveice");
	var isMobile = /Android|webOS|iPhone|iPad|iPod/i.test(operating_system);
	var device = navigator.platform;
	return operating_system;
}
opSystem();



/// Check if site is avaliable

function siteAvailable(){
	var siteAvailable = "siteAvailable";
	$.ajax({
		url:"includes/web-availability-check",
		method:"post",
		data:{siteAvailable:siteAvailable},
		success:function(response){
			$("#siteAvailable").html(response);
		}
	})
}
// setInterval(function(){
// 	siteAvailable();
// }, 10000);

