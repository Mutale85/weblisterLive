function opSystem() {
    var operating_system = navigator.userAgent;
    var element = document.getElementById("check_device");
    var isMobile = /Android|webOS|iPhone|iPad|iPod/i.test(operating_system);
    var device = navigator.platform;
    return operating_system;
}
opSystem();

var url = window.location.href;
var seconds = 1000;
document.addEventListener('readystatechange', function() { 
    
    console.log(url + " Ready in '" + document.readyState + "' after " + performance.now() / seconds + " S"); 
    
});

document.addEventListener('DOMContentLoaded', function() { 
    console.log(url + " Content Loaded in: " + performance.now() / seconds + " S"); 
    
}, false);

var scrTags = document.getElementsByTagName("script");
var src = scrTags[scrTags.length-1].src;
var URL = unescape(src).split("url=")[1].split("&")[0];

window.addEventListener('load', function() { 
    var pageloadTime        = performance.now() / seconds + " Seconds";
    var pageUrl             =  url;
    var site_name           = window.location.hostname;
    var operating_system    = opSystem();

    $.ajax({
        type: 'GET',
        url: 'https://weblister.co/includes/web-page-speed',
        data:{URL:URL, pageloadTime:pageloadTime, pageUrl:pageUrl, site_name:site_name, operating_system:operating_system},
        dataType: 'jsonp',
        crossDomain: true,
        success:function(data){
        
        }
    })
    
}, false); 