<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
date_default_timezone_set('Africa/Lusaka');
include("header-profile.php");

?>
<style>
    .response_time {
        box-shadow:0 0 4px;
        padding:10px;
        border-radius:4px;
        margin:20px auto;
        width:60%;
    }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="dislayAllListedSites"></div>
    </div>
</div>
<?php
    include("footer-profile.php");
?>
<script>
    function dislayAllListedSites(){
        var dislayAllListedSites = "dislayAllListedSites";
        $.ajax({
            url:"includes/dislayAllListedSites",
            method:"post",
            data:{dislayAllListedSites:dislayAllListedSites},
            beforeSend:function(){
                $("#loader").css("display", "block");
            },
            success:function(data){
                $(".dislayAllListedSites").html(data);
                $("#loader").css("display", "none");
            }
        })
    }
    dislayAllListedSites();
    $(function(){
        $(document).on("click", ".remove-site", function(){
            var site_owner_email = $(this).attr("id");
            var site_link = $(this).data("site");
            if(confirm("You are about to remove this "+ site_link+ " from weblister")){
                $.ajax({
                    url:"includes/remove-url",
                    method:"post",
                    data:{site_owner_email:site_owner_email, site_link:site_link},
                    beforeSend:function(){
                        $("#loader").css("display", "block");
                    },
                    success:function(data){
                        $("#loader").css("display", "none");
                        dislayAllListedSites();  
                    }
                })
            }else{
                
            }
        })
    })
</script>


