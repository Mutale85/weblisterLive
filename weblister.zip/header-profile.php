<base href="https://weblister.co/">
<?php
$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$start = $time;

include 'includes/db.php';
if (!isset($_SESSION['username'])) {
	header("location:../");
}
// Count days remain on Plan
$start_date =  $end_date =  $time_left = $days = $current_date = $today = $message = $plan = $user_role = $role = "";

$query = $conn->prepare("SELECT * FROM web_directory WHERE user_email = ?") or die(mysqli_error($conn));
$query->bind_param("s", $_SESSION['email']);
$query->execute();
$result = $query->get_result();
$site_link = "";
foreach ($result as $row) {
	$plan = $row['plan'];
	$start_date = strtotime($row['start_date']);
	$end_date = strtotime($row['end_date']);
	$website_link =  $row['website_link'];
	$today = strtotime("now");
    $end_date = strtotime($row['end_date']);
    $daysGone =  $end_date - $today;
    $remaining_days = floor($daysGone/(60*60*24));
    $url = preg_replace("#[^0-9a-zA-Z_]#", "_", goodUrl($row['website_link']));
    $site_link .= '<li><a href="site-performance?site-url='.$row['website_link'].'" class="site_url_pef" id="'.$row['website_link'].'"><i class="fa fa-globe fa-fw"></i>'.$row["website_link"].'</a><li>';

	if ($today > $end_date) {
        $message = "Subscription Ended ".$days_remaining." <br>";
        setcookie(goodUrl($website_link)."_ExpiredSubscription", $remaining_days);
        // $_SESSION['ExpiredSubscriptionXsxxxsffsf'];
    }else{
    	$message = "Days: ".$remaining_days;
    }
    
}

$sql = $conn->prepare("SELECT * FROM `members_list` WHERE email  = ? ");
$sql->bind_param("s", $_SESSION['email']);
$sql->execute();
$result = $sql->get_result();
foreach ($result as $row) {
    $user_role = $row['user_role'];
    if($row['user_role'] == "super_admin"){
        $role = '<li><a href="test-all-sites"><i class="fa fa-globe fa-fw" aria-hidden="true"></i> All Websites</a></li>';
    }elseif($row['user_role'] == "user"){
        $role = '';
    }else{
       $role = ''; 
    }
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Sites Profile</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="We are about creating a directory for websites">
	<meta property="og:title" content="Weblister">
	<meta property="og:description" content="We are about creating a directory for websites">
	<meta property="og:keywords" content="website directory, websites directory, online directory">
	<meta property="og:image" content="https://weblister.co/images/icon_new.png">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-3.3.7.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome.css">
	<link rel="icon" type="icon" href="images/icon_new.png">
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-3.3.7.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript" src="js/chart.js"></script>
	<style>
		/*side naviation*/
		.side-nav {
			float: left;
			height: 100%;
			width: 290px;
			box-shadow: 0 0 5px;
			color: #CCC;
			-webkit-transform: translateX(0);
			-moz-transform: translateX(0);
			transform: translateX(0);
			-webkit-transition: all .3s ease-in-out;
			-moz-transition: all .3s ease-in-out;
			transition: .3s;
			position: fixed;
			top: 0;
			left: 0;
			overflow: auto;
			z-index: 9999999
		}
		.side-nav .close-aside {
			position: absolute;
			top: 7px;
			right: 7px;
			cursor: pointer;
			color: #EEE;
		}
		.side-nav .heading {
			box-shadow: 0 0 5px;
			padding: 10px;
			overflow: hidden;
		}
		.side-nav .heading img {
			border-radius: 50%;
			height: 40px;
			margin-right: auto;
			margin-left: auto;
			width: 40px;
		}
		/* End heading */

		/*section styling-----*/
		::-webkit-scrollbar {
			background: transparent;
			width: 5px;
			height: 5px;
		}
		::-webkit-scrollbar-thumb {
			background-color: #888;
		}
		::-webkit-scrollbar-thumb:hover {
			background-color: rgba(0, 0, 0, 0.3);
		}

		#contents {
			position: relative;
			transition: .3s;
			margin-left: 290px;
		}
		.marginDIV {
			margin-left: 0 !important;
		}


		/*side nav categories*/
		.categories {
			list-style: none;
			font-family: 'Droid Sans', sans-serif;
		}
		.categories li a.siteLink {
			color: #6499cd;
			font-size: 18px;
		}
		.categories li a.siteLink:hover {
			text-decoration: none;
		}
		.categories li a.siteLink:active {
			text-decoration: none;
		}
		.categories li a.siteLink:link {
			text-decoration: none;
		}
		.side-nav .categories > li {
			padding: 10px;
			overflow: hidden;
			border-bottom: 1px solid rgba(255, 255, 255, 0.5);
			cursor: pointer;
			margin-left: -20px;
		}
		.categories > li > a {
			color: #6499cd;
			font-size: 18px;
		}

		.side-nav .categories > li > a:hover {
			color: #6499cd;
			text-decoration: none;

		}
		.side-nav .categories > li > i {
			font-size: 18px;
			margin-right: 5px
		}
		.side-nav .categories li a.siteLink:after {
			/*content: "\f149";*/
			/*font-family: fontAwesome;*/
			font-size: 18px;
			/*line-height: 1.8;*/
			/*float: right;*/
			/*color: #AAA;*/
			-webkit-transition: all .3s ease-in-out;
			-moz-transition: all .3s ease-in-out;
			transition: all .3s ease-in-out;
		}
		.side-nav .categories .opend > a:after {
			-webkit-transform: rotate(-90deg);
			-moz-transform: rotate(-90deg);
			transform: rotate(-90deg);
		}

		.hide_showAside {
			display: none;
			-webkit-transition: all .3s ease-in-out;
			-moz-transition: all .3s ease-in-out;
			transition: all .3s ease-in-out;
		}
			/* End categories */
			/* Start dropdown menu */
		.side-nav .categories .side-nav-dropdown {
			padding-top: 10px;
			padding-left: 30px;
			list-style: none;
			display: none;
		}
		.side-nav .categories .side-nav-dropdown > li > a {
			color: #AAA;
			text-decoration: none;
			padding: 7px 0;
			display: block;
		}
		/* End dropdown menu */

		/*loaders -----*/
		#loader {
			position: absolute;
			left: 50%;
			top: 50%;
			z-index: 1;
			width: 150px;
			height: 150px;
			margin: -75px 0 0 -75px;
			border: 16px solid #f3f3f3;
			border-radius: 50%;
			border-top: 16px solid #3498db;
			width: 120px;
			height: 120px;
			-webkit-animation: spin 2s linear infinite;
			animation: spin 2s linear infinite;
			display: none;
		}

		@-webkit-keyframes spin {
			0% { -webkit-transform: rotate(0deg); }
			100% { -webkit-transform: rotate(360deg); }
		}

		@keyframes spin {
			0% { transform: rotate(0deg); }
			100% { transform: rotate(360deg); }
		}

		/* Add animation to "page content" */
		.animate-bottom {
			position: relative;
			-webkit-animation-name: animatebottom;
			-webkit-animation-duration: 1s;
			animation-name: animatebottom;
			animation-duration: 1s
		}

		@-webkit-keyframes animatebottom {
			from { bottom:-100px; opacity:0 } 
			to { bottom:0px; opacity:1 }
		}

		@keyframes animatebottom { 
			from{ bottom:-100px; opacity:0 } 
			to{ bottom:0; opacity:1 }
		}
		/*end of loader*/

		/*preview Image*/
		img.previewImage {
			width: 110px;
			height: 110px;
		}

		/*performance.php*/
		.well-performance {
			border:1px solid #ccc;
			width: 60%;
			margin:40px auto;
			padding: 20px;
			min-height: 250px;
			box-shadow: 0 0 2.5px;
			border-radius: 4px;
		}

		/*web-pages.php*/
		.website-pages-div {
			/*border:1px solid red;*/
			padding: 20px;
			box-shadow: 0 0 3px;
			width:60%;
			margin:20px auto;
		}

		/*--prices start here--*/
		.price-grid {
		    float: left;
		    width: 31%;
		    margin: 0% 2% 0% 0%;
		}
		.priceing-table h1 {
		    font-size: 3em;
		    color: #fff;
		    text-align: center;
		    margin:1em 0em;
		}
		.priceing-table h3 {
			color: #fff;
		}
		.priceing-table .paypal-form {
			text-align: center;
		}
		.wthree {
		    margin: 0% 0% 0% 0%;
		}
		.priceing-table-main {
		    width:50%;
		    margin: 0 auto;
		}
		.prices-head h2 {
		    font-size: 2em;
		    color: #68AE00;
		    margin:0em 0em 1em 0.4em;
		    font-family: 'Carrois Gothic', sans-serif;
		}
		.price-list ul {
		    padding: 0px;
		    list-style: none;
		}
		.price-gd-top .price-trial {
			background: #6499cd;
		}
		.price-gd-top {
		    /*background:#ecb412;*/
		    background: #6499cd;
		    text-align: center;
		    border-radius: 5px 5px 0px 0px;
		}
		.price-gd-top h4 {
		    font-size: 1.8em;
		    color: #fff;
		    padding: 0.4em 1em;
		    /*background:#d29d05;*/
		    background: #1a3864;
		    border-radius: 5px 5px 0px 0px;
		}
		/*-- w3layouts --*/
		.price-gd-top h3 {
		    padding:0.2em 0em 0.1em 0em;
		    font-size:2.5em;
		    color: #fff;
		}
		.price-gd-top h5 {
		    font-size: 1em;
		    color: #fff;
		    padding: 0.2em 0em 0.8em 0em;
		}
		.price-gd-bottom {
		    background: #fff;
		    text-align: center;
		    padding: 1em 0em;
		}
		.price-gd-top.pric-clr2 h4 {
		    background: #7d1e4a;
		}
		.price-gd-top.pric-clr2 {
		    background:#96285b;
		}
		.price-selet.pric-sclr2 a {
		    background: #7d1e4a;
		}
		.price-gd-top.pric-clr3 {
		    background: #2d818a;
		}
		.price-gd-top.pric-clr3 h4 {
		    background: #14646d;
		}
		.price-selet.pric-sclr3 a {
		    background: #14646d;
		}
		.price-list ul li {
		    padding: 0.5em 0em;
		    font-size:0.9em;
		    color: #545454;
		}
		.price-selet {
		    padding: 1em 0em;
		    text-align: center;
		    background: #fff;
		    border-radius: 0px 0px 5px 5px;
		}
		/*-- agileits --*/
		.price-selet a {
		    font-size: 1.1em;
		    color: #fff;
		    display: block;
		}
		.price-selet a {
		    font-size: 0.9em;
		    color: #ffffff;
		    display: inline-block;
		    padding: 0.5em 1.5em;
		    background:#d29d05;
		    border-radius: 3px;
		}
		.price-grid {
		    margin-bottom: 3em;
		}
		.price-block {
		    box-shadow: 0px 0px 2px 1px rgba(0,0,0,0.15);
		    transition: 0.5s all;
		    -webkit-transition: 0.5s all;
		    -moz-transition: 0.5s all;
		    -o-transition: 0.5s all;
		}
		.price-block:hover {
		    transform: scale(1.1);
		    -webkit-transform: scale(1.1);
		    -moz-transform: scale(1.1);
		    -o-transform: scale(1.1);
		    -ms-transform: scale(1.1);
		    z-index: 1;
		}
		/*subscription div*/
		.subscription {
			margin:20px auto;
		}
		
		/*views and web-pages*/
		.pagelinkDiv {
            border:1px solid #ccc;
            padding:7px;
            margin:10px auto;
            border-radius:5px;
        }
        /*navigation with colors*/
        .navigation {
            list-style: none;
            margin: 0px;
            padding: 0px;
        }
        
        .navigation li{
            float: none; 
            width: 100%;
        }
        .navigation li.dropdown ul.dropdown-menu {
            z-index:999;
            box-shadow:0 0 4px;
            padding:4px;
            border-radius:4px;
        }
        /*.navigation li.dropdown ul.dropdown-menu li{*/
        /*    border:5px solid red;*/
        /*}*/
        
        .navigation li a{
            display: block; 
            width: 100%; 
            padding: 20px; 
            border-left: 5px solid; 
            position: relative; 
            z-index: 2;
            text-decoration: none;
            color: #444;
            box-sizing: border-box;  
            -moz-box-sizing: border-box;  
            -webkit-box-sizing: border-box; 
        }
        	
        .navigation li a:hover{ border-bottom: 0px; color: #fff;}
        .navigation li:first-child a{ border-left: 10px solid #3498db; }
        .navigation li:nth-child(2) a{ border-left: 10px solid #ffd071; }
        .navigation li:nth-child(3) a{ border-left: 10px solid #f0776c; }
        .navigation li:nth-child(4) a{ border-left: 10px solid #ffd071; }
        .navigation li:nth-child(5) a{ border-left: 10px solid #f0776c; }
        .navigation li:nth-child(6) a{ border-left: 10px solid #3498db; }
        .navigation li:last-child a{ border-left: 10px solid #1abc9c; }
        
        .navigation li a:after { 
          content: "";
          height: 100%; 
          left: 0; 
          top: 0; 
          width: 0px;  
          position: absolute; 
          transition: all 0.3s ease 0s; 
          -webkit-transition: all 0.3s ease 0s; 
          z-index: -1;
        }
        
        .navigation li a:hover:after{ width: 100%; }
        .navigation li:first-child a:after{ background: #3498db; }
        .navigation li:nth-child(even) a:after{ background: #ffd071; }
        .navigation li:nth-child(odd) a:after{ background: #f0776c; }
        .navigation li:last-child a:after{ background: #1abc9c; }
        /*end of navigation-------*/
		
		/* Start media query */
		@media (max-width: 767px) {
			.side-nav {
				display: none;
				background: #fff;
			}
			.side-nav .categories > li {
				padding-top: 12px;
				padding-bottom: 12px;
			}
			.side-nav .search {
				padding: 10px 0 10px 30px
			}
			#contents {
				margin: 0 !important
			}
			.statistics .box {
				margin-bottom: 25px !important;
			}
			.navbar-default .navbar-nav .open .dropdown-menu>li>a {
				color: #CCC !important
			}
			.navbar-default .navbar-nav .open .dropdown-menu>li>a:hover {
				color: #FFF !important
			}
			.navbar-default .navbar-toggle{
				border:none !important;
				color: #EEE !important;
				font-size: 18px !important;
			}
			.navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle:hover {background-color: transparent !important}
			.logout-li {
				display: block;
			}
			#bs-example-navbar-collapse-1 {
				display: none;
			}
			.aside-bg {
				z-index: 999999;
				background: #fff;
			}
			.websites_wrapper button {
				margin-top: 5px;
			}
			.well-performance { 
				width: 100%;
			}
			.website-pages-div {
				width: 100%;
			}

			.price-grid {
				width: 100%;
			}

		}

	</style>
</head>
<body>
	<aside class="side-nav" id="show-side-navigation1">
		<div class="heading">
			<a href="web-profile"><img src="images/icon_new.png" class="logo-img"></a>
			<div class="info"></div>
		</div>
		<ul class="navigation">
			<li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-folder-o fa-fw"></i>
                    <?php
                        if(isset($_COOKIE['site_url'])){
                            echo $_COOKIE['site_url'];
                        }else{
                           echo "My Websites"; 
                        }
                    ?>
                        <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
			        <?php echo $site_link;?>
			    </ul>
			  </li>
			<li><a href="" class='showTagsModal'><i class="fa fa-code fa-fw" aria-hidden="true"></i> Create Tags</a></li>
			<?php if($plan == "Trial"): ?>
				<li><a href="subscription" class=""><i class="fa fa-plus fa-fw" aria-hidden="true"></i> Add New Site</a></li>
			<?else:?>
				<li><a href="" class="showSiteModal"><i class="fa fa-plus fa-fw" aria-hidden="true"></i> Add New Site</a></li>
			<?php endif;?>
			<li><a href="performance"><i class="fa fa-signal fa-fw"></i> Performance</a></li>
			<li><a href="subscription"><i class="fa fa-credit-card fa-fw" aria-hidden="true"></i> Subscription | <?php echo $message ?></a></li>
			<!--<li><i class="fa fa-bell fa-fw" aria-hidden="true"></i><a href="settings">SMS Alerts</a></li>-->
			<?php echo $role; ?>
			<li class="logout-li"><a href="logout" class="logout"><i class="fa fa-sign-out fa-fw" aria-hidden="true"></i> Log out</a></li>
		</ul>
	</aside>
	<section id="contents">
		<nav class="navbar navbar-default">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<i class="fa fa-align-right"></i>
					</button>
					<a class="navbar-brand" href="web-profile"><?php echo UserName($conn, $_SESSION['user_id']); ?>'s <span class="main-color">Dashboard</span></a>
				</div>
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="_logout"><a href="logout" class="logout"><i class="fa fa-sign-out"></i> Log out</a></li>
						<li><a href="" class="show-side-btn-link"><i data-show="show-side-navigation" class="fa fa-bars show-side-btn"></i></a></li>
					</ul>
				</div>
			</div>
		</nav>
		<script>
		    $(function(){
		        $(document).on("click", ".site_url_pef", function(e){
		           e.preventDefault();
		           var link = $(this).attr("id");
		           var site_link = $(this).attr("href");
		          document.cookie = "site_url="+link+";expires=Thu, 05 Sep 2021 00:00:00 GMT;path=/;";
		           window.location = site_link;
		        })
		    })
		  //  close the side menu when the screen is small -- mobile mode
		    $(document).mouseup(function(e) {
                var container = $(".side-nav");
                if ($(window).width() <= 767) {
                // if the target of the click isn't the container nor a descendant of the container
                    if (!container.is(e.target) && container.has(e.target).length === 0) {
                        container.hide();
                    }
                }
            });
		</script>
		<div id="loader"></div>