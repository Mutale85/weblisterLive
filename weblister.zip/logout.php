<?php
include_once("includes/db.php");
unset($_SESSION['username']);
session_destroy();
header('location:./');
?>