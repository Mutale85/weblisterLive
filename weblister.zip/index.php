<?php
$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$start = $time;

include 'header.php';
?>

<div class="container">
	<div class="row">
		<div class="col-md-5 col-sm-12 col-xs-12">
			<div class="main-container">
				<h1 class="h1">Monitor Your Website Uptime. Count your website visits.</h1>
				<div class="webFormDiv" id="register">
					<div class="price-gd-top price-trial">
						<h4>Start Your 30 Days Free Trial</h4>
						<!-- <h3>$0.00</h3>
						<h5>One Month</h5> -->
					</div>
					<p class="text-center">No Credit Card Required</p>
					<hr>
					<form method="post" class="websiteForm">
						<div class="form-group">
							<label>WEBSITE URL</label>
							<input type="text" name="website_link" onblur="is_valid_url(this.value)" id="website_link" class="form-control" placeholder="https://" required="required">
							<em>Add an active link</em> <div id="url-error"></div>
						</div>
						<div class="form-group">
							<label>CATEGORY</label>
							<select class="form-control" name="website_category" id="website_category" required="required">
								<option value="">Choose A Category</option>
								<option value="Blog">Blog</option>
								<option value="Education">Education</option>
								<option value="E-commerce">E-commerce</option>
								<option value="How To">How To</option>
								<option value="Life Style">Life Style</option>
								<option value="Medical">Medical</option>
								<option value="Music">Music</option>
								<option value="News">News</option>
								<option value="Personal">Personal</option>
								<option value="Technology">Technology</option>
								<option value="Other">Other</option>
							</select><br>
							<input type="text" name="other_website_category" id="other_website_category" class="form-control" placeholder="Specify Category" style="display: none;">
							<em id="cat_error"></em>
						</div>
						<div class="form-group">
	               			<div class="input-group">
	               				<div class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></div>
		               			<input type="text" name="username" id="username" class="form-control" required="required" placeholder="Create Username" onblur="checkUsername(this.value)">
		               		</div>
		               		<em id="user_error"></em>
	               		</div>
	               		<div class="form-group">
	               			<div class="input-group">
	               				<div class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
	               				<input type="email" name="email" id="email" class="form-control" required="required" placeholder="Email">
	               				<input type="hidden" name="plan" id="plan" value="Trial">
	               				<input type="hidden" name="start_date" id="start_date">
	               				<input type="hidden" name="price" id="price" value="0.00">
	               				<input type="hidden" name="end_date" id="end_date" value="">
	               			</div>
	               			<p><i>We will never share your Email with anyone</i></p>
	               		</div>
						<button class="btn btn-primary" type="submit" id="submitBtn">SUBMIT SITE</button>
						<div class="message-div"></div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-md-7 col-sm-12 col-xs-12">
			<div class="main-container-two">
				<img src="images/undraw_content_team_3epn.svg" class="img-responsive demopic" alt="demopicture">
				<div class="join-now">
					<h3 class="text-center pricing"></h3><hr>
					<ul class="ul_class">
						<!-- <li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> </li> -->
						<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Can you tell how many of your website visitors used <b><i> mobile phones </i></b> or <b><i> tablets </i></b> or <b><i> computers </i></b>? Why should you care? knowing will help you optimize your website to suit your customer's needs.</li>
						<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Do you wish to know which of your <b><i> pages</i></b> received higher traffic?</li>
						<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Monitor Your Website Availability <b><i> every 5 minutes.</i></b></li>
						<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Get <b><i>notifications</i></b> when your site is down.</li>
						<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> View similar websites to yours.</li>						
					</ul>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<ul class="ul_class">
				<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Preview your live website on <b><i> mobile simulator</i></b>. </li>
				<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Create website title and meta tags for Twitter and Facebook <b><i> Free</i></b>. </li>
				<li><i class="fa fa-check-square-o text-primary" aria-hidden="true"></i> Compare which <b><i>devices</i></b> are mostly used to visit your site.</li>
			</ul>
		</div>
		<div class="col-md-7">
			<a href="images/page-view.jpeg" title="demopicture" class="fancybox">
				<img src="images/page-view.jpeg" class="img-responsive image-demo" title="click on me" alt="demopicture">
			</a>
		</div>
		<div class="col-md-5">
			<h3 class="text-center">Mobile Website Preview</h3>
			<img src="images/mobile-preview.jpeg" class="img-responsive mobile-preview"  alt="demopicture2">
			<br><br>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="price-grid col-md-4">
				<div class="price-block agile">
					<div class="price-gd-top pric-clr1">
						<h4>Basic</h4>
						<h3>$5.99</h3>
						<h5>Monthly</h5>
					</div>
					<div class="price-gd-bottom">
						<div class="price-list">
							<ul>
								<li>Up to 10K visitors</li>
								<li>Unlimted Websites</li>
								<li>Website Monitoring Every 5 Minutes</li>
								<li>Check Top Performing Pages</li>
								<li>Update Website Visits</li>
								<li>Receive Email Alerts on Downtime</li>
								<li>Check Mobile Responsiveness</li>
							</ul>
						</div>
					</div>
					<div class="price-select text-center pric-sclr1">
						<a class="btn btn-default popup-with-zoom-anim" data-plan="basic" data-price="4.99" href="#register" data-sites="01">Try Now</a><br><br>
						<p><em>No Credit Card Required</em></p>
						<br><br>
					</div>
				</div>
			</div>

			<div class="price-grid col-md-4">
				<div class="price-block agile">
					<div class="price-gd-top pric-clr2">
						<h4>Middle</h4>
						<h3>$9.99</h3>
						<h5>Monthly</h5>
					</div>
					<div class="price-gd-bottom">
						<div class="price-list">
							<ul>
								<li>Up to 100K visitors</li>
								<li>Unlimted Websites</li>
								<li>Check Top Performing Pages</li>
								<li>Website Monitoring Every 5 Minutes</li>
								<li>Update Website Visits</li>
								<li>Receive Email Alerts on Downtime</li>
								<li>Check Mobile Responsiveness</li>
							</ul>
						</div>
					</div>
					<div class="price-select text-center pric-sclr2">
						<a class="btn btn-default popup-with-zoom-anim" data-plan="Middle" data-price="9.99" href="#register" data-sites="05">Try Now</a><br><br>
						<p><em>No Credit Card Required</em></p>
						<br><br>
					</div>
				</div>
			</div>

			<div class="price-grid col-md-3">
				<div class="price-block agile">
					<div class="price-gd-top pric-clr3">
						<h4>Platinum</h4>
						<h3>$19.99</h3>
						<h5>Monthly</h5>
					</div>
					<div class="price-gd-bottom">
						<div class="price-list">
							<ul>
								<li>unlimited visitors</li>
								<li>Unlimted Websites</li>
								<li>Website Monitoring Every 5 Minutes</li>
								<li>Check Top Performing Pages</li>
								<li>Update Website Visits</li>
								<li>Receive Email Alerts on Downtime</li>
								<li>Check Mobile Responsiveness</li>
							</ul>
						</div>
					</div>
					<div class="price-select text-center pric-sclr3">
						<a class="btn btn-default popup-with-zoom-anim" data-plan="Platinum" data-price="19.99" href="#register" data-sites="10">Try Now</a><br><br>
						<p><em>No Credit Card Required</em></p>
						<br><br>
					</div>
				</div>
			</div>
			<div class="col-md-5">
				<img src="images/sample-code.png" class="img-responsive sample-code">
			</div>
			<div class="col-md-7">
				<h3>Copy and Paste </h3>
				<div class="codeArea">
					<textarea readonly disabled="disabled" class="code-text"><script type="text/javascript" src="https://weblister.co/js/extension.js?url=website_url"></script></textarea>
					<br><button class="btn btn-default btn-xs  copy-btn" type="button">Get the Code</button><br><br>
				</div>
			</div>
		</div>
		<div id="pricing"></div>
		 <div class="col-md-12">
            <div class="footer">
                <!--<a href="https://www.producthunt.com/posts/weblister-co?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-weblister-co" target="_blank"><img src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=225735&theme=light" alt="Weblister.co - Creating an  Online Websites Directory | Product Hunt Embed" style="width: 250px; height: 54px;" width="250px" height="54px" /></a> -->
            </div>
        </div>
	</div>
</div>
<?php include ("footer.php")?>