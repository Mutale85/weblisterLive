<?php include "header-profile.php"; 
$email = $_SESSION['email'];
$QUERY = mysqli_query($conn, "SELECT * FROM web_directory WHERE user_email = '$email' ") or die(mysqli_error($conn));
$row = mysqli_fetch_assoc($QUERY);
if(isset($_COOKIE['site_url'])){
   $website_link =  $_COOKIE['site_url'];
}else{
    $website_link = $row['website_link'];
}
// header("location:site-performance?site-url=".$website_link);
echo "<script>
            window.location = 'site-performance?site-url=$website_link';
        </script>";

?>

<style>
    .detailsDiv {
        width:80%;
        margin:60px auto;
        border:1px solid #ccc;
        padding:20px;
        font-family: 'Source Code Pro', monospace;
    }
    .tableDiv {
        border-radius:3px;
        border:1px solid #ddd;
        padding:10px;
    }
    .mapping {
        margin:50px auto;
        width:80%;
        margin:30px auto;
        padding:0px;
        border-radius:5px;
    }
    .mapping #vmap {
        width: 100%; height: 400px;
		border-radius: 5px;
    }
    @media(max-width:767px){
        .detailsDiv {
            width:100%;
        }
        .mapping {
           width:100%; 
        }
    }
    
</style>
	<div class="container-fluid">
		<div class="row">
			<div class="">
				<div class="col-md-12">
					<div class="mylistedSites"></div>
				</div>
				<div class="col-md-12">
				    <div class="detailsDiv">
    					<h2 class="site_header">Website Uptime</h2><hr>
    					<div id="performance"> Please Wait ... <i class="fa fa-spinner fa-spin fa-fw"></i></div>
    				</div>
				</div>
				<div class="mapping">
				    <div id="vmap" style=""></div>
				</div>
			</div>
		</div>
	</div>
	<!--Modal To Show Countrie User Starts Here-->
    <div class="modal" tabindex="-1" role="dialog" id="CountriesDialog">
    	<div class="modal-dialog modal-lg" role="document">
    		<div class="modal-content">
    	  		<div class="modal-header">
    	    		<h3 class="text-center site_name"></h3>
    	    		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
    	      			<span aria-hidden="true">&times;</span>
    	    		</button>
    	  		</div>
    		  	<div class="modal-body">
    		    	<div id="modal-results"></div>
    		  	</div>
    		  	<div class="modal-footer">
    		    	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    		  	</div>
    		</div>
    	</div>
    </div>
    <!--Modal Ends Here-->
	<br><br><br>
</section>
	
<?php include 'footer-profile.php'; ?>
<link rel="stylesheet" href="maps/css/jqvmap.css" type="text/css"/>
<script type="text/javascript" src="maps/js/jquery.vmap.js"></script>
<script type="text/javascript" src="maps/js/jquery.vmap.world.js" charset="utf-8"></script>
<script type="text/javascript" src="maps/js/jquery.vmap.sampledata.js"></script>

<!--END OF MAPPING LINKS-->
<script>
    jQuery(document).ready(function () {
    // var DB = '<?php echo $DB?>';
        jQuery('#vmap').vectorMap({
    	    map: 'world_en',
    	    backgroundColor: '#a5bfdd',
    	    borderColor: '#818181',
    	    borderOpacity: 0.25,
    	    borderWidth: 1,
    	    color: '#f4f3f0',
    	    enableZoom: true,
    	    hoverColor: '#c9dfaf',
    	    hoverOpacity: null,
    	    normalizeFunction: 'linear',
    	    scaleColors: ['#b6d6ff', '#005ace'],
    	    selectedColor: '#c9dfaf',
    	    selectedRegions: null,
    	    showTooltip: true,
    	    onRegionOver: function(element, code, region){
    	        var message = 'You clicked "'
    	            + region
    	            + '" which has the code: '
    	            + code.toUpperCase();
    	       // jQuery.ajax({
    	            
    	       // 	url:"includes/maps",
    	       // 	method:"post",
    	       // 	data:{region:region, DB:DB},
    	       // 	success:function(data){
    	       //         $("#result").html(region +"<br><span> Visitors:</span> "+data).addClass("data");
    	       // 	}
    	       // });
    	    },
    	    onRegionClick: function(event, code, region){
    	       //jQuery.ajax({
    	       // 	url:"includes/maps",
    	       // 	method:"post",
    	       // 	data:{region:region, DB:DB},
    	       // 	success:function(data){
            // 	       $("#result").html(region +"<br><span> Visitors:</span> "+data ).addClass("data");
    	       // 	}
    	       // }); 
    	    }
            
    	});
    });
</script>