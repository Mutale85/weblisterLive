<?php
include 'header.php';
?>
<style type="text/css">
	.message {
		margin: 100px auto;
		box-shadow: 0 0 5px;
		padding: 20px;
		text-transform: capitalize;
		border-radius:5px;
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="message">
				<?php
					if (isset($_GET['message'])) {
						$msg = $_GET['message'];
						if($msg == "Activated"){?>
						    <h3 class="">You Account is Activated <a href="https://weblister.co/login" class="btn btn-default pull-right"> Login </a></h3>
						    <img src="images/undraw_monitor.svg" class="img-responsive monitor_image" >
						    <p><a href="https://weblister.co/login" class="btn btn-default"> Login </a></p>
					    <?php
						    
						}else{
						  echo $msg;  
						}
					}else{
						header("location:./");
					}
				?>
			</div>
		</div>
	</div>
</div>