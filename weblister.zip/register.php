<?php
include("header.php");
?>
<style>
	.form-div {
		width:65%; border: solid 1px #333333;margin: 50px auto;
	}
	
	.error-msg_s {
		color:#cc0000; /*margin-top:10px;text-align: center;
		background: rgba(0,0,0,0.8); padding: 7px;*/
	}
	
	.eye_con:hover {
		cursor: pointer;
	}
	.input-group-addon {
		background: #fff;
	}
	.eyeColor {
		color: mediumseagreen;
	}
	@media(max-width: 768px){
		.form-div {
			width:100%;
			border: none;
			box-shadow: 0 0 3px;
		}
	}
</style>
<div class="container wrapper">
	<div class="row">
		<div class="col-md-12">
			<div class="form-div">
				<h3 class="text-center">Create Your Account</h3><br>
               	<form method="post" id="CreateAccountForm">
               		<div class="form-group">
               			<div class="input-group">
               				<div class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></div>
	               			<input type="text" name="username" id="username" class="form-control" required="required" placeholder="Create Username" onblur="checkUsername(this.value)">
	               		</div>
	               		<em id="user_error"></em>
               		</div>
               		<div class="form-group">
               			<div class="input-group">
               				<div class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
               				<input type="email" name="email" id="email" class="form-control" required="required" placeholder="Email">
               			</div>
               		</div>
               		<div class="form-group">
               			<div class="input-group">
               				<div class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></div>
               				<input type="password" name="password" id="password" class="form-control" required="required" placeholder="Create Password">
               				<div class="input-group-addon eye_con"><i class="fa fa-eye"></i></div>
               			</div>
               		</div>
                  	<button type="submit" name="submit" class="btn btn-primary submitBtn pull-left">Submit</button>
               	</form>
               	<div class="">
               		<br><br><hr>
               		<p>Already A Member? <a href="login">Login <i class="fa fa-sign-in"></i></a></p>
               </div>
           		<div class="error-msg"></div>		
         	</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	function checkUsername(username_check) {
			$.ajax({
			url:"includes/register.php",
			method:"post",
			data:{username_check:username_check},
			success:function(data){
				$("#user_error").html(data).addClass("error-msg_s");
			}
		})
	}

	$(function(){
		$("#CreateAccountForm").submit(function(e){
			e.preventDefault();
			$.ajax({
				url:"includes/register.php",
				method:"post",
				data:$(this).serialize(),
				beforeSend:function(){
					$(".submitBtn").attr("disabled", "disabled");
					$(".submitBtn").html("<i class='fa fa-spinner fa-spin'></i>");
				},
				success:function(data){
					$(".submitBtn").html("Submit");
					$(".submitBtn").removeAttr("disabled");
					$(".error-msg").html(data).addClass("error-msg_s");
				}
			})
		});

		$(".eye_con").click(function () {
			var password = document.getElementById('password');
			if (password.type === "password") {
				password.type = "text";
				$(".fa-eye").addClass("fa-eye-slash").addClass("eyeColor");
			}else{
				password.type = "password";
				$(".fa-eye").removeClass("fa-eye-slash").removeClass("eyeColor");
			}
		})
	})
</script>