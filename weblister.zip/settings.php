<?php
include 'header-profile.php';
?>
<link rel="stylesheet" type="text/css" href="build/css/intlTelInput.min.css">
<style type="text/css">
	.select-style {
	    width: 70px;
	    padding: 0;
	    margin: 0;
	    display: inline-block;
	    vertical-align: middle;
	    background: url("http://grumbletum.com/places/arrowdown.gif") no-repeat 100% 30%;
	}
	.select-style select {
	    width: 100%;
	    padding: 0;
	    margin: 0;
	    background-color: transparent;
	    background-image: none;
	    border: none;
	    box-shadow: none;
	    -webkit-appearance: none;
	       -moz-appearance: none; // FF have a bug
	            appearance: none;
	}
	.iti { width: 100%; }
	.intl-tel-input {
	  /*display: table-cell;*/
	  background-color: black;
	}
	.intl-tel-input .selected-flag {
	  z-index: 4;
	  background-color: black;
	}
	.iti__selected-dial-code {
		color: red;
	}
	/*contact Details -------*/
	.displayContactDetails, .contactsFormDiv {
	    border:1px solid #ccc;
	    padding:10px;
	    border-radius:5px;
	    margin-top:40px;
	}
</style>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-6">
		    <h3 class="text-center">Contact Details</h3><hr>
			<div class="displayContactDetails"></div>
		</div>
		<div class="col-md-6">
		    <div class="contactsFormDiv">
    			<h3 class="text-center">Add Phone Number</h3><hr>
    			<form method="post" id="contactsForm">
    				<div class="form-group">
    					<input type="hidden" name="user_email" id="user_email" class="form-control" value="<?php echo $_SESSION['email'] ?>">
    				</div>
    				<div class="form-group">
              			<label>Mobile Number</label>
    					<input type="tel" id="phone" name="phone" class="form-control" onkeyup="checkCodeNumber(this.value)">
    					<input type="hidden" name="phonenumber" id="phonenumber" value="" class="form-control"><br>
    				</div>
    				<p id="result"></p>
    				<p id="error4" style="color: red; display: none;">Enter Your Valid Mobile Number</p><br>
    				<button class="btn btn-default addPhone" type="submit">Submit</button>
    			</form>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="build/js/intlTelInput.js"></script>
<?php
include 'footer-profile.php';
?>
<script>
	var input = document.querySelector("#phone");
    var iti = intlTelInput(input, {
    	autoHideDialCode: true,
        autoPlaceholder: true,
        separateDialCode: true,
        nationalMode: true,
	    allowDropdown: true,
	    autoPlaceholder: "polite",
	    dropdownContainer: document.body,
	      geoIpLookup: function(callback) {
	        $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
	          var countryCode = (resp && resp.country) ? resp.country : "";
	          callback(countryCode);
	        });
	      },
	      nationalMode: false,
	      placeholderNumberType: "MOBILE",
	      preferredCountries: ['zm'],
	      separateDialCode: true,
	    utilsScript: "build/js/utils.js",
	});

	function checkCodeNumber(phone){
		var num = iti.getNumber(),
		valid = iti.isValidNumber();
		result = document.querySelector("#result");
		phonenumber = document.querySelector("#phonenumber");
		if (phone == "") {
			result.textContent = "Add Your Number";
			return false;
		}
  		if (valid == true) {
  			result.textContent = "Number: " + num + ", is valid";
  			phonenumber.value = num;
  		}else if(valid == false){
  			result.textContent = "Number: " + num + ", is invalid";
  			phonenumber.value = "";
  		}
	}

	$(function(){
		$("#contactsForm").on("submit", function(e){
			e.preventDefault();
			var contactsForm = $("#contactsForm").serialize();
			var phone = $("#phone").val();
			var phonecode = $("#phonenumber").val();
			$.ajax({
				url:"includes/add-contacts",
				method:"POST",
				data:contactsForm,
				beforeSend:function(){
				   $(".addPhone").html("<i class='fa fa-spinner fa-spin'></i>").attr("disabled", "disabled"); 
				},
				success:function(data){
					$(".displayContactDetails").html(data);
					 $(".addPhone").html("Submit").removeAttr("disabled");
					 $("#result").html("");
					 $("#contactsForm")[0].reset();
				}
			})
		})
	});
    
    function getUserContactsDetails(){
        var userEmail = "userEmail";
    	$.ajax({
			url:"includes/add-contacts",
			method:"POST",
			data:{userEmail:userEmail},
			success:function(data){
				$(".displayContactDetails").html(data);
			}
		})
    }
    getUserContactsDetails();
    
</script>
